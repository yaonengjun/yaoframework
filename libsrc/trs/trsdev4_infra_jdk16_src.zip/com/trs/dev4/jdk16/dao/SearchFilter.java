/*
 * Created on 2004-12-7
 */
package com.trs.dev4.jdk16.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.common.util.StringHelper;

import com.trs.dev4.jdk16.dao.hb3.HqlGenerator;
import com.trs.dev4.jdk16.utils.ArrayUtil;
import com.trs.dev4.jdk16.utils.DigestUtil;

/**
 * 对SQL查询条件的封装. <BR>
 * 
 * @author TRS信息技术有限公司
 */
public class SearchFilter {

	/**
	 * 默认分页的页码.
	 */
	public final static int DEFAULT_PAGE_NO = 0;

	/**
	 * 默认分页的记录数量.
	 */
	public final static int DEFAULT_PAGE_SIZE = 20;

	/**
	 * 最多提取的记录数量，防止大数据量时内存溢出.
	 */
	public final static int MAX_PAGE_SIZE = 1000;

	/**
	 * 查询条件, 即Where子句部分.
	 */
	private List<Condition> conditions = new ArrayList<Condition>();

	/**
	 * 查找的起始位置, 默认值0表示从第一条开始.
	 */
	private int startPos = 0;

	/**
	 * 取记录数时的最大数目上限, 默认值-1表示无限制.
	 */
	private int maxResults = -1;

	/**
	 * SQL语句中order子句中"order by"后面的部分.
	 */
	private String orderBy;

	/**
	 * SQL语句中order子句中"group by"后面的部分, 但不包含having部分.
	 */
	private String groupBy;

	/**
	 * 指定的默认检索字段，此属性可以为空。
	 */
	private String defaultFields = "*";

	/**
	 * 参数为SearchFilter的时候是否从cache中提取
	 */
	private boolean cacheable = false;

	/**
	 * 默认检索词
	 */
	private String defaultKeyword;

	/**
	 * 构造函数，待有分页信息，仅package可见.
	 * 
	 * @param pageNo
	 *            当前页码, 0表示第一页.
	 * @param pageSize
	 *            每页的条数
	 */
	SearchFilter(int pageNo, int pageSize) {
		if (pageSize > MAX_PAGE_SIZE) {
			pageSize = MAX_PAGE_SIZE;
		}
		this.setMaxResults(pageSize);
		this.setStartPos(pageSize * pageNo);
		this.setCacheable(true);
	}

	/**
	 * 返回查询条件的总个数.
	 */
	public int getTotalConditions() {
		return conditions.size();
	}

	/**
	 * 返回指定项查询条件的查询项, 也就是对应的对象属性(即数据表的字段)名.
	 * 
	 * @param index
	 *            指定项的序号
	 * @return 对应的对象属性(即数据表的字段)名
	 */
	public String getPropertyName(int index) {
		return getCondition(index).getField();
	}

	/**
	 * 返回指定项查询条件的查询值.
	 * 
	 * @param index
	 *            指定项的序号
	 * @return 对应的查询值
	 */
	public Object getValue(int index) {
		return getCondition(index).getValue();
	}

	public Object getBetweenValue2(int index) {
		return getCondition(index).getValue2();
	}

	/**
	 * 返回指定项查询条件的关系运算符.
	 * 
	 * @param index
	 *            指定项的序号
	 * @return 对应的关系运算符
	 */
	public String getRelationOp(int index) {
		return getCondition(index).getOp();
	}

	/**
	 * 添加一个相等的查询条件, 即指定某属性的取值. <BR>
	 * 
	 * @param prop
	 *            属性名
	 * @param value
	 *            取值
	 * @see #addCondition(String, String, Object)
	 */
	public void addEqCondition(String prop, Object value) {
		addCondition(Condition.OP_EQUAL, prop, value);
	}

	/**
	 * 添加一个不相等的查询条件, 即指定某属性的取值. <BR>
	 * 
	 * @param prop
	 *            属性名
	 * @param value
	 *            取值
	 * @see #addCondition(String, String, Object)
	 */
	public void addNotEqCondition(String prop, Object value) {
		addCondition(Condition.OP_NOTEQUAL, prop, value);
	}

	/**
	 * 
	 * @param prop
	 * @creator liushen @ Feb 16, 2010
	 */
	public void addIsNullCondition(String prop) {
		addCondition(Condition.OP_ISNULL, prop, null);
	}

	/**
	 * 
	 * @param prop
	 * @creator liushen @ Feb 16, 2010
	 */
	public void addNotNullCondition(String prop) {
		addCondition(Condition.OP_ISNOTNULL, prop, null);
	}

	/**
	 * 
	 * @param prop
	 * @param value
	 * @since liushen @ Jun 17, 2010
	 */
	public void addInCondition(String prop, Object... value) {
		// WHERE id in ()会导致Hibernate抛出错误, 因此必须跳过无意义的空的in条件, 参见HQLBuider的类似方法:
		if (value == null || value.length == 0) {
			return;
		}

		addCondition(Condition.OP_IN, prop, value);
	}

	/**
	 * 
	 * @param prop
	 * @param value
	 * @since liushen @ Jun 17, 2010
	 */
	public void addInCondition(String prop, int... value) {
		if (value == null || value.length == 0) {
			return;
		}
		// liushen @ Jun 20, 2010: int[]必须转换为Integer[], 否则hibernate无法处理
		addCondition(Condition.OP_IN, prop, ArrayUtil.toIntegerArray(value));
	}

	/**
	 * 添加一个查询条件. <BR>
	 * <strong>注意!</strong> 因为操作符(参数op)容易导致随意写和出错, 请尽可能使用更明确的方法, 比如对in条件请使用
	 * {@link #addInCondition(String, Object[])}; 此方法仅在有动态查询需要时使用.
	 * 
	 * @param op
	 *            属性和取值的关系运算符. 可以取得值有"=", "like", ">=", "<=", ">", "<", "in".
	 *            对于除此以外的值, 该方法并不会实际添加该条件.
	 * @param prop
	 *            对象的属性名
	 * @param value
	 *            要查询的取值; 如果value参数为null, 该方法并不会实际添加该条件.
	 * @see Condition#isValidOp(String)
	 */
	// TODO: liushen@Jan 20, 2011: 可以将操作符改进为枚举
	public void addCondition(String op, String prop, Object value) {
		Condition condition = Condition.buildCondition(op, prop, value);
		addCondition(condition);
	}

	/**
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 * @since fangxiang @ Apr 17, 2010
	 */
	public void addGreaterThanEquals(String prop, Object value) {
		this.addCondition(Condition.OP_GTE, prop, value);
	}

	/**
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 * @since fangxiang @ Apr 17, 2010
	 */
	public void addGreaterThan(String prop, Object value) {
		this.addCondition(Condition.OP_GT, prop, value);
	}

	/**
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 * @since fangxiang @ Apr 17, 2010
	 */
	public void addLesserThan(String prop, Object value) {
		this.addCondition(Condition.OP_LT, prop, value);
	}

	/**
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 * @since fangxiang @ Apr 17, 2010
	 */
	public void addLesserThanEquals(String prop, Object value) {
		this.addCondition(Condition.OP_LTE, prop, value);
	}

	/**
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 * @since fangxiang @ Apr 17, 2010
	 */
	public void addLike(String prop, Object value) {
		this.addCondition(Condition.OP_LIKE, prop, value);
	}

	/**
	 * 
	 * 
	 * @param condition
	 */
	private void addCondition(Condition condition) {
		if (condition != null) {
			conditions.add(condition);
			// liushen @ May 4, 2010: 兼容一个字段有多个条件时，比如id小于10大于5
			condition.setBindName(condition.getField() + "_"
					+ conditions.size());
		}
	}

	/**
	 * 
	 * @param prop
	 * @param value1
	 * @param value2
	 */
	public void addBetweenCondition(String prop, Object value1, Object value2) {
		addCondition(Condition.buildBetweenCondition(prop, value1, value2));
	}

	/**
	 * 取记录的起始位置.<BR>
	 * 
	 * @return 取记录的起始位置. 0表示从第一条开始取记录. 该值不会小于0.
	 */
	public int getStartPos() {
		return startPos;
	}

	/**
	 * 设置取记录的起始位置.<BR>
	 * 如果参数小于0, 则忽略此设值操作.
	 * 
	 * @param startPos
	 *            取记录的起始位置. 0表示从第一条开始. 如果参数小于0, 则忽略此设值操作.
	 */
	public void setStartPos(int startPos) {
		if (startPos > 0) {
			this.startPos = startPos;
		}
	}

	/**
	 * 获取取记录数的总数, 默认值-1表示无限制.
	 * 
	 * @return Returns the maxResults.
	 */
	public int getMaxResults() {
		return maxResults;
	}

	/**
	 * 设置取记录数的总数, 默认值-1表示无限制.
	 * 
	 * @param maxResults
	 *            The maxResults to set.
	 */
	public void setMaxResults(int maxResults) {
		this.maxResults = maxResults;
	}

	/**
	 * 返回指定项的查询条件.
	 * 
	 * @param index
	 *            指定项的序号
	 * @return 查询条件
	 */
	public Condition getCondition(int index) {
		if (index < 0 || (index >= conditions.size())) {
			throw new IndexOutOfBoundsException("index should in [0, "
					+ conditions.size() + "), but it's " + index + "!");
		}
		return conditions.get(index);
	}

	/**
	 * Returns the {@link #orderBy}.
	 * 
	 * @return the orderBy.
	 */
	public String getOrderBy() {
		return orderBy;
	}

	/**
	 * Set {@link #orderBy}.
	 * 
	 * @param orderBy
	 *            The orderBy to set.
	 */
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	/**
	 * 
	 * @return
	 */
	public String buildWhere() {
		return new HqlGenerator(this).buildWhere();
	}

	/**
	 * 通过设置页面来设置起始位置，减少外部计算造成的页面记录条数的不一致
	 * 
	 * @param pageNo
	 *            当前页码, 0表示第一页.
	 * @creator fangxiang @ Mar 19, 2009
	 */
	public void setPageNo(int pageNo) {
		this.startPos = pageNo * DEFAULT_PAGE_SIZE;
	}

	@Override
	public String toString() {
		StringBuilder strBuf = new StringBuilder();
		strBuf.append("{[where: ");
		strBuf.append(buildWhere()).append("]");
		if (this.getOrderBy() != null) {
			strBuf.append("[order:").append(this.getOrderBy()).append("]");
		}
		if (this.getGroupBy() != null) {
			strBuf.append("[group:").append(this.getGroupBy()).append("]");
		}
		strBuf.append("[parameters:");
		int totalConditions = this.getTotalConditions();
		for (int i = 0; i < totalConditions; i++) {
			Condition condition = getCondition(i);
			strBuf.append(condition.getField()).append(' ');
			strBuf.append(condition.getOp()).append(' ');
			if (condition.needBindCollectionParam()) {
				strBuf.append("(").append(condition.getValue()).append(')');
			} else if (condition.isBetweenCondition()) {
				strBuf.append('(').append(condition.getValue());
				strBuf.append(" and ").append(condition.getValue2())
						.append(')');
			} else if (condition.needBindOneParam()) {
				strBuf.append(condition.getValue());
			}
			if (i < totalConditions - 1) {
				strBuf.append(";");
			}
		}
		strBuf.append("]}");
		return strBuf.toString();
	}

	/**
	 * 
	 * @return
	 */
	public String getCacheKey() {
		StringBuilder strBuf = new StringBuilder();
		strBuf.append("[");
		int totalConditions = this.getTotalConditions();
		for (int i = 0; i < totalConditions; i++) {
			Condition condition = getCondition(i);
			strBuf.append(this.getFieldAbbr(condition.getField()));
			if (condition.needBindCollectionParam()) {
				strBuf.append("(").append(condition.getValue()).append(')');
			} else if (condition.isBetweenCondition()) {
				strBuf.append('(').append(condition.getValue());
				strBuf.append("-").append(condition.getValue2())
						.append(')');
			} else if (condition.needBindOneParam()) {
				strBuf.append(condition.getValue());
			}
			strBuf.append('_');
		}
		if (this.getOrderBy() != null) {
			strBuf.append(StringHelper.replace(this.getOrderBy(), " ", "-"))
					.append("_");
		}
		if (this.getGroupBy() != null) {
			strBuf.append(this.getGroupBy());
		}
		strBuf.append("_sp").append(this.startPos).append("_ps")
				.append(this.maxResults);
		strBuf.append("]");
		return DigestUtil.md5Hex(strBuf.toString());
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Jan 18, 2011
	 */
	protected String getFieldAbbr(String field) {
		if ("createdTime".equals(field)) {
			return "ct";
		} else if ("createdUserId".equals(field)) {
			return "cui";
		} else if ("lastModifiedTime".equals(field)) {
			return "lmt";
		} else if ("receivedTime".equals(field)) {
			return "rt";
		}
		return field;
	}


	/**
	 * @return
	 * @creator liushen @ Feb 15, 2010
	 */
	public static SearchFilter getDefault() {
		return new SearchFilter(DEFAULT_PAGE_NO, DEFAULT_PAGE_SIZE);
	}

	public static SearchFilter getNoPagedFilter() {
		return new SearchFilter(DEFAULT_PAGE_NO, MAX_PAGE_SIZE);
	}

	/**
	 * @return
	 * @creator liushen @ Feb 15, 2010
	 */
	public static SearchFilter getSearchFilter(int pageNo, int pageSize) {
		return new SearchFilter(pageNo, pageSize);
	}

	/**
	 * @return the {@link #groupBy}
	 */
	public String getGroupBy() {
		return groupBy;
	}

	/**
	 * @param groupBy
	 *            the {@link #groupBy} to set
	 */
	public void setGroupBy(String groupBy) {
		this.groupBy = groupBy;
	}

	public void setCacheable(boolean cacheable) {
		this.cacheable = cacheable;
	}

	/**
	 * @return the {@link #defaultFields}
	 */
	public String getDefaultFields() {
		return defaultFields;
	}

	/**
	 * @param defaultFields
	 *            the {@link #defaultFields} to set
	 */
	public void addDefaultFields(String defaultFields) {
		this.defaultFields = defaultFields;
	}

	/**
	 * @return the {@link #defaultKeyword}
	 */
	public String getDefaultKeyword() {
		return defaultKeyword;
	}

	/**
	 * @param defaultKeyword
	 *            the {@link #defaultKeyword} to set
	 */
	public void setDefaultKeyword(String defaultKeyword) {
		this.defaultKeyword = defaultKeyword;
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Dec 24, 2010
	 */
	public boolean isCacheable() {
		if (!cacheable)
			return false;
		int totalConditions = this.getTotalConditions();
		for (int i = 0; i < totalConditions; i++) {
			Condition condition = getCondition(i);
			if (condition.needBindCollectionParam()) {
				return false;
			}
		}
		return cacheable;
	}
}