/*
 * Created: TRS@Feb 9, 2012 3:42:00 PM
 */
package com.trs.dev4.jdk16.dao.hb3;

import org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean;

/**
 * 职责: 实现数据库会话和DataSource的管理<br>
 * 
 */
public class ShardingDatabaseSessionFactory extends AnnotationSessionFactoryBean {

}
