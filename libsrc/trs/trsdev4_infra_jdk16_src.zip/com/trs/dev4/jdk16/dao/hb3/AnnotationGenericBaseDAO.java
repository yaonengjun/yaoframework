package com.trs.dev4.jdk16.dao.hb3;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.trs.dev4.jdk16.dao.DBSummary;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;

/**
 * Annotation领域对象数据持久化基类，支持读写分离<br>
 * byType默认注入SessionFactory，默认可能得到多个选择，所以指定qualifier为mainSessionFactory的实现
 * 
 * 
 * @since 2010-4-14
 * @creator liuyou
 */
public class AnnotationGenericBaseDAO<T> extends GenericBaseDAO<T> {

	/**
	 *
	 */
	private GenericBaseDAO<T> slaveGenericBaseDAO = null;

	@Resource(name = "slaveSessionFactory")
	private SessionFactory slaveSessionFactory;

	@Autowired
	public void setFactory(
			@Qualifier("mainSessionFactory") SessionFactory sessionFactory) {
		this.setSessionFactory(sessionFactory);
	}

	/**
	 * @param slaveSessionFactory
	 *            the {@link #slaveSessionFactory} to set
	 */
	public void setSlaveSessionFactory(SessionFactory slaveSessionFactory) {
		this.slaveSessionFactory = slaveSessionFactory;
		buildSlaveSessionFactory(this.getClassType());
	}

	/**
	 * @param classType
	 */
	public AnnotationGenericBaseDAO(Class<T> classType) {
		super(classType);
		buildSlaveSessionFactory(classType);
	}

	/**
	 * @param classType
	 * @since fangxiang @ Oct 27, 2010
	 */
	private void buildSlaveSessionFactory(Class<T> classType) {
		// if (slaveSessionFactory != null) {
		// slaveGenericBaseDAO = new GenericBaseDAO<T>(classType);
		// slaveGenericBaseDAO.setSessionFactory(slaveSessionFactory);
		// }
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#getObject(int)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public T getObject(int objectId) throws DAOException {
		if ( slaveAvailable() ){
			return slaveGenericBaseDAO.getObject(objectId);
		}
		return super.getObject(objectId);
	}

	/**
	 * @return
	 * @since fangxiang @ Oct 27, 2010
	 */
	boolean slaveAvailable() {
		return slaveGenericBaseDAO != null;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#listObjects()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public List<T> listObjects() throws DAOException {
		if (slaveAvailable()) {
			return slaveGenericBaseDAO.listObjects();
		}
		return super.listObjects();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#listObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public List<T> listObjects(SearchFilter sf) throws DAOException {
		if (slaveAvailable()) {
			return slaveGenericBaseDAO.listObjects(sf);
		}
		return super.listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#listObjects(java.lang.String,
	 *      java.lang.Object)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public List<T> listObjects(String fieldName, Object value)
			throws DAOException {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.listObjects(fieldName, value);
		}
		return super.listObjects(fieldName, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#pagedAll()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public PagedList<T> pagedAll() throws DAOException {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.pagedAll();
		}
		return super.pagedAll();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public PagedList<T> pagedObjects(SearchFilter sf) throws DAOException {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.pagedObjects(sf);
		}
		return super.pagedObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#findFirst(java.lang.String,
	 *      java.lang.Object)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public T findFirst(String field, Object value) throws DAOException {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.findFirst(field, value);
		}
		return super.findFirst(field, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#total()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public int total() throws DAOException {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.total();
		}
		return super.total();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public int total(SearchFilter sf) {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.total(sf);
		}
		return super.total(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#retriveDBSummary()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public DBSummary retriveDBSummary() {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.retriveDBSummary();
		}
		return super.retriveDBSummary();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#getAllEntityClassMetadata()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	public Map<String, ClassMetadata> getAllEntityClassMetadata() {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.getAllEntityClassMetadata();
		}
		return super.getAllEntityClassMetadata();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#getHibernateClassMetadata()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	ClassMetadata getHibernateClassMetadata() {
		if (slaveAvailable()) {
			this.slaveGenericBaseDAO.getHibernateClassMetadata();
		}
		return super.getHibernateClassMetadata();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.hb3.GenericBaseDAO#getHibernateEntityMetamodel()
	 * @since fangxiang @ Oct 27, 2010
	 */
	@Override
	EntityMetamodel getHibernateEntityMetamodel() {
		return super.getHibernateEntityMetamodel();
	}

}
