/*
 * Created: liushen@Jun 23, 2011 4:56:45 PM
 */
package com.trs.dev4.jdk16.dao;

/**
 * 所支持的关系数据库产品的枚举，用于对JDBC连接信息的生成和管理. <br>
 * 
 */
public enum RDBProduct {

	MySQL, Oracle, OracleRAC, SQLServer, DB2, Sybase, H2;

}
