/*
 * Created: Administrator@Oct 27, 2010 2:46:40 PM
 */
package com.trs.dev4.jdk16.dao.hb3;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 记录数据库查询及操作的耗时。 <br>
 * 
 */
public class QueryTimer {
	/**
	 *
	 */
	private final static Logger logger = Logger.getLogger(QueryTimer.class);
	/**
	 *
	 */
	private long beginTimeInMillis = System.currentTimeMillis();
	private Class<?> classType;

	/**
	 *
	 */
	public QueryTimer(Class<?> classType) {
		this.classType = classType;
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void startWatch() {
		beginTimeInMillis = System.currentTimeMillis();
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(SearchFilter searchFilter) {
		stopWatch(searchFilter, (Throwable) null);
	}

	/**
	 *
	 *
	 * @param exception TODO
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(SearchFilter searchFilter, Throwable exception) {
		long duration = getDuration();
		if (isHighRiskSlow(duration)) {
			if (exception != null) {
				logger.warn("(" + this.classType + ")'s SearchFilter(" + searchFilter + ") consumed (" + duration + ") ms!!", exception);
			} else {
				logger.warn("(" + this.classType + ")'s SearchFilter(" + searchFilter + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			}
			return;
		}
		if (isSlow(duration)) {
			if (logger.isDebugEnabled()) {
			logger.debug("(" + this.classType + ")'s SearchFilter("
					+ searchFilter.toString() + ") consumed (" + duration
					+ ") ms");
			}
		}
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(int id) {
		long duration = getDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + this.classType + ")'s Get id=(" + id + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s Get id=(" + id
					+ ") consumed (" + duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch() {
		long duration = getDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + this.classType + ")'s listObjects consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s listObjects consumed ("
					+ duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since fangxiang @ Oct 25, 2010
	 */
	public void stopWatch(Object entity, String action) {
		long duration = getDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + entity.toString() + ")'s (" + action + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + entity.toString() + ")'s (" + action
					+ ") consumed (" + duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since fangxiang @ Oct 25, 2010
	 */
	public void stopWatch(String statement) {
		long duration = getDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + this.classType + ")'s execute command(" + statement + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s execute command("
					+ statement + ") consumed (" + duration + ") ms");
		}
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	private boolean isSlow(long duration) {
		return (duration > 1000);
	}

	/**
	 * 
	 * @param duration
	 * @return
	 * @since liushen @ Feb 13, 2012
	 */
	private boolean isHighRiskSlow(long duration) {
		return (duration >= 5000);
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	private long getDuration() {
		return (System.currentTimeMillis() - beginTimeInMillis);
	}

}