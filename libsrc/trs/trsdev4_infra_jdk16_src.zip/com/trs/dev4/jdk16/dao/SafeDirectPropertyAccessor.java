package com.trs.dev4.jdk16.dao;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.hibernate.HibernateException;
import org.hibernate.PropertyAccessException;
import org.hibernate.PropertyNotFoundException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.property.DirectPropertyAccessor;
import org.hibernate.property.Setter;
import org.hibernate.util.ReflectHelper;

/*
 *
 * Created on 2005-12-17 17:05:43, by liushen
 com.trs.dev4.jdk16.daos.idm.util.hb;

 import java.lang.reflect.Field;
 import java.lang.reflect.Method;

 import org.hibernate.HibernateException;
 import org.hibernate.PropertyAccessException;
 import org.hibernate.PropertyNotFoundException;
 import org.hibernate.engine.SessionFactoryImplementor;
 import org.hibernate.property.DirectPropertyAccessor;
 import org.hibernate.property.Setter;
 import org.hibernate.util.ReflectHelper;

 /**
 * improve for primitive field: avoid Exception when the column value is null in db.
 * @see org.hibernate.property.DirectPropertyAccessor
 * @see org.hibernate.property.DirectPropertyAccessor.DirectSetter
 */
public class SafeDirectPropertyAccessor extends DirectPropertyAccessor {
	/**
	 * 
	 * TODO <BR>
	 * 
	 * @since Administrator@Dec 18, 2008
	 */
	public static final class DirectSetter implements Setter {
		/**
		 *
		 */
		private static final long serialVersionUID = 1L;
		/**
		 *
		 */
		private final transient Field field;
		/**
		 *
		 */
		private final Class<?> clazz;
		/**
		 *
		 */
		private final String name;

		/**
		 * 
		 * @param field
		 * @param clazz
		 * @param name
		 */
		DirectSetter(Field field, @SuppressWarnings("rawtypes") Class clazz,
				String name) {
			this.field = field;
			this.clazz = clazz;
			this.name = name;
		}
		public Method getMethod() {
			return null;
		}
		public String getMethodName() {
			return null;
		}
		public void set(Object target, Object value, SessionFactoryImplementor factory) throws HibernateException {

			// ls@2005-12-17 improve for primitive field: avoid Exception when
			// the column value is null in db.
			if (value == null && field.getType().isPrimitive()) {
				return;
			}

			try {
				field.set(target, value);
			}
			catch (Exception e) {
				throw new PropertyAccessException(e, "could not set a field value by reflection", true, clazz, name);
			}
		}

		@Override
		public String toString() {
			return "DirectSetter(" + clazz.getName() + '.' + name + ')';
		}

		/*
		Object readResolve() {
			return new DirectSetter( getField(clazz, name), clazz, name );
		}
		*/
	}

	private static Field getField(@SuppressWarnings("rawtypes") Class clazz,
			String name) throws PropertyNotFoundException {
		if ( clazz==null || clazz==Object.class ) {
			throw new PropertyNotFoundException("field not found: " + name); // TODO: we should report what class we started searching for the property - right now it will always end on Object.class.
		}
		Field field;
		try {
			field = clazz.getDeclaredField(name);
		}
		catch (NoSuchFieldException nsfe) {
			field = getField( clazz.getSuperclass(), name );
		}
		if (!ReflectHelper.isPublic(clazz, field))
			field.setAccessible(true);
		return field;
	}

	@Override
	public Setter getSetter(@SuppressWarnings("rawtypes") Class theClass,
			String propertyName)
		throws PropertyNotFoundException {
		return new DirectSetter( getField(theClass, propertyName), theClass, propertyName );
	}

}
