/*
 * Created: Administrator@Oct 26, 2010 2:05:36 PM
 */
package com.trs.dev4.jdk16.mina.impl;

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trs.dev4.jdk16.mina.IMessage;
import com.trs.dev4.jdk16.mina.IMessageHandler;

/**
 * 职责: 消息服务会话Handler<br>
 * 
 */
public class MessageServerSessionHandler extends IoHandlerAdapter {

	/**
	 * 日志logger
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private final static Logger logger = LoggerFactory
			.getLogger(MessageServerSessionHandler.class);

	/**
	 * 将要注入的消息句柄map
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private Map<String, IMessageHandler> messageHandlers;

	/**
	 * 接收的消息条数
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private int receivedCount = 0;

	/**
	 * 默认的存储条数
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private int divisor = 10;

	/**
	 * 消息处理总用时
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private long totalTime = 0;

	/**
	 * 最近几条消息
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private IMessage[] recentMessages;

	/**
	 * 最耗时消息
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private SortedMap<Long, IMessage> maxTimeMessages;

	/**
	 * 失败的几条消息
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private IMessage[] failedMessages;

	/**
	 * 构造函数， 初始化数据
	 */
	public MessageServerSessionHandler() {
		this.recentMessages = new IMessage[this.divisor];
		this.failedMessages = new IMessage[this.divisor];
		this.maxTimeMessages = new TreeMap<Long, IMessage>();
	}

	/**
	 * 记录最近的几条消息
	 * 
	 * @param message
	 *            消息
	 * @since dujie @ Oct 29, 2010
	 */
	public void updateRecentMessages(IMessage message) {
		int position = this.receivedCount % this.divisor;
		this.recentMessages[position] = message;
	}

	/**
	 * 最近失败的消息
	 * 
	 * @param message
	 *            消息
	 * @since dujie @ Oct 29, 2010
	 */
	public void updateFailedMessages(IMessage message) {
		this.failedMessages[this.receivedCount % this.divisor] = message;
	}

	/**
	 * 储存最耗时的消息
	 * 
	 * @param message
	 *            消息
	 * @param time
	 *            执行时间
	 * @since dujie @ Oct 29, 2010
	 */
	public void updateMaxTimeMassages(IMessage message, long time) {

		try {
			if (this.maxTimeMessages.isEmpty()) {
				this.maxTimeMessages.put(time, message);
			} else if (this.maxTimeMessages.size() < this.divisor) {
				this.maxTimeMessages.put(time, message);
			} else if (this.maxTimeMessages.lastKey() < time) {
				this.maxTimeMessages.remove(this.maxTimeMessages.firstKey());
				this.maxTimeMessages.put(time, message);
			}
		} catch (NoSuchElementException e) {
			logger.error("Method maxTimeMassages Exception: " + e.getMessage(),
					e);
		}
	}

	/**
	 * @see org.apache.mina.core.service.IoHandlerAdapter#messageReceived(org.apache.mina.core.session.IoSession,
	 *      java.lang.Object)
	 * @since dujie @ Oct 26, 2010
	 */
	@Override
	public void messageReceived(IoSession session, Object message) {
		// 消息处理开始时间
		long beginTime = System.currentTimeMillis();

		IMessage am = (IMessage) message;
		// 记录最近接受的消息
		this.updateRecentMessages(am);
		// 记录总共的条数
		this.receivedCount++;

		Map<String, IMessageHandler> messageHandlers = this.messageHandlers;

		IMessageHandler messageHandler = messageHandlers.get(am.getClass()
				.getName());

		IMessage mr = messageHandler.messageReceived(am);

		try {
			session.write(mr);
		} catch (RuntimeException e) {
			// 记录失败的消息
			this.updateFailedMessages(am);
			logger.error("MessageServerSessionHandler write failure:"
					+ e.getMessage(), e);
		}
		// 消息处理结束时间
		long endTime = System.currentTimeMillis();
		// 消息处理时间
		long costTime = endTime - beginTime;
		// 计算消息处理用时最长的几条
		this.updateMaxTimeMassages(am, costTime);
		// 计算总用时
		this.totalTime = totalTime + costTime;

	}

	/**
	 * @see org.apache.mina.core.service.IoHandlerAdapter#exceptionCaught(org.apache.mina.core.session.IoSession,
	 *      java.lang.Throwable)
	 * @since dujie @ Oct 26, 2010
	 */
	@Override
	public void exceptionCaught(IoSession session, Throwable cause) {
		logger.error("ServerSessionHandler exception:" + cause.getMessage(),
				cause);
		session.close(true);
	}

	/**
	 * @return the {@link #messageHandlers}
	 */
	public Map<String, IMessageHandler> getMessageHandlers() {
		return messageHandlers;
	}

	/**
	 * @param messageHandlers
	 *            the {@link #messageHandlers} to set
	 */
	public void setMessageHandlers(Map<String, IMessageHandler> messageHandlers) {
		this.messageHandlers = messageHandlers;
	}

	/**
	 * @return the {@link #divisor}
	 */
	public int getDivisor() {
		return divisor;
	}

	/**
	 * @param divisor
	 *            the {@link #divisor} to set
	 */
	public void setDivisor(int divisor) {
		if (divisor != 0) {
			this.divisor = divisor;
		}
	}

}
