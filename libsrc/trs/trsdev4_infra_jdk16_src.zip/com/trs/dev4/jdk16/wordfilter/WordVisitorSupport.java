/*
 * Created: TRS@Mar 3, 2011 5:40:41 PM
 */
package com.trs.dev4.jdk16.wordfilter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dom4j.Element;
import org.dom4j.VisitorSupport;

import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 *
 */
public class WordVisitorSupport extends VisitorSupport {
	/**
	 * 
	 */
	protected static final Logger LOG = Logger
			.getLogger(WordVisitorSupport.class);
	/**
	 * 
	 */
	LinkedList<String> groupNames = new LinkedList<String>();
	/**
	 * 
	 */
	LinkedList<String> groupNamesWithSystem = new LinkedList<String>();
	/**
	 * 
	 */
	Element root;
	/**
	 * 
	 */
	IWordFilter wordFilter;
	/**
	 * 
	 */
	Map<String, Dictionary> dicMap = new HashMap<String, Dictionary>();

	public WordVisitorSupport(Element root, IWordFilter wordFilter) {
		this.root = root;
		this.wordFilter = wordFilter;
		//
		root.accept(this);
	}

	@Override
	public void visit(Element element) {

		// 加载systemGroup
		if (element.getName().equalsIgnoreCase(Word.WORD_SYSTEM_GROUP)) {
			dicMap.put(WordFilterImpl.SYSTEM_GROUP_DIC_NAME,
					XML2Dictionary(wordFilter.getSystemDictionary(), root,
							element));
			groupNamesWithSystem.addLast(WordFilterImpl.SYSTEM_GROUP_DIC_NAME);
			if (LOG.isDebugEnabled()) {
				LOG.debug("加载系统过滤词典:" + WordFilterImpl.SYSTEM_GROUP_DIC_NAME);
			}
		}

		// 加载普通group 不 追加系统过滤词典
		if (element.getName().equalsIgnoreCase(Word.WORD_GROUP)) {
			String keyId = element.attributeValue(Word.WORD_ID);
			dicMap.put(keyId,
					XML2Dictionary(new Dictionary(keyId), root, element));
			groupNames.addLast(keyId);
			groupNamesWithSystem.addLast(keyId);
			if (LOG.isDebugEnabled()) {
				LOG.debug("加载自定义过滤词典:" + keyId);
			}
		}
	}

	/** 将XML词典文件转化为有效词典对象 */
	private Dictionary XML2Dictionary(Dictionary dic, Element root,
			Element element) {

		for (Iterator<?> iter = element.elementIterator(); iter.hasNext();) {
			Element iElement = (Element) iter.next();
			String level = iElement.attributeValue(Word.WORD_LEVEL);
			String word = iElement.getText();
			String color = iElement.attributeValue(Word.WORD_COLOR);
			boolean isFuzzy = StringHelper.isNotEmpty(iElement.attributeValue(Word.WORD_ISFUZZY))
					&& StringHelper.equalIngoreCaseAndSpace(iElement.attributeValue(Word.WORD_ISFUZZY), "true");
			boolean isReplacement = StringHelper.isNotEmpty(iElement.attributeValue(Word.WORD_ISREPLACEMENT))
					&& StringHelper.equalIngoreCaseAndSpace(iElement.attributeValue(Word.WORD_ISREPLACEMENT), "true");
			String replacement = iElement.attributeValue(Word.WORD_REPLACEMENT) == null ? "" : iElement.attributeValue(Word.WORD_REPLACEMENT);
			
			if (word == null) {
				LOG.warn("detected a null filterword:" + word + "; dictionary:"
						+ dic.toString());
				continue;
			}

			StringBuffer sb = new StringBuffer(word.length() * 2);
			for (int i = 0; i < word.length(); i++) {
				char c = word.charAt(i);

				if (c < 65535 && !wordFilter.ingoreChar(c)) { // 过滤词的字符为有效的过滤词字符
					sb.append(c);
				}
			}

			if (WordFilterImpl.isBlank(color))
				color = element.attributeValue(Word.WORD_COLOR);
			if (WordFilterImpl.isBlank(color))
				color = root.attributeValue(Word.WORD_COLOR);
			if (WordFilterImpl.isBlank(color))
				color = "red";

			dic.addWord(sb.toString(), NumberUtil.parseInt(level), color, isFuzzy, isReplacement, replacement);
		}
		return dic;
	}

	/**
	 * @return the {@link #dicMap}
	 */
	public Map<String, Dictionary> getDicMap() {
		return dicMap;
	}

	/**
	 * @return the {@link #groupNames}
	 */
	public LinkedList<String> getGroupNames() {
		return groupNames;
	}

	/**
	 * @return the {@link #groupNamesWithSystem}
	 */
	public LinkedList<String> getGroupNamesWithSystem() {
		return groupNamesWithSystem;
	}
}
