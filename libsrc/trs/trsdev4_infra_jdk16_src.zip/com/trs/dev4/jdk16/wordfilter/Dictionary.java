package com.trs.dev4.jdk16.wordfilter;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * @描述 过滤词引擎- 过滤词典实体对象
 * @作者 liang.xu
 * @创建时间 2006-7-10
 */
final class Dictionary {
	/**
	 * 过滤词典索引数组
	 */
	private Word[] m_fwl = null;
	/**
	 * 过滤词列表
	 */
	private List<String> words = new ArrayList<String>();
	/**
	 * 过滤词组颜色
	 */
	private String color = "red";
	/**
	 * 过滤词组等级
	 */
	private int level = 0;
	/** Log4j */
	protected static final Logger LOG = Logger.getLogger(WordFilterImpl.class);
	/**
	 * 过滤词组名
	 */
	private String groupName;

	public Dictionary(String groupName) {
		this.groupName = groupName;
		this.m_fwl = new Word[65535];
	}

	public Dictionary(String groupName, Word[] words) {
		this.groupName = groupName;
		this.m_fwl = words.clone();
	}

	// 词典是否为空
	private boolean isEmpty = true;

	public boolean isEmpty() {
		return isEmpty;
	}

	/**
	 * 增加新的过滤词。将所有字母换成小写。
	 * 
	 * @param p_word
	 *            要加入的过滤词
	 */
	public void addWord(String p_word, int level, String color) {
		addWord(p_word, level, color, false, false, "");
	}
	
	private List<Word> fuzzyWords = new ArrayList<Word>();
	
	private List<Word> replacementWords = new ArrayList<Word>();

	public void addWord(String p_word, int level, String color, boolean isFuzzy, boolean isReplacement, String replacement) {

		if (!StringHelper.isEmpty(p_word)) {
			p_word = p_word.toLowerCase().trim();

			int index = p_word.charAt(0);

			Word word = new Word();
			word.setWord(p_word);
			word.setGroup(this.groupName);
			word.setNext(this.m_fwl[index]);
			word.setLevel(level);
			word.setColor(color);
			word.setFuzzy(isFuzzy);
			word.setReplacement(isReplacement);
			word.setReplacement(replacement);
			this.m_fwl[index] = word;
			this.words.add(p_word);
			
			if (isFuzzy) {
				this.fuzzyWords.add(word);
			}
			
			if (isReplacement) {
				this.replacementWords.add(word);
			}

			// 设置词典包含过滤词
			isEmpty = false;

			if (LOG.isDebugEnabled()) {
				LOG.debug("加入过滤词:" + word);
			}
		}
	}


	/**
	 * 返回以指定的字符开始的过滤词列表, 如果没有返回 <code>null</code> 过滤词的第一个字母应该为小写
	 * 
	 * @param p_ch
	 *            过滤词的第一个字符
	 */
	public Word getWord(char p_ch) {
		return this.m_fwl[p_ch];
	}

	public Dictionary getCloneDic(String newGroupName) {
		return new Dictionary(newGroupName, this.m_fwl);
	}

	/**
	 * 获取过滤词列表
	 * 
	 * @return
	 */
	public String listWords() {
		StringBuilder sb = new StringBuilder();
		for ( Word word : m_fwl ){
			if (word == null)
				continue;
			//
			sb.append(word.getWord()).append("[").append(word.getLevel()).append("]").append(";");
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param word
	 * @return
	 * @since TRS @ Mar 2, 2011
	 */
	public boolean contains(String word) {
		return words.contains(word);
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Mar 2, 2011
	 */
	public List<String> listAllWords() {
		return words;
	}

	public void clear() {
		this.m_fwl = new Word[65535];
		this.isEmpty = true;
		this.words.clear();
		this.fuzzyWords.clear();
		this.replacementWords.clear();
	}

	/**
	 * 获取字典的过滤词数目
	 * 
	 * @return
	 * @since TRS @ Mar 2, 2011
	 */
	public int size() {
		return this.words.size();
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the {@link #color}
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color the {@link #color} to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the {@link #level}
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            the {@link #level} to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * @return the {@link #fuzzyWords}
	 */
	public List<Word> getFuzzyWords() {
		return fuzzyWords;
	}

	/**
	 * @return the {@link #replacementWords}
	 */
	public List<Word> getReplacementWords() {
		return replacementWords;
	}

	/**
	 * @param fuzzyWords
	 *            the {@link #fuzzyWords} to set
	 */
	public void setFuzzyWords(List<Word> fuzzyWords) {
		this.fuzzyWords = fuzzyWords;
	}

	/**
	 * @param replacementWords
	 *            the {@link #replacementWords} to set
	 */
	public void setReplacementWords(List<Word> replacementWords) {
		this.replacementWords = replacementWords;
	}
}
