package com.trs.dev4.jdk16.wordfilter;

/**
 * @描述 过滤词引擎- 过滤词实体对象
 * @作者 liang.xu
 * @创建时间 2006-7-10
 */
public class Word {

	/**
	 * 标识
	 */
	private int id;
	/**
	 * 组
	 */
	private String group;
	/**
	 * 过滤词
	 */
	private String word;
	/**
	 * 过滤级别
	 */
	private int level;
	/**
	 * 过滤颜色
	 */
	private String color;

	/**
	 * 是否模糊查询
	 * 
	 * @since yu.hongqi @ 2012-3-21
	 */
	private boolean isFuzzy;
	
	/**
	 * 替换的词语内容
	 * 
	 * @since yu.hongqi @ 2012-3-21
	 */
	private String replacement;

	/**
	 * 是否开启替换
	 * 
	 * @since yu.hongqi @ 2012-3-21
	 */
	private boolean isReplacement;

	/**
	 * 链表中下一节点
	 */
	private Word next;

	public static String WORD_COLOR = "color";
	public static String WORD_LEVEL = "level";
	public static String WORD_GROUP = "group";
	public static String WORD_ID = "id";
	public static String WORD_SYSTEM_GROUP = "systemGroup";
	public static String WORD_ISFUZZY = "isFuzzy";
	public static String WORD_REPLACEMENT = "replacement";
	public static String WORD_ISREPLACEMENT = "isReplacement";

	public Word getNext() {
		return next;
	}

	public void setNext(Word next) {
		this.next = next;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer(64);
		buff.append(word).append("/").append(level).append("/").append(color);
		return buff.toString();
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the {@link #isFuzzy}
	 */
	public boolean isFuzzy() {
		return isFuzzy;
	}

	/**
	 * @return the {@link #replacement}
	 */
	public String getReplacement() {
		return replacement;
	}

	/**
	 * @return the {@link #isReplacement}
	 */
	public boolean isReplacement() {
		return isReplacement;
	}

	/**
	 * @param isFuzzy
	 *            the {@link #isFuzzy} to set
	 */
	public void setFuzzy(boolean isFuzzy) {
		this.isFuzzy = isFuzzy;
	}

	/**
	 * @param replacement
	 *            the {@link #replacement} to set
	 */
	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}

	/**
	 * @param isReplacement
	 *            the {@link #isReplacement} to set
	 */
	public void setReplacement(boolean isReplacement) {
		this.isReplacement = isReplacement;
	}

}
