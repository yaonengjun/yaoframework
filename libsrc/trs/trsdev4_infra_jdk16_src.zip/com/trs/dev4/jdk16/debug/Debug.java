/*
 * Created: fangxiang@Nov 25, 2010 10:42:51 PM
 */
package com.trs.dev4.jdk16.debug;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 职责: <br>
 *
 */
@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Debug {

}
