/*
 * Created: fangxiang@Nov 25, 2010 10:44:21 PM
 */
package com.trs.dev4.jdk16.debug;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 职责: <br>
 *
 */
@Entity
@Table(name = "`DEBUGLOGS`")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_DEBUGLOG") })
public class Debuglog extends BaseEntity {

	/**
	 * @since fangxiang @ Nov 25, 2010
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	@Column(name="`CLASSNAME`")
	private String className;
	/**
	 *
	 */
	@Column(name = "`ARGUMENTS`")
	private String arguments;
	/**
	 *
	 */
	@Column(name = "`PARAMETERNAMES`")
	private String parameterNames;

	/**
	 *
	 */
	@Column(name="`METHODNAME`")
	private String methodName;

	/**
	 *
	 */
	@Column(name="`METHODSIG`")
	private String methodSignature;

	@Column(name="`RETURNVALUE`")
	private String returnValue;

	@Column(name="`RESULT`")
	private String result;

	@Column(name="`ELAPSED`")
	private int elapsed;

	/**
	 *
	 */
	@Column(name = "`ERRORMESSAGE`")
	private String errorMessage;

	/**
	 * @return the {@link #className}
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @param className
	 *            the {@link #className} to set
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * @return the {@link #methodName}
	 */
	public String getMethodName() {
		return methodName;
	}

	/**
	 * @param methodName
	 *            the {@link #methodName} to set
	 */
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	/**
	 * @return the {@link #methodSignatures}
	 */
	public String getMethodSignature() {
		return methodSignature;
	}

	/**
	 * @param methodSignatures
	 *            the {@link #methodSignatures} to set
	 */
	public void setMethodSignature(String methodSignature) {
		this.methodSignature = methodSignature;
	}

	/**
	 * @return the {@link #returnValue}
	 */
	public String getReturnValue() {
		return returnValue;
	}

	/**
	 * @param returnValue
	 *            the {@link #returnValue} to set
	 */
	public void setReturnValue(String returnValue) {
		this.returnValue = returnValue;
	}

	/**
	 * @return the {@link #result}
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result
	 *            the {@link #result} to set
	 */
	public void setResult(String result) {
		this.result = result;
	}

	/**
	 * @return the {@link #elapsed}
	 */
	public int getElapsed() {
		return elapsed;
	}

	/**
	 * @param elapsed
	 *            the {@link #elapsed} to set
	 */
	public void setElapsed(int elapsed) {
		this.elapsed = elapsed;
	}

	/**
	 * @return the {@link #errorMessage}
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the {@link #errorMessage} to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the {@link #arguments}
	 */
	public String getArguments() {
		return arguments;
	}

	/**
	 * @param arguments
	 *            the {@link #arguments} to set
	 */
	public void setArguments(String arguments) {
		this.arguments = arguments;
	}

	/**
	 * @return the {@link #parameterNames}
	 */
	public String getParameterNames() {
		return parameterNames;
	}

	/**
	 * @param parameterNames
	 *            the {@link #parameterNames} to set
	 */
	public void setParameterNames(String parameterNames) {
		this.parameterNames = parameterNames;
	}
}
