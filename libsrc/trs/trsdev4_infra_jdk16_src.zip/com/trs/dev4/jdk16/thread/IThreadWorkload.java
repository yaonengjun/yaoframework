/*
 * Created: fangxiang@Jan 8, 2011 10:07:10 AM
 */
package com.trs.dev4.jdk16.thread;

/**
 * 线程执行体
 */
public interface IThreadWorkload {
	/**
	 * 线程执行行为
	 * 
	 */
	public void onExecute();
}
