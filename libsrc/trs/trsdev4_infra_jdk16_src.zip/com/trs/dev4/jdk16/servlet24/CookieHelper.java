/*
 */
package com.trs.dev4.jdk16.servlet24;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.utils.UrlUtil;

/**
 * 存取Cookie的工具类. <BR>
 * 
 * @author TRS信息技术有限公司
 */
public class CookieHelper {

    private HttpServletRequest request;

    private HttpServletResponse response;

	private Map<String, Cookie> cookiesMap;

    private String cookiesHeader;

    private String domain;

	/**
	 * 初始化, 从request获取所有Cookie并保存到内部成员, 供后续高效获取.
	 * 
	 * @param request
	 * @param response
	 */
    public CookieHelper(HttpServletRequest request, HttpServletResponse response) {
        initCookieHelper(request, response);
        // TODO parse and save queryString
    }

	/**
	 * 初始化, 从request获取所有Cookie并保存到内部成员, 供后续高效获取.
	 * 
	 * @param request
	 *            HttpServletRequest 请求
	 * @param response
	 *            HttpServletResponse 请求
	 * @param domainLevel
	 *            cookie domain级别 TODO 详细说明不同值对应的域
	 */
    public CookieHelper(HttpServletRequest request, HttpServletResponse response,int domainLevel) {
    	initCookieHelper(request, response);
    	this.domain =UrlUtil.getDomainByLevel(request.getServerName(), domainLevel);
    }

	/**
	 * 初始化, 从request获取所有Cookie并保存到内部成员, 供后续高效获取.
	 * 
	 * @param request
	 *            HttpServletRequest 请求
	 * @param response
	 *            HttpServletResponse 请求
	 * @param domainLevel
	 *            cookie domain级别 TODO 详细说明不同值对应的域
	 */
	public CookieHelper(HttpServletRequest request,
			HttpServletResponse response, String domain) {
		initCookieHelper(request, response);
		this.domain = domain;
	}

	/**
	 * 初始化cookie Helper
	 * 
	 * @param request
	 * @param response
	 */
    private void initCookieHelper(HttpServletRequest request,
    		HttpServletResponse response) {
    	this.request = request;
    	this.response = response;

    	cookiesHeader = request.getHeader("Cookie");
    	Cookie[] cookies = request.getCookies();
    	if (cookies == null) {
			cookiesMap = Collections.emptyMap();
    	} else {
			cookiesMap = new HashMap<String, Cookie>(cookies.length);
    		for (int i = 0; i < cookies.length; i++) {
    			cookiesMap.put(cookies[i].getName(), cookies[i]);
    		}
    	}
    }

	/**
	 * 根据名称获取cookie
	 * 
	 * @param name
	 * @return
	 * @since lichuanjiao @ 2010-10-26
	 */
    public Cookie getCookie(String name) {
        return cookiesMap.get(name);
    }

	/**
	 * 获取cookie的值
	 * 
	 * @param name
	 * @return
	 * @since lichuanjiao @ 2010-10-26
	 */
    public String getValue(String name) {
        Cookie cookie = getCookie(name);
        if (cookie == null) {
            return null;
        }
        return cookie.getValue();
    }

	/**
	 * 删除cookie
	 * 
	 * @param name
	 * @since lichuanjiao @ 2010-10-26
	 */
    public void removeCookie(String name) {
        Cookie cookie = new Cookie(name, null);
        cookie.setMaxAge(0);
        cookie.setPath(getContextPath(request));
        response.addCookie(cookie);
    }

	/**
	 * 
	 * @param name
	 * @param path
	 * @param domain
	 * @since fangxiang @ Dec 13, 2010
	 */
    public void removeCookie(String name, String domain) {
        Cookie cookie = new Cookie(name, null);
        cookie.setMaxAge(0);
		cookie.setPath(getContextPath(request));
		if (false == StringHelper.isEmpty(domain)) {
        	cookie.setDomain(domain);
        }
        response.addCookie(cookie);
    }

	/**
	 * 
	 * @param name
	 * @param path
	 * @param domain
	 * @since fangxiang @ Dec 13, 2010
	 */
	public void removeCookie(String name, String path, String domain) {
		Cookie cookie = new Cookie(name, null);
		cookie.setMaxAge(0);
		cookie.setPath(path);
		if (false == StringHelper.isEmpty(domain)) {
			cookie.setDomain(domain);
		}
		response.addCookie(cookie);
	}

	/**
	 * 写入一个会话期Cookie.
	 * 
	 * @param name
	 * @param value
	 * @since ls@07-0604
	 */
	public void addCookie(String name, String value) {
        Cookie cookie = new Cookie(name, value);
		// cookie.setMaxAge(-1); // not store if setMaxAge(-1) in weblogic9.1,
		// result 【com.trs.ids.guest.blog Received null Thursday, 01-Jan-1970
		// 01:00:00 GMT】
		cookie.setPath(getContextPath(request));
        if(false == StringHelper.isEmpty(domain)) {
        	cookie.setDomain(domain);
        }
        response.addCookie(cookie);
	}

	/**
	 * 写入一个指定生存时间的cookie
	 * 
	 * @param name
	 *            cookie的名称
	 * @param value
	 *            cookie的值
	 * @param cookieAge
	 *            cookie在客户端的生存时间
	 * @since lichuanjiao @ 2010-10-28
	 */
	public void addCookie(String name, String value, int cookieAge) {
		Cookie cookie = new Cookie(name, value);
		cookie.setPath(getContextPath(request));
		cookie.setMaxAge(cookieAge);
		if (false == StringHelper.isEmpty(domain)) {
			cookie.setDomain(domain);
		}
		response.addCookie(cookie);
	}


	public String getCookieStrings() {
		StringBuffer sb = new StringBuffer(64 * cookiesMap.size());
		for (Iterator<String> iter = cookiesMap.keySet().iterator(); iter
				.hasNext();) {
			String name = iter.next();
			sb.append(name).append('=').append(cookiesMap.get(name)).append("; ");
		}
		return sb.toString();
	}

	/**
	 * Returns the {@link #request}.
	 * @return the request.
	 */
	public HttpServletRequest getRequest() {
		return request;
	}

	/**
	 * Returns the {@link #cookiesHeader}.
	 * @return the cookiesHeader.
	 */
	public String getCookiesHeader() {
		return cookiesHeader;
	}

	/**
	 * 根据request获取当前应用的上下文路径
	 * 
	 * @return
	 * @since 2008-06-25
	 */
	private String getContextPath(HttpServletRequest request) {
		String contextPath = request.getContextPath();
		if(contextPath == null || contextPath.length() == 0) {
			contextPath = "/";
		}
		return contextPath;
	}
}