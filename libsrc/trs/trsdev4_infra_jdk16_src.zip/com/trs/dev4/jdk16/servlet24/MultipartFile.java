/*
 * Created: liushen@Apr 9, 2010 1:50:18 PM
 */
package com.trs.dev4.jdk16.servlet24;

import java.io.File;

/**
 * 上传后的文件以及其信息.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class MultipartFile {

	private File file;
	private String originalFileName;

	/**
	 * 文件对应的表单域的名称.
	 */
	private String inputName;

	/**
	 * 
	 */
	MultipartFile(File file, String originalFileName, String inputName) {
		this.file = file;
		this.originalFileName = originalFileName;
		this.inputName = inputName;
	}

	/**
	 * Get the {@link #file}.
	 * 
	 * @return the {@link #file}.
	 */
	public File getFile() {
		return file;
	}

	/**
	 * Get the {@link #originalFileName}.
	 * 
	 * @return the {@link #originalFileName}.
	 */
	public String getOriginalFileName() {
		return originalFileName;
	}

	/**
	 * Get the {@link #inputName}.
	 * 
	 * @return the {@link #inputName}.
	 */
	public String getInputName() {
		return inputName;
	}

}
