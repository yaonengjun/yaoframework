/*
 * Created: liushen@Feb 19, 2010 1:07:45 AM
 */
package com.trs.dev4.jdk16.exception;

import com.trs.dev4.jdk16.model.ValidationErrors;

/**
 * 断言有效性检验通过，但却没有通过；主要用于保存新创建或修改对象前.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
@SuppressWarnings("serial")
public class ValidateAssertionException extends RootException {
	/**
	 *
	 */
	private ValidationErrors valiationErrors;
	/**
	 * @param msg
	 */
	public ValidateAssertionException(String msg) {
		super(msg);
	}

	/**
	 * @return the {@link #valiationErrors}
	 */
	public ValidationErrors getValiationErrors() {
		return valiationErrors;
	}

	/**
	 * @param valiationErrors
	 *            the {@link #valiationErrors} to set
	 */
	public void setValiationErrors(ValidationErrors valiationErrors) {
		this.valiationErrors = valiationErrors;
	}

}
