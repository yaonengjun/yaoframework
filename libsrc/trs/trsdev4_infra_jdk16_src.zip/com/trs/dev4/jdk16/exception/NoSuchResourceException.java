/*
 * Created: liushen@Mar 9, 2010 7:36:57 AM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 职责: <br>
 * 
 */
@SuppressWarnings("serial")
public class NoSuchResourceException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public NoSuchResourceException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public NoSuchResourceException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public NoSuchResourceException(Throwable cause) {
		super(cause);
	}

}
