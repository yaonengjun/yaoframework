/**
 * Created: liushen@Jan 31, 2010 3:03:51 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 进程执行相关的异常.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
@SuppressWarnings("serial")
public class ProcessException extends RootException {

	/**
	 * @see RootException#RootException(String)
	 */
	public ProcessException(String msg) {
		super(msg);
	}

	/**
	 * @see RootException#RootException(String, Throwable)
	 */
	public ProcessException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @see RootException#RootException(Throwable)
	 */
	public ProcessException(Throwable cause) {
		super(cause);
	}

}
