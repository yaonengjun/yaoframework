/*
 * Created: cl@2011-6-15 下午02:09:27
 */
package com.trs.dev4.jdk16.exception;

/**
 * 职责: 表示远程连接或访问失败<br>
 * 
 */
public class RemoteException extends RootException {

    /**
     * @param msg
     * @param cause
     */
    public RemoteException(String msg, Throwable cause) {
        super(msg, cause);
    }

    /**
     * @param msg
     */
    public RemoteException(String msg) {
        super(msg);
    }

    /**
     * @param cause
     */
    public RemoteException(Throwable cause) {
        super(cause);
    }

    /**
     * @since cl @ 2011-6-15
     */
    private static final long serialVersionUID = 1L;

}
