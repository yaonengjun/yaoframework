/*
 * Created: liushen@Jun 22, 2010 4:19:20 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 反射操作的相关异常. <br>
 * 
 */
@SuppressWarnings("serial")
public class ReflectException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public ReflectException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public ReflectException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public ReflectException(Throwable cause) {
		super(cause);
	}

}
