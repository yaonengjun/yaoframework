/*
 * Created: liushen@Feb 7, 2010 5:14:24 PM
 */
package com.trs.dev4.jdk16.exception;

import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.utils.ArrayUtil;

/**
 * 异常及堆栈相关的工具方法.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ExceptionUtil {

	/**
	 * 从给定异常中获取所有调用堆栈信息.
	 * 
	 * @see #getStackTrace(Throwable, String)
	 * @since liushen @ Feb 7, 2010
	 */
	public static String getStackTrace(Throwable t) {
		return getStackTrace(t, null);
	}

	/**
	 * 从给定异常中获取所有以com.trs为开始的调用堆栈信息.
	 * 
	 * @see #getStackTrace(Throwable, String)
	 * @since liushen @ Mar 25, 2010
	 */
	public static String getStackTraceOnlyTRS(Throwable t) {
		return getStackTrace(t, "com.trs.");
	}

	/**
	 * 获取异常最主要的信息, 包括异常的信息和出现位置.
	 * 
	 * @param exception
	 *            异常
	 * @return a string representation of this throwable.
	 * @since liushen @ Mar 19, 2010
	 */
	public static String getBrief(Throwable exception) {
		if (exception == null) {
			return "";
		}
		String message = exception.getMessage();
		String topTrace = getMainCaller(exception, 1);
		String simpleExName = exception.getClass().getSimpleName();
		message = (message == null || message.trim().length() == 0) ? simpleExName
				: simpleExName + ": " + message;
		return message + " at " + topTrace;
	}

	/**
	 * 获取当前调用堆栈中的主调用者（类、方法名、文件、行号），其中本类被排除在外.
	 * 
	 * @see #getMainCaller(int)
	 * @since liushen @ Mar 25, 2010
	 */
	public static String getMainCaller() {
		return getMainCaller(1);
	}

	/**
	 * 获取当前调用堆栈中的主要几个调用者（类、方法名、文件、行号），其中本类被排除在外.
	 * 
	 * @see #getMainCaller(Throwable, int)
	 * @since liushen @ Mar 25, 2010
	 */
	public static String getMainCaller(int amount) {
		Exception currStackTrace = new Exception();
		return getMainCaller(currStackTrace, amount);
	}

	/**
	 * 获取给定的调用堆栈中的主要几个调用者（类、方法名、文件、行号）.
	 * 
	 * @see #subStackTraceAsStr(Throwable, int, Class...)
	 * @since liushen @ May 23, 2010
	 */
	public static String getMainCaller(Throwable exception, int topNum) {
		return subStackTraceAsStr(exception, topNum, new Class<?>[0]);
	}

	/**
	 * 获取给定调用堆栈中的主调用者（类、方法名、文件、行号），其中给定的类被排除在外.
	 * 
	 * @see #subStackTraceAsStr(Throwable, int, Class...)
	 * @since liushen @ May 23, 2010
	 */
	public static String getMainCaller(Throwable exception, Class<?>... classes) {
		return subStackTraceAsStr(exception, 1, classes);
	}

	/**
	 * 从给定异常中获取其中仅包含给定的包或者类的调用堆栈信息.
	 * 
	 * @since liushen @ Feb 7, 2010
	 * @see
	 */
	public static String getStackTrace(Throwable t, String prefixInclude) {
		return subStackTraceOnlyForPrefix(t, 0, prefixInclude);
	}

	/**
	 * 从给定异常中获取其中仅包含给定的包或者类的调用堆栈信息.
	 * 
	 * @param t
	 *            给定的调用堆栈
	 * @param prefixInclude
	 *            仅包含以此为起始的
	 * @return 字符串表示的调用堆栈信息
	 * @since liushen @ Jun 1, 2012
	 */
	public static String subStackTraceOnlyForPrefix(Throwable t, int topNum, String... prefixsInclude) {
		if (t == null) {
			return "";
		}
		StackTraceElement[] stacks = t.getStackTrace();
		// liushen@May 9, 2012: 堆栈的长度可能为0
		if (stacks.length == 0) {
			return "JVM not provided the stack trace: " + t.getClass().getName();
		}
		List<StackTraceElement> topST = new ArrayList<StackTraceElement>();
		List<StackTraceElement> matchedST = new ArrayList<StackTraceElement>();
		// List<StackTraceElement> bottomST = new
		// ArrayList<StackTraceElement>();
		
		int indexOfTopMatch = 0;
		if (prefixsInclude.length > 0) {
			for (int i = 0; i < stacks.length; i++) {
				if (ArrayUtil.prefixMatch(prefixsInclude, stacks[i].getClassName())) {
					indexOfTopMatch = i;
					break;
				}
				topST.add(stacks[i]);
			}
		}

		for (int i = indexOfTopMatch, j = 1; i < stacks.length; i++, j++) {
			matchedST.add(stacks[i]);
			if (j == topNum) {
				break;
			}
		}

		int matchedSize = matchedST.size();
		StringBuilder sb = new StringBuilder(matchedSize * 64);
		int beforeSize = topST.size();
		if (beforeSize > 0) {
			sb.append("(").append(beforeSize).append(" topper)");
		}
		for (int i = 0; i < matchedSize; i++) {
			StackTraceElement st = matchedST.get(i);
			sb.append(st.getClassName()).append("#").append(st.getMethodName()).append(":").append(st.getLineNumber());
			if (i < matchedSize - 1) {
				sb.append(" <- ");
			}
		}
		return sb.toString();
	}

	/**
	 * 获取给定的调用堆栈中的主要几个调用者（类、方法名、文件、行号），其中给定的类被排除在外.
	 * 
	 * @param exception
	 *            给定的调用堆栈
	 * @param topNum
	 *            要获取栈帧的数目
	 * @param classes
	 *            要排除的类构成的数组(可变长参数)
	 * @return 字符串表示的调用信息，包括类、方法名、文件、行号
	 * @since liushen @ Mar 25, 2010
	 */
	public static String subStackTraceAsStr(Throwable exception, int topNum,
			Class<?>... classes) {
		if (exception == null) {
			return "";
		}
		StackTraceElement[] stacks = exception.getStackTrace();
		if (stacks.length == 0) {
			return "JVM not provided the stack trace";
		}
		StringBuilder sb = new StringBuilder(topNum * 64);

		String topClass = stacks[0].getClassName();

		int startIndex = 0;
		// 计算startIndex: 利用两次循环，从顶排除掉本类以及传入的指定类(一般是被调用的类).
		if (topClass.equals(ExceptionUtil.class.getName())) {
			for (int i = 0; i < stacks.length; i++) {
				String currClassName = stacks[i].getClassName();
				if (currClassName.equals(ExceptionUtil.class.getName())) {
					continue;
				} else {
					startIndex = i;
					break;
				}
			}
		}
		if (stacks.length <= startIndex) {
			return "No stacks after trimming.";
		}
		String targetClass = stacks[startIndex].getClassName();
		for (int j = 0; j < classes.length; j++) {
			Class<?> clazz = classes[j];
			String trimTarget = (clazz == null) ? targetClass : clazz.getName();
			for (int i = startIndex; i < stacks.length; i++) {
				String currClassName = stacks[i].getClassName();
				if (currClassName.startsWith(trimTarget)) {
					continue;
				} else {
					startIndex = i;
					break;
				}
			}
		}
		// startIndex计算完毕
		int endIndex = (stacks.length < startIndex + topNum) ? stacks.length
				: startIndex + topNum;

		// com.trs.mam.model.process.AssetFileAccessor.computeTimepoints(AssetFileAccessor.java:137)
		// getClassName() + "." + methodName +
		// (isNativeMethod() ? "(Native Method)" :
		// (fileName != null && lineNumber >= 0 ?
		// "(" + fileName + ":" + lineNumber + ")" :
		// (fileName != null ? "("+fileName+")" : "(Unknown Source)")));
		for (int i = startIndex; i < endIndex - 1; i++) {
			sb.append(stacks[i]);
			sb.append(" <- ");
		}
		sb.append(stacks[endIndex - 1]);
		return sb.toString();
	}

	/**
	 * 友好地显示异常对象的错误信息，主要用于Web前台.
	 * 
	 * @param exception
	 *            异常对象
	 * @since liushen @ Jul 1, 2011
	 */
	public static String friendlyShow(Throwable exception) {
		return friendlyShow(exception, "com.trs.");
	}

	/**
	 * 友好地显示异常对象的错误信息，包括错误信息和一个最主要的代码行信息；主要用于Web前台.
	 * 
	 * @param exception
	 *            异常对象
	 * @param prefixsInclude
	 *            只从哪些前缀的包名或类名中去找最主要的代码行信息
	 * @return 友好描述该异常的字符串
	 * @since liushen @ Jun 1, 2012
	 */
	public static String friendlyShow(Throwable exception, String... prefixsInclude) {
		if (exception == null) {
			return "";
		}
		String message = exception.getLocalizedMessage();

		return message + "(" + subStackTraceOnlyForPrefix(exception, 1, prefixsInclude) + ")";
	}

}
