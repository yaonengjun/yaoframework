/*
 * Created: liushen@Jan 18, 2011 10:13:46 AM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 配置异常。<br>
 * 
 */
@SuppressWarnings("serial")
public class ConfigException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public ConfigException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public ConfigException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public ConfigException(Throwable cause) {
		super(cause);
	}

}
