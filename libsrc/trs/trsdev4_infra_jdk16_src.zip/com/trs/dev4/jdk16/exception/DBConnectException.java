/*
 * Created: liushen@Jul 1, 2011 9:14:29 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 数据库连接异常. <br>
 * 
 */
@SuppressWarnings("serial")
public class DBConnectException extends RootException {

	/**
	 * @param msg
	 */
	public DBConnectException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param cause
	 */
	public DBConnectException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param cause
	 */
	public DBConnectException(Throwable cause) {
		super(cause);
	}

}
