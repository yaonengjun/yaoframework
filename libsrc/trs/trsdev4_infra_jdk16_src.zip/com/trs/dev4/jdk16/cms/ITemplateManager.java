/*
 * created by TRS @ Jan 21, 2011
 *
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 模板管理器
 * 
 * @author TRS
 */
public interface ITemplateManager extends IBaseManager<Template> {
	/**
	 * 获取模板对象
	 * 
	 * @param name
	 * @return
	 * @since TRS @ Feb 12, 2011
	 */
	Template getTemplate(String templateName);

	/**
	 * 获取解析后的模板
	 * 
	 * @param templateName
	 * @return
	 * @since TRS @ Feb 16, 2011
	 */
	TemplateDocument getTemplateDocument(String templateName);

	/**
	 * 直接解析模板
	 * 
	 * @param templateContent
	 * @return
	 * @since TRS @ Feb 16, 2011
	 */
	TemplateDocument parseTemplateDocument(String templateContent);

	/**
	 * 根据ObjectId和ObjectType获取模板对象
	 * @param objectType 模板类型
	 * @param objectId 模板ID
	 * @return
	 */
	Template getTemplateByObjectType(String objectType,int objectId);

}
