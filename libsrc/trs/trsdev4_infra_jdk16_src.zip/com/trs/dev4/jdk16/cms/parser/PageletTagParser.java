package com.trs.dev4.jdk16.cms.parser;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.http.PureClient;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

public class PageletTagParser implements ITagParser, ApplicationContextAware {
	
	private IContentGenerator contentGenerator;
	
	private ICacheServer cacheServer;

	public PageletTagParser() {

	}

	public PageletTagParser(IContentGenerator contentGenerator) {
		this.contentGenerator = contentGenerator;
	}
	
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_PAGELET", "generate ad", BodyType.HTML);
	}
    
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {

		if (contentGenerator != null) {
			String templateName = tagContext.getAttribute("templateName");
			String loginedTemplateName = tagContext.getAttribute("loginedTemplateName", "");
			String cssAttr = tagContext.getAttribute("css");
			String src = tagContext.getAttribute("src");
			int cacheTime = tagContext.getAttribute("cacheTime", 0);
			
			StringBuilder sb = new StringBuilder();
			
			if (!StringHelper.isEmpty(cssAttr)) {
				String[] csses = StringHelper.split(cssAttr, ";");
				for (String css : csses) {
					sb.append("<link href=\"").append(css).append("\" rel=\"stylesheet\" type=\"text/css\" />");
				}
			}

			// 登录情况
			if (!StringHelper.isEmpty(loginedTemplateName) && tagContext.getPageContext().isLogined()) {
				return sb.append(contentGenerator.generate(loginedTemplateName, tagContext.getPageContext())).toString();
			}

			// 未登录状态
			else if (!StringHelper.isEmpty(templateName)) {
				if (cacheServer != null && cacheTime > 0) {
					RequestContext requestContext = tagContext.getPageContext().getRequestContext();
					
					String key = "templateContent_" + templateName + (requestContext == null ? "" : requestContext.getQueryString());
					Object content = cacheServer.get(key);
					if (content == null) {
						content = sb.append(contentGenerator.generate(templateName, tagContext.getPageContext())).toString();
						cacheServer.set(key, cacheTime, content);
					} 
					return (String) content;
				} else {
					return sb.append(contentGenerator.generate(templateName, tagContext.getPageContext())).toString();									
				}
			} else if (!StringHelper.isEmpty(src)) {
				return PureClient.get(src).getResponseBodyAsTrimStr();
			} else {
				return TagParserUtils.writeError("TRS_Pagelet置标至少需要指定templateName或者src属性。");
			}
		} else {
			return "contentGenerator is not init!!!";
		}
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since yangyu @ 2012-6-3
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if (applicationContext.containsBean("contentGenerator")) {
			contentGenerator = (IContentGenerator) applicationContext.getBean("contentGenerator");
		}
	}

	public ICacheServer getCacheServer() {
		return cacheServer;
	}

	public void setCacheServer(ICacheServer cacheServer) {
		this.cacheServer = cacheServer;
	}
	
}
