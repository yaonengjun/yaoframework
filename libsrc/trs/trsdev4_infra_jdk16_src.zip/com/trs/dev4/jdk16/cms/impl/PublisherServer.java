/*
 * created by TRS @ Jan 21, 2011
 *
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ICMSPublisher;
import com.trs.dev4.jdk16.cms.IContentProvider;
import com.trs.dev4.jdk16.cms.IPublisherServer;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IModuleLifecycle;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * @author TRS
 * 
 */
public class PublisherServer implements IPublisherServer, IModuleLifecycle,
		IConfigurable {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(PublisherServer.class);
	/**
	 * 
	 */
	private static final String CONFIG_OUTPUT_DIR = "publish.dir";
	/**
	 * 
	 */
	private ICMSPublisher publisher;
	/**
	 * 
	 */
	private String outputDirectory;
	/**
	 * 
	 */
	private List<PublisherJob> publisherJobs = new ArrayList<PublisherJob>();
	/**
	 * 
	 */
	@Resource(name = "configurationManager")
	private IConfigurationManager configurationManager;

	/**
	 * @see com.trs.uc.service.IPublisherServer#publish(java.lang.String,
	 *      java.util.Map, java.lang.String)
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public void publish(String templateName, Map<String, Object> inputObjects,
			String fileName) {
		publisher.publish(templateName, inputObjects, outputDirectory
				+ fileName);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public String getPrefix() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public void refreshConfigs() {
		outputDirectory = StringHelper
				.smartAppendSlashToEnd(configurationManager.getConfiguration(
						this, CONFIG_OUTPUT_DIR));

	}

	/**
	 * 执行发布任务
	 * 
	 * @since fangxiang @ Jan 21, 2011
	 */
	void doPublish() {
		List<PublisherJob> executedJobs = new ArrayList<PublisherJob>();
		while (this.publisherJobs.size() > 0) {
			PublisherJob job = publisherJobs.remove(0);
			// 执行
			job.publish();
			//
			if (job.getDuration() > 0) {
				executedJobs.add(job);
			}
		}
		//
		if (executedJobs.size() > 0) {
			publisherJobs.addAll(executedJobs);
		}
	}

	/**
	 * 构造配置描述的消息Key
	 * 
	 * @return
	 * @since TRS@Jan 9, 2011
	 */
	protected String buildConfigurationDescMessageKey(String configurationKey) {
		return (this.getPrefix() + "." + configurationKey + ".desc")
				.toLowerCase();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public String getModuleName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public void start() {
		initConfigurations();
		refreshConfigs();
		//
		/*
		 * DaemonThreadFactory.getInstance().startThread("Publisher.THREAD", 60,
		 * new IThreadWorkload() {
		 * 
		 * @Override public void onExecute() { doPublish(); } });
		 */
	}

	/**
	 * 
	 * @since TRS@Jan 21, 2011
	 */
	private void initConfigurations() {
		// 用户访问路径，支持泛域名
		if (!configurationManager.existsOrConfigured(this, CONFIG_OUTPUT_DIR)) {
			String classPath = this.getClass().getClassLoader().getResource("")
					.getPath();
			configurationManager.addConfigKey(this, CONFIG_OUTPUT_DIR, "发布文件夹",
					buildConfigurationDescMessageKey(CONFIG_OUTPUT_DIR),
					classPath);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public void stop() {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since TRS@Jan 21, 2011
	 */
	@Override
	public void restart() {

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IPublisherServer#publish(java.lang.String,
	 *      com.trs.dev4.jdk16.cms.IContentProvider, java.util.Map, int)
	 * @since fangxiang @ Jan 21, 2011
	 */
	@Override
	public void publish(String templateName, IContentProvider contentProvider,
			Map<String, Object> parameters, int duration) {
		PublisherJob job = new PublisherJob();
		job.setDuration(duration);
		job.setParameters(parameters);
		job.setTemplateName(templateName);
		job.setContentProvider(contentProvider);
		job.setPublisher(publisher);
		job.setOutputDirectory(outputDirectory);
		//
		publisherJobs.add(job);
		//
		logger.debug("PublisherJob(" + job + ") built successfully.");
	}

	/**
	 * @param publisher
	 *            the {@link #publisher} to set
	 */
	public void setPublisher(ICMSPublisher publisher) {
		this.publisher = publisher;
	}

	/**
	 * @param configurationManager
	 *            the {@link #configurationManager} to set
	 */
	public void setConfigurationManager(
			IConfigurationManager configurationManager) {
		this.configurationManager = configurationManager;
	}
}
