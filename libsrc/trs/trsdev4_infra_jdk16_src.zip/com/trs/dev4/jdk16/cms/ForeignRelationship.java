/**
 * 
 */
package com.trs.dev4.jdk16.cms;

/**
 * 定义对象属性与其关联对象之间的关系，比如:post里面的CreateUserId 是和 user对象的ID关联的
 * @author yu.hongqi
 *
 */
public class ForeignRelationship {

	private String objectName;
	private String attributeName;
	private Class<?> tagAwareClass;
	
	public String getAwareClassName(){
		return tagAwareClass.getSimpleName();
	}
	
	protected ForeignRelationship(){}
	
	public ForeignRelationship(Class<?> tagAwareClass,String objectName,String attributeName){
		this.attributeName =attributeName;
		this.objectName = objectName;
		this.tagAwareClass = tagAwareClass;
	}


	/**
	 * @return the objectName
	 */
	public String getObjectName() {
		return objectName;
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}


	/**
	 * @return the tagAwareClass
	 */
	public Class<?> getTagAwareClass() {
		return tagAwareClass;
	}
}
