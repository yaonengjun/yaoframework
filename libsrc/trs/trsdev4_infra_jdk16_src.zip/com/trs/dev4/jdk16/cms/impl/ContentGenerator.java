/*
 * Created: TRS@Feb 12, 2011 9:40:34 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.map.UnmodifiableMap;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ForeignRelationship;
import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.ITemplateManager;
import com.trs.dev4.jdk16.cms.PageContext;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.TemplateDocument;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.HtmlCompressor;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 负责内容解析和生成，实现{@link IContentGenerator}
 * 
 */
public class ContentGenerator implements IContentGenerator {

	private static final Logger LOG = Logger.getLogger(ContentGenerator.class);

	/**
	 * 管理置标和ITagParser之间的关系
	 */
	private Map<String, ITagParser> parsers = new HashMap<String, ITagParser>();
	/**
	 * 管理对象和ITagAware之间的关系
	 */
	private Map<String, ITagAware> tagAwares = new HashMap<String, ITagAware>();

	private ITemplateManager templateManager;

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#getParser(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public ITagParser getParser(String tagName) {
		return parsers.get(tagName);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#getAware(java.lang.String)
	 */
	@Override
	public ITagAware getAware(String obj) {
		return tagAwares.get(obj);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#registerParser(com.trs.dev4.jdk16.cms.ITagParser)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void registerParser(ITagParser tagParser) {
		if (tagParser == null) {
			return;
		}

		String name = tagParser.getBeanInfo().getName();
		ITagParser prevRegistered = parsers.get(name);
		if (prevRegistered == null) {
			parsers.put(name, tagParser);
			return;
		}
		if (false == tagParser.getClass().equals(prevRegistered.getClass())) {
			LOG.warn("the [" + name + "] already associated a different parser: " + prevRegistered.toString() + "; it will replace with " + tagParser);
		}
		parsers.put(name, tagParser);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#unregisterParser(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void unregisterParser(String tagName) {
		parsers.remove(tagName);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#generate(java.lang.String,
	 *      com.trs.dev4.jdk16.cms.PageContext)
	 */
	@Override
	public String generate(String templateName, PageContext pageContext) {
		if (StringHelper.isEmpty(templateName)) {
			return "";
		}
		TemplateDocument templateDoc = templateManager
				.getTemplateDocument(templateName);
		if (templateDoc == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("templateDoc is null: [" + templateName + "]");
			}
			return "";
		}
		return generate(templateDoc, pageContext);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#generate(com.trs.dev4.jdk16.cms.ITemplate,
	 *      com.trs.dev4.jdk16.cms.PageContext)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public String generate(TemplateDocument templateDoc, PageContext pageContext) {
		PageContent pageContent = new PageContent();
		int tagCount = templateDoc.getItemCount();
		if (LOG.isDebugEnabled()) {
			LOG.debug("tagCount: " + tagCount);
		}
		for (int i = 0; i < tagCount; i++) {
			TagItem currentTag = templateDoc.getItemAt(i);
			if (currentTag == null) {
				LOG.warn(i + "of " + tagCount + " tagItem is null");
				continue;
			}
			TagContext tagContext = new TagContext(pageContext, currentTag);
			parseTag(currentTag, pageContent, pageContext, tagContext);
		}
		return pageContent.merge();
	}

	/**
	 * 解析指标
	 * 
	 * @param currentTag
	 * @param pageContent
	 * @param pageContext
	 * @param tagContext
	 */
	public void parseTag(TagItem currentTag, PageContent pageContent,
			PageContext pageContext, TagContext tagContext) {
		String tagName = currentTag.getName();// 标签名
		if (StringHelper.isEmpty(tagName)) {
			pageContent.add(currentTag);
			return;
		}

		ITagParser tagParser = this.getParser(tagName); // 标签对应的Tag
		if (tagParser == null) {
			LOG.warn("No Suitable TagParser for [" + tagName + "]");
			return;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("Found " + tagParser + " for parse [" + tagName + "]");
		}
		String parsedTagContent = tagParser.parse(currentTag, tagContext);
		pageContent.add(new TagItem(parsedTagContent));
	}
	
	public String parseLoop(TagItem tagItem, TagContext tagContext) {
		
		PageContent childrenContent = new PageContent();
		
		PublishObject entitys = tagContext.getEntity();

		List objects = (List) entitys.getProperty("pageItems");
		
		int objectSize = objects.size();
		
		for (int objectIndex = 0; objectIndex < objectSize;objectIndex++) {
		
			for (TagItem childTag : tagItem.getChildren()) {

				if (StringHelper.isEmpty(childTag.getName())) {
					childrenContent.add(childTag);
					continue;
				}
				
				if (childTag.getName().equalsIgnoreCase("TRS_OBJECT") ) {
					int length = StringHelper.parseInt(childTag.getAttribute("LENGTH"));
					
					length = length > 0 ? length : 1;
					
					for (int i = 0; i < length && objectIndex < objectSize; i++) {
						
						Object object = objects.get(objectIndex);
						PublishObject entity = tagContext.getPageContext().wrap(object);
						TagContext entityTagContext = new TagContext(tagContext, childTag);
						entityTagContext.setEntity(entity);
						this.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);
						
						if (i != length - 1) {
							objectIndex++;
						}
					}

				} else {
					Object object = objects.get(objectIndex);
					PublishObject entity = tagContext.getPageContext().wrap(object);
					TagContext entityTagContext = new TagContext(tagContext, childTag);
					entity.setIndex(objectIndex);
					entityTagContext.setEntity(entity);
					this.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);
				} 
			}
		}
		
		return childrenContent.merge();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.IContentGenerator#parseObjects(com.trs.dev4.jdk16
	 * .dao.PagedList, com.trs.dev4.jdk16.cms.impl.TagItem,
	 * com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	@SuppressWarnings("rawtypes")
	public String parseObjects(String loopType, PagedList objects, TagItem currentTag,
			TagContext tagContext, ITagAware tagAware) {

		if (LOG.isDebugEnabled()) {
			LOG.debug("tagItem: " + tagContext + "\ntagContext: " + tagContext);
			LOG.debug("tagParser.pagedObjects: " + objects);
			LOG.debug("tagItem.getChildren: "
					+ CollectionUtil.toString(currentTag.getChildren()));
		}

		PageContent childrenContent = new PageContent();

		if (loopType.equalsIgnoreCase("loop")) {
			buildPageContent(objects, currentTag, tagContext, childrenContent, tagAware);
		} else {
			
			int objectSize = objects.getPageItems().size();

			for (int objectIndex = 0; objectIndex < objectSize; objectIndex++) {

				for (TagItem childTag : currentTag.getChildren()) {

					if (StringHelper.isEmpty(childTag.getName())) {
						childrenContent.add(childTag);
						continue;
					}

					if (childTag.getName().equalsIgnoreCase("TRS_OBJECT")) {
						int length = StringHelper.parseInt(childTag.getAttribute("LENGTH"));

						length = length > 0 ? length : 1;

						for (int i = 0; i < length && objectIndex < objectSize; i++) {

							Object object = objects.getPageItems().get(objectIndex);
							PublishObject entity = tagContext.getPageContext().wrap(object);
							TagContext entityTagContext = new TagContext(tagContext, childTag);
							entityTagContext.setEntity(entity);
							this.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);

							if (i != length - 1) {
								objectIndex++;
							}
						}

					} else {
						Object object = objects.getPageItems().get(objectIndex);
						PublishObject entity = tagContext.getPageContext().wrap(object);
						TagContext entityTagContext = new TagContext(tagContext, childTag);
						entity.setIndex(objectIndex);
						entityTagContext.setEntity(entity);
						this.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);
					}
				}
			}
		}
		
		return childrenContent.merge();
	}

	/**
	 * 显示遍历内容
	 * 
	 * @param objects
	 * @param currentTag
	 * @param tagContext
	 * @param childrenContent
	 */
	@SuppressWarnings("rawtypes")
	private void buildPageContent(PagedList objects, TagItem currentTag,
			TagContext tagContext, PageContent childrenContent,
			ITagAware tagAware) { 
		
		// 遍历所有的子标签
		for (TagItem childTag : currentTag.getChildren()) {
			// 子标签中的HTML标签不通过Parser
			if (StringHelper.isEmpty(childTag.getName())) {
				childrenContent.add(childTag);
				continue;
			}
			TagContext entityTagContext = new TagContext(tagContext, childTag);
			
			PublishObject entity = tagContext.getPageContext().wrap(objects);
			
			entityTagContext.setEntity(entity);
			
			this.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);
		
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.IContentGenerator#parseObject(com.trs.dev4.jdk16
	 * .cms.IPublishable, com.trs.dev4.jdk16.cms.impl.TagItem,
	 * com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	public String parseObject(PublishObject entity, TagItem tagItem,
			TagContext tagContext) {

		PageContent childrenContent = new PageContent();

		// 遍历所有的子标签
		for (TagItem childTag : tagItem.getChildren()) {

			// 子标签中的HTML标签不通过Parser
			if (StringHelper.isEmpty(childTag.getName())) {
				childrenContent.add(childTag);
				continue;
			}

			// 构造子标签的TagContext及标签上下文对象
			TagContext entityTagContext = new TagContext(tagContext, childTag);

			entityTagContext.setEntity(entity);

			// 解析每一个子标签到childrenContent
			this.parseTag(childTag, childrenContent,
					entityTagContext.getPageContext(), entityTagContext);
		}

		return childrenContent.merge();

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#listRegedTagParsers()
	 * @since liushen @ Feb 15, 2012
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, ITagParser> listRegedTagParsersAsMap() {
		return UnmodifiableMap.decorate(parsers);
	}

	/**
	 * @param parsers
	 *            the parsers to set
	 */
	public void setParsers(Map<String, ITagParser> parsers) {
		for (ITagParser parser : parsers.values()) {
			TagBeanInfo tagBeanInfo = parser.getBeanInfo();
			String tagName = tagBeanInfo.getName();
			this.parsers.put(tagName, parser);
			LOG.info("ITagParser [" + tagName + "] ==> " + parser + ".");
		}
	}

	/**
	 * @return the templateManager
	 */
	public ITemplateManager getTemplateManager() {
		return templateManager;
	}

	@SuppressWarnings("unchecked")
	public Map<String, ITagAware> getTagAwares() {
		return UnmodifiableMap.decorate(tagAwares);
	}

	public void setTagAwares(Map<String, ITagAware> tagAwares) {
		for (ITagAware tagAware : tagAwares.values()) {
			String tagClassName = tagAware.getTagClass().getSimpleName();
			this.tagAwares.put(tagClassName, tagAware);
			LOG.info("ITagAware [" + tagClassName + "] ==> " + tagAware + ".");
		}
	}

	/**
	 * @param templateManager
	 *            the {@link #templateManager} to set
	 */
	public void setTemplateManager(ITemplateManager templateManager) {
		this.templateManager = templateManager;
	}

	
	@Override
	public PublishObject getForeign(PublishObject publishable, String key, TagContext tagContext) {

		ITagAware tagAware = this.getAware(publishable.getMappedObject()
				.getClass().getSimpleName());
		if (null == tagAware) {
			return null;
		}
		List<ForeignRelationship> foreignRelationships = tagAware
				.listForeignRelationships();
		if (null == foreignRelationships) {
			return null;
		}

		ForeignRelationship foreignRelationship = null;
		for (ForeignRelationship t : foreignRelationships) {
			if (key.equals(t.getObjectName())) {
				foreignRelationship = t;
				break;
			}

		}
		if (null == foreignRelationship) {
			return null;
		}
		ITagAware nextTagAware = this.getAware(foreignRelationship
				.getAwareClassName());
		Object nextObject = null;
		String propertyAsStr = publishable.getPropertyAsStr(foreignRelationship.getAttributeName());
		if (StringHelper.isEmpty(propertyAsStr)) {
			nextObject = nextTagAware.getPublishObject(publishable.getPropertyAsInt(foreignRelationship.getAttributeName()));
		} else {
			nextObject = nextTagAware.getPublishObject(propertyAsStr, tagContext);
		}
		if (nextObject == null) {
			return null;
		}
		PublishObject nextPublishable = (!(nextObject instanceof PublishObject)) ? new PublishObject(
				nextObject) : (PublishObject) nextObject;
		publishable.put(foreignRelationship.getObjectName(), nextPublishable);
		return nextPublishable;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#getExtraProperty(java.lang.String)
	 * @since yangyu @ 2012-6-17
	 */
	@Override
	public Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext) {
		ITagAware tagAware = this.getAware(publishable.getMappedObject().getClass().getSimpleName());
		return tagAware.getExtraProperty(publishable, key, tagContext);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#generate(com.trs.dev4.jdk16.cms.bo.PageLink,
	 *      com.trs.dev4.jdk16.cms.PageContext, java.io.PrintWriter)
	 * @since yangyu @ Jul 16, 2012
	 */
	@Override
	public void generate(PageLink pageLink, PageContext pageContext, final PrintWriter writer) {
		TemplateDocument templateDoc = templateManager.getTemplateDocument(pageLink.getTemplateName());
		if (templateDoc == null) {
			return;
		}
		
		final PageContent pageContent = new PageContent();
		List<TagContext> pagelets = new ArrayList<TagContext>();
		final List<String> jsList = new ArrayList<String>();
		final List<String> cssList = new ArrayList<String>();
		
		int tagCount = templateDoc.getItemCount();		
		for (int i = 0; i < tagCount; i++) {
			TagItem currentTag = templateDoc.getItemAt(i);
			if (currentTag == null) {
				LOG.warn(i + "of " + tagCount + " tagItem is null");
				continue;
			}
			
			TagContext tagContext = new TagContext(pageContext, currentTag);
			
			if (!StringHelper.isEmpty(currentTag.getName()) && currentTag.getName().equalsIgnoreCase("TRS_PAGELET")) {
				pageletParseTag(pageLink, pageContext, writer, pageContent, pagelets, jsList, cssList, currentTag, tagContext);
			} else {
				parseTag(currentTag, pageContent, pageContext, tagContext);
			}
		}
		
		// 输出主框架
		flushwriter(pageContent.merge(), writer);
				
		if (pageLink.getParserType().equals(PageLink.ParserType.BIGPIPE)) {
			loadContentByJs(writer, pageContent, pagelets, jsList, cssList);
		}

		flushJs(writer, jsList);
	}

	/**
	 * 解析Pagelet
	 */
	private void pageletParseTag(PageLink pageLink, PageContext pageContext, final PrintWriter writer, final PageContent pageContent,
			List<TagContext> pagelets, final List<String> jsList, final List<String> cssList, TagItem currentTag, TagContext tagContext) {
		buildJs(tagContext, jsList);
		if (pageLink.getParserType() != null && pageLink.getParserType().equals(PageLink.ParserType.BIGPIPE)) {
			pagelets.add(tagContext);
		} else {
			buildCss(writer, pageContent, tagContext, cssList, false);
			parseTag(currentTag, pageContent, pageContext, tagContext);
		}
	}

	private void loadContentByJs(final PrintWriter writer, final PageContent pageContent, List<TagContext> pagelets, final List<String> jsList,
			final List<String> cssList) {
		flushwriter("<script type=\"text/javascript\">function arrivedHtml(id,text) { var b=document.getElementById(id); b.innerHTML = text; }</script>",
				writer);
		List<Callable<Boolean>> tasks = new ArrayList<Callable<Boolean>>();

		for (final TagContext pagelet : pagelets) {
			tasks.add(new Callable<Boolean>() {
				public Boolean call() {
					try {
						pagelet(writer, pagelet, jsList, cssList, pageContent);
					} catch (Exception e) {
						return false;
					}
					return true;
				}
			});
		}

		try {
			executor.invokeAll(tasks, 1500, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
		}
	}

	private void flushJs(final PrintWriter writer, final List<String> jsList) {
		StringBuilder jsCode = new StringBuilder();
		for (String js : jsList) {
			jsCode.append("<script src=\"").append(js).append("\"></script>");
		}
		flushwriter(jsCode.toString(), writer);
	}

	private void pagelet(PrintWriter writer, TagContext pagelet, List<String> jsList, List<String> cssList, PageContent pageContent) {
		String idAttr = pagelet.getAttribute("id");

		ITagParser tagParser = this.getParser("TRS_PAGELET");
		String content = tagParser.parse(pagelet.getTagItem(), pagelet);
		
		try {
			content = HtmlCompressor.compress(content);
		} catch (Exception e) {
		}
		
		buildCss(writer, null, pagelet, cssList, true);
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("<script>arrivedHtml(\"").append(idAttr).append("\", \"").append(
				content.replaceAll("\"", "\\\\\"").replaceAll("</script>", "</\\\\script>"))
				.append("\");</script>");
		
		flushwriter(sb.toString(), writer);
	}

	private void buildJs(TagContext pagelet, List<String> jsList) {
		String jsAttr = pagelet.getAttribute("js");
		if (!StringHelper.isEmpty(jsAttr)) {
			String[] jses = StringHelper.split(jsAttr, ";");
			for (String js : jses) {
				if (!jsList.contains(js)) {
					jsList.add(js);
				}
			}
		}
	}

	private void buildCss(PrintWriter writer, PageContent pageContent, TagContext pagelet, List<String> cssList, boolean needFlush) {
		String cssAttr = pagelet.getAttribute("css");
		if (!StringHelper.isEmpty(cssAttr)) {
			String[] csses = StringHelper.split(cssAttr, ";");
			for (String css : csses) {
				if (!cssList.contains(css)) {
					if (needFlush) {
						flushwriter("<link href=\"" + css + "\" rel=\"stylesheet\" type=\"text/css\" />", writer);
					} else {
						pageContent.add(new TagItem("<link href=\"" + css + "\" rel=\"stylesheet\" type=\"text/css\" />"));
					}
					cssList.add(css);
				}
			}
		}
	}

	/**
	 * @param string
	 * @param writer
	 * @since yangyu @ Jul 17, 2012
	 */
	private void flushwriter(String string, PrintWriter writer) {
		writer.println(string);
		writer.flush();
	}
	
    private static ExecutorService executor = Executors.newFixedThreadPool(500, new ThreadFactory() {
		public Thread newThread(Runnable r) {
			Thread t = new Thread(r);
			t.setName("Service Thread " + t.getId());
			t.setDaemon(true);
			return t;
		}
	});
    
}
