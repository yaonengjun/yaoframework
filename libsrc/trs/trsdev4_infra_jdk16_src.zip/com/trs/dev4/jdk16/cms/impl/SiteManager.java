/**
 * 
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.List;

import com.trs.dev4.jdk16.cms.ForeignRelationship;
import com.trs.dev4.jdk16.cms.ISiteManager;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IModuleLifecycle;

/**
 * 职责：站点管理类实现，参见{@link ISiteManager}和{@link ITagAware}<br>
 * 
 * @author TRS信息技术股份有限公司
 * @since 2012-2-9
 */
public class SiteManager extends CachedBaseManager<Site> implements ISiteManager, ITagAware, IModuleLifecycle {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.cms.ITagAware#getPublishObject(int)
	 */
	@Override
	public Object getPublishObject(int id) {
		return this.get(id); 
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.cms.ITagAware#listForeignRelationships()
	 */
	@Override
	public List<ForeignRelationship> listForeignRelationships() {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.cms.ITagAware#getTagClass()
	 */
	@Override
	public Class<?> getTagClass() {
		return Site.class;
	}

	@Override
	public Object getPublishObject(SearchFilter obj, TagContext tagContext) {
		return null;
	}

	@Override
	public PagedList<Site> pagedPublishObjects(TagItem arg0, TagContext arg1, SearchFilter sf) {
		return this.pagedObjects(sf);
	}
	
	public Site getCurrentSite() {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("status", 1);
		return this.findUnique(sf, true);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagAware#getPublishObject(java.lang.String,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since yangyu @ Jun 6, 2012
	 */
	@Override
	public Object getPublishObject(String propertyAsStr, TagContext tagContext) {
		// TODO yangyu@Jun 6, 2012 4:26:59 PM: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagAware#getExtraProperty(com.trs.dev4.jdk16.cms.PublishObject,
	 *      java.lang.String)
	 * @since yangyu @ 2012-6-17
	 */
	@Override
	public Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext) {
		// TODO yangyu@2012-6-17 下午02:34:24: Auto-generated method stub
		return null;
	}

}
