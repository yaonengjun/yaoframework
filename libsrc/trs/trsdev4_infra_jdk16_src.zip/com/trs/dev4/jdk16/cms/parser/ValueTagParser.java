/*
 * Created: yangyu@Jul 5, 2012 1:41:24 PM
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;

/**
 * 职责: <br>
 * 
 */
public class ValueTagParser implements ITagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since yangyu @ Jul 5, 2012
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since yangyu @ Jul 5, 2012
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		
		
		return null;
	}

}
