/*
 * Created: yangyu@2012-6-10 上午09:37:57
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.utils.UrlUtil;

/**
 * 职责: <br>
 * 
 */
public class LinkTagParser implements ITagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since yangyu @ 2012-6-10
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_LINK", "LINK", BodyType.EMPTY);

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since yangyu @ 2012-6-10
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {

		// 父置标
		TagContext pTagContext = tagContext.getParent();

		if (pTagContext == null) {
			return TagParserUtils.writeError("Link置标需要有外层置标");
		}

		String selectedClass = pTagContext.getAttribute("selectedClass", "");
		String defaultClass = pTagContext.getAttribute("defaultClass", "");
		String urlParam = pTagContext.getAttribute("urlParam");

		String value = getValue(tagContext, urlParam);

		String selectedValue = getSelectedValue(tagContext);
		selectedValue = UrlUtil.encode(selectedValue);
		
		// 完成
		String hrefValue = TagParserUtils.deleteParameter(tagContext, urlParam);
		if (!StringHelper.isEmpty(selectedValue)) {
			hrefValue = new StringBuilder(hrefValue).append("&").append(urlParam).append("=").append(selectedValue).toString();
		}
		
		String innerHtml = TagParserUtils.getInnerHtml(tagItem, tagContext);
		
		String classValue = "";

		if (selectedValue.equalsIgnoreCase(value)) {
			classValue = selectedClass;
		} else {
			classValue = defaultClass;
		}
		
		StringBuilder sb = new StringBuilder("<a href='");
		sb.append(hrefValue);
		sb.append("' class='");
		sb.append(classValue);
		sb.append("'>");
		sb.append(innerHtml);
		sb.append("</a>");
		return sb.toString();
	}

	private String getValue(TagContext tagContext, String urlParam) {
		String value = tagContext.getPageContext().getRequestParameter(urlParam, "");
		return value;
	}

	private String getSelectedValue(TagContext tagContext) {
		String selectedValue = tagContext.getAttribute("selectedValue","");
		
		return TagParserUtils.parentValueDecorate(selectedValue, tagContext);
	}
	
}
