package com.trs.dev4.jdk16.cms.parser;

import java.text.DecimalFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 统一的属性解析Parser
 * 
 * @author yangyu
 * @since 2011-5-21
 */
public class PropertyTagParser implements ITagParser {

	protected final Logger logger = Logger.getLogger(PropertyTagParser.class);
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem
	 * , com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since yangyu @ 2012-5-20
	 */
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		String stringValue = tagContext.getAttribute("VALUE");

		Object output = buildCommonValue(tagItem, tagContext, stringValue);
		PublishObject publishable = tagContext.getEntity();
		
		if (output == null && publishable != null) {

			output = publishable.getProperty(stringValue);

			if (null == output) {
				output = tagContext.getPageContext().getContentGenerator().getExtraProperty(publishable, stringValue, tagContext);
			}

		}
		
		if (null == output) {
			return "";
		}
		
		output = datePatternDecorate(tagContext, output);
		
		if(StringHelper.isNumeric(output.toString())){
			output = numberPatternDecorate(tagContext, output);			
		}
		
		output = escapeXMLDecorate(tagContext, output);
		
		output = separateDecorate(tagContext, output.toString());
	    
	    return output.toString();
	}

	/**
	 * @param tagItem
	 * @param tagContext
	 * @param stringValue
	 * @return
	 * @since yangyu @ Jul 5, 2012
	 */
	private Object buildCommonValue(TagItem tagItem, TagContext tagContext, String stringValue) {

		if (stringValue.startsWith("requestAttribute.")) {
			RequestContext requestContext = tagContext.getPageContext().getRequestContext();
			if (requestContext == null) {
				return null;
			}
			return requestContext.getAttribute(stringValue.substring(17));
		}

		return null;
	}

	private String separateDecorate(TagContext tagContext, String output) {
		// 加前缀、后缀、分割、URL
		String prefix = tagContext.getAttribute("prefix","");
		String suffix = tagContext.getAttribute("suffix","");
		String separator = tagContext.getAttribute("separator");
		String[] separatedOutput = new String[]{output};
		if(StringHelper.isNotEmpty(separator)){
			separatedOutput = StringHelper.split(output, separator);
		}
		String[] prefixSeparatedOutput = new String[separatedOutput.length];
		for(int i=0;i<separatedOutput.length ;i++){
			prefixSeparatedOutput[i] = (new StringBuffer(prefix)).append(separatedOutput[i]).append(suffix).toString();
		}
		String urlPattern = tagContext.getAttribute("urlPattern");
		if(StringHelper.isNotEmpty(urlPattern)){
			
			for(int i=0;i<separatedOutput.length ;i++){
				String url = urlPattern.replace("$" ,separatedOutput[i]);
				separatedOutput[i] = (new StringBuffer("<a href='")).append(url).append("'>").append(prefixSeparatedOutput[i]).append("</a>").toString();
			}
		}
		StringBuffer outputBuffer = new StringBuffer();
		for(int i=0;i<separatedOutput.length ;i++){
			outputBuffer.append(separatedOutput[i]);
		}
	    output = outputBuffer.toString();	

		String holder = tagContext.getAttribute("holder");
	    if(StringHelper.isNotEmpty(holder)){
	    	output = StringHelper.replaceAll(output, "$", holder);
	    }
		return output;
	}

	private String escapeXMLDecorate(TagContext tagContext, Object output) {
		String escape = tagContext.getAttribute("escapeXML");
		boolean escapeXML = Boolean.valueOf(escape);
		if(escapeXML == true){
			return StringHelper.escape(output.toString());
		}
		return output.toString();
	}

	private Object numberPatternDecorate(TagContext tagContext, Object value) {
		String numberPattern = tagContext.getAttribute("NUMBERPATTERN");
		if(!StringHelper.isEmpty(numberPattern)){
			value = new DecimalFormat(numberPattern).format(value);				
		}
		return value;
	}

	private Object datePatternDecorate(TagContext tagContext, Object value) {
		String datePattern = tagContext.getAttribute("DATEPATTERN");
		
		if(!StringHelper.isEmpty(datePattern)){
			boolean readable = Boolean.valueOf(tagContext.getAttribute("readable", "false"));
			long timeMillis = 0;
			if(value instanceof Date){
				timeMillis = ((Date) value).getTime();
			}else if(StringHelper.isNumeric(value.toString())){
				timeMillis = Long.valueOf(value.toString()); 
			}
			long duration = System.currentTimeMillis()-timeMillis;
			//
			if(duration <= 24*3600*1000L && readable == true){
				value = DateUtil.timeToString(duration);
			}else{
				value = DateUtil.formatMillis(timeMillis, datePattern);
			}
		}
		return value;
	}

	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_PROPERTY", "DOMAIN PROPERTY",
				BodyType.EMPTY);
	}
}
