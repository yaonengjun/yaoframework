/*
 * TagBeanAttrInfo.java created on 2005-9-6 14:56:32 by Martin (Fu Chengrui)
 * Update Log:
 *	2006.01.19	FuChengrui
 *		增加了方法getVariable()和setVariable()，用以判断该置标属性是否支持变量。
 */

package com.trs.dev4.jdk16.cms.impl;

/**
 * 用于描述 ITagParser 置标的属性的特性
 * 
 * @author Martin (付成睿)
 */
public class TagBeanAttrInfo {

    public static class Type {

		/**
		 * 整数类型的属性，属性值必须是10个数字和减号
		 */
        public final static Type INTEGER = new Type("INTEGER");

		/**
		 * 数值类型的属性，属性值必须是10个数字、减号和小数点
		 */
        public final static Type NUMBER = new Type("NUMBER");

		/**
		 * 字符串类型的属性，属性值可以是任意字符串
		 */
        public final static Type STRING = new Type("STRING");

		/**
		 * 属性类型的名称
		 */
        private String m_sName;

		/**
		 * 私有的构造函数，不得外部实例化
		 * 
		 * @param name
		 *            属性类型的名称
		 */
        private Type(String name) {
            m_sName = name;
        }

		/**
		 * 返回属性类型的名称
		 * 
		 * @return 属性类型的名称
		 */
        public String getName() {
            return m_sName;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#toString()
         */
        @Override
		public String toString() {
            return m_sName;
        }

    }

	/**
	 * 属性的名称
	 */
    private String m_sAttrName;

	/**
	 * 属性的详细描述
	 */
    private String m_sAttrDesc;

	/**
	 * 属性的类型
	 */
    private Type m_oAttrType;

	/**
	 * 属性是不是必须的
	 */
    private boolean m_zRequired;

	/**
	 * 属性值是不是可变的
	 */
    private boolean m_zVariable;

	/**
	 * 属性的缺省值
	 */
    private String m_sDefValue;

	/**
	 * 有效的属性值列表
	 */
    private String[] m_enumValue;

	/**
	 * 有效的属性值列表拼接得到的字符串
	 */
    private String m_sEnumValueString;

	/**
	 * 缺省构造方法
	 */
    public TagBeanAttrInfo() {
        m_oAttrType = Type.STRING;
        m_zVariable = true;
    }

	/**
	 * 构造方法
	 * 
	 * @param name
	 *            属性名称
	 * @param type
	 *            属性类型
	 * @param sDef
	 *            属性缺省值
	 * @param aVal
	 *            有效属性值的列表
	 */
    public TagBeanAttrInfo(String name, Type type, String sDef, String[] aVal) {
        m_sAttrName = name;
        m_oAttrType = type;
        m_sDefValue = sDef;
        m_enumValue = aVal;
        m_sAttrDesc = name;
        m_zRequired = false;
        m_zVariable = true;
    }

	/**
	 * 返回属性名称
	 * 
	 * @return 属性名称
	 */
    public String getName() {
        return m_sAttrName;
    }

	/**
	 * 设置属性名称
	 * 
	 * @param name
	 *            属性名称
	 */
    public void setName(String name) {
        if (m_sAttrDesc == null) {
            m_sAttrDesc = name.toUpperCase();
        }
        m_sAttrName = name.toUpperCase();
    }

	/**
	 * 返回属性的详细描述
	 * 
	 * @return 属性的详细描述
	 */
    public String getDesc() {
        return m_sAttrDesc;
    }

	/**
	 * 设置属性的详细描述
	 * 
	 * @param desc
	 *            属性的详细描述
	 */
    public void setDesc(String desc) {
        m_sAttrDesc = desc;
    }

	/**
	 * 返回属性类型
	 * 
	 * @return 属性类型
	 */
    public Type getType() {
        return m_oAttrType;
    }

	/**
	 * 设置属性类型
	 * 
	 * @param type
	 *            属性类型
	 */
    public void setType(Type type) {
        m_oAttrType = type;
    }

	/**
	 * 返回对于当前置标该属性是不是必须的
	 * 
	 * @return 对于当前置标该属性是不是必须的
	 */
    public boolean getRequired() {
        return m_zRequired;
    }

	/**
	 * 设置对于当前置标该属性是不是必须的
	 * 
	 * @param zRequired
	 *            对于当前置标该属性是不是必须的
	 */
    public void setRequired(boolean zRequired) {
        m_zRequired = zRequired;
    }

	/**
	 * 返回设置属性值是不是可变的
	 * 
	 * @return 属性值是否可以为变量
	 */
    public boolean getVariable() {
        return m_zVariable;
    }

	/**
	 * 设置属性值是不是可变的
	 * 
	 * @param variable
	 *            属性值是否可以为变量
	 */
    public void setVariable(boolean variable) {
        m_zVariable = variable;
    }

	/**
	 * 返回属性的缺省值
	 * 
	 * @return 属性的缺省值
	 */
    public String getDefaultValue() {
        return m_sDefValue;
    }

	/**
	 * 设置属性的缺省值
	 * 
	 * @param sDefaultValue
	 *            属性的缺省值
	 */
    public void setDefaultValue(String sDefaultValue) {
        m_sDefValue = sDefaultValue;
    }

	/**
	 * 返回有效的属性值的列表数组，如果属性值不是枚举类型，则返回<code>null</code>。
	 * 
	 * @return 有效的属性值的列表数组或者<code>null</code>
	 */
    public String[] getEnumValue() {
        return m_enumValue;
    }

	/**
	 * 设置有效的属性值的列表数组，如果属性值不是枚举类型，则可以设置为<code>null</code>。
	 * 
	 * @param value
	 *            有效的属性值的列表数组或者<code>null</code>
	 */
    public void setEnumValue(String[] value) {
        m_enumValue = value;
    }

	/**
	 * 返回由有效的属性值构成的字符串，或者<code>null</code>。
	 * 
	 * @return 由有效的属性值构成的字符串
	 */
    public String getEnumValueString() {
        if (m_sEnumValueString == null) {
            if (m_enumValue != null && m_enumValue.length > 0) {
                StringBuffer sb = new StringBuffer();
                sb.append('[');
                for (int i = 0; i < m_enumValue.length; i++) {
                    if (sb.length() > 1)
                        sb.append(',');
                    sb.append(m_enumValue[i]);
                }
                sb.append(']');
                m_sEnumValueString = sb.toString();
            }
        }
        return m_sEnumValueString;
    }

}