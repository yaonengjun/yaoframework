package com.trs.dev4.jdk16.cms.impl;

/**
 * 扫描模板正文，把正文解析成为置标树的辅助类。
 * 
 */
public class ScanContext {

	/**
	 * 模板正文
	 */
    private String m_sText;

	/**
	 * 当前字符的行号
	 */
    private int m_iLineNo = 1;

	/**
	 * 当前字符的列号
	 */
    private int m_iColumn = 1;

	/**
	 * 当前字符的位置
	 */
    private int m_iOffset;

	/**
	 * 上次设置的记录点
	 */
    private int m_iMarkedLineNo;

    private int m_iMarkedColumn;

    private int m_iMarkedOffset;

	/**
	 * 构造方法
	 * 
	 * @param s
	 *            模板正文
	 */
    public ScanContext(String s) {
        if (s == null || s.length() <= 0) {
			throw new IllegalArgumentException("模板正文不能为空");
        }
        m_sText = s;
    }

	/**
	 * 判断是否还有未获取的字符
	 */
    public boolean hasChar() {
        return m_iOffset < m_sText.length();
    }

	/**
	 * 返回当前字符,但是不移动指针
	 */
    public char getChar() {
        return m_sText.charAt(m_iOffset);
    }

	/**
	 * 返回前一个字符,但是不移动指针
	 */
    public char prevChar() {
        return m_sText.charAt(m_iOffset - 1);
    }

	/**
	 * 移动指针到下一个字符
	 */
    public void skipChar() {
        if (m_iOffset >= m_sText.length()) {
            return;
        }
        char c = m_sText.charAt(m_iOffset++);
		if (c == '\n') // 为了实现的简单起见,直接忽略'0x0D',即'\r' c == '\r'
        {
            m_iLineNo++;
            m_iColumn = 1;
        } else {
            m_iColumn++;
        }
    }

	/**
	 * 返回当前字符的列号
	 */
    public int getColumn() {
        return m_iColumn;
    }

	/**
	 * 返回当前字符的行号
	 */
    public int getLineNo() {
        return m_iLineNo;
    }

	/**
	 * 返回当前字符的偏移位置
	 */
    public int getOffset() {
        return m_iOffset;
    }

	/**
	 * 返回正文的长度
	 */
    public int getLength() {
        return m_sText.length();
    }

	/**
	 * 标记当前位置
	 */
    public void mark() {
        m_iMarkedLineNo = m_iLineNo;
        m_iMarkedColumn = m_iColumn;
        m_iMarkedOffset = m_iOffset;
    }

	/**
	 * 重置当前位置为上一次标记的位置
	 */
    public void reset() {
        m_iLineNo = m_iMarkedLineNo;
        m_iColumn = m_iMarkedColumn;
        m_iOffset = m_iMarkedOffset;
    }

	/**
	 * 返回从指定的位置开始,到当前位置的一个描述
	 * 
	 * @param iStartPos
	 *            指定的开始位置
	 */
    public String lookAround(int iStartPos) {
        return lookAround(iStartPos, m_iOffset);
    }

	/**
	 * 返回指定启止位置的描述
	 * 
	 * @param iStartPos
	 *            指定的开始位置
	 * @param iClosePos
	 *            指定的结束位置
	 */
    public String lookAround(int iStartPos, int iClosePos) {
        StringBuffer sb = new StringBuffer(256);

        sb.append('(');
		sb.append("行=").append(getLineNo()).append(',');
		sb.append("列=").append(getColumn()).append(',');
		sb.append("偏移=").append(getOffset()).append(',');
		sb.append("源码=");
        if (iClosePos >= m_sText.length()) {
            iClosePos = m_sText.length();
        }
        if ((iClosePos - iStartPos) < 160) {
            sb.append(m_sText.substring(iStartPos, iClosePos));
        } else {
            sb.append(m_sText.substring(iStartPos, iStartPos + 79));
            sb.append("...");
            sb.append(m_sText.substring(iClosePos - 79, iClosePos));
        }
        sb.append(')');

        return sb.toString();
    }

}