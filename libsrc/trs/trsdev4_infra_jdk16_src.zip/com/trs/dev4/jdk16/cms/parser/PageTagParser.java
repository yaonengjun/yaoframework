package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.utils.StringHelper;

public class PageTagParser implements ITagParser {

	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_PAGE", "Page information", BodyType.EMPTY);
	}

	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		PublishObject entity = tagContext.getEntity();

		int pageSize = entity.getPropertyAsInt("pageSize");
		int totalPage = entity.getPropertyAsInt("pageTotal");
		int currentPage = entity.getPropertyAsInt("pageIndex") + 1;
		int total = entity.getPropertyAsInt("totalItemCount");
		int pageNum = entity.getPropertyAsInt("pageTotal") == 0 ? 1 : entity.getPropertyAsInt("pageTotal");
		int prevPage = entity.getPropertyAsInt("prevPage") + 1;
		int nextPage = entity.getPropertyAsInt("nextPage") + 1;
		int startPage = entity.getPropertyAsInt("startPage") + 1;
		int endPage = entity.getPropertyAsInt("endPage") + 1;

		String usedFirst = tagContext.getAttribute("first");
		String usedPrev = tagContext.getAttribute("prev");
		String usedNext = tagContext.getAttribute("next");
		String usedLast = tagContext.getAttribute("last");		
		String usedTotal = tagContext.getAttribute("total");
		String usedTotalPage = tagContext.getAttribute("totalPage");
		String usedPageSize = tagContext.getAttribute("pageSize");
		String usedCurrent = tagContext.getAttribute("current");
		String defaultClass = tagContext.getAttribute("defaultClass", "");
		String currentClass = tagContext.getAttribute("currentClass", "");		
		String currentStyle = tagContext.getAttribute("currentStyle", "");

		String urlPattern = TagParserUtils.buildUrlPattern(tagContext);
		
		StringBuilder sb = new StringBuilder();
		// 首页
		if (StringHelper.isNotEmpty(usedFirst) && currentPage != 1) {
			buildPage(urlPattern, sb, usedFirst, 1, defaultClass, currentStyle);
		}
		// 上一页
		if (StringHelper.isNotEmpty(usedPrev) && currentPage != 1) {
			buildPage(urlPattern, sb, usedPrev, prevPage, defaultClass, currentStyle);
		}
		
		// 数字
		for (int i = startPage; i <= endPage; i++) {
			if (i == currentPage) {
				buildPage(urlPattern, sb, String.valueOf(i), i, currentClass, currentStyle, true);
				continue;
			}
			buildPage(urlPattern, sb, String.valueOf(i), i, defaultClass, currentStyle);
		
		}
		
		// 下一页
		if (StringHelper.isNotEmpty(usedNext) && currentPage != pageNum) {
			buildPage(urlPattern, sb, usedNext, nextPage, defaultClass, currentStyle);
		}

		// 尾页
		if (StringHelper.isNotEmpty(usedLast) && currentPage != pageNum) {
			buildPage(urlPattern, sb, usedLast, pageNum, defaultClass, currentStyle);
		}
		
		// 总记录数
		if (StringHelper.isNotEmpty(usedTotal)) {
			sb.append(usedTotal.replace("$", total + ""));
		}
		
		// 总页数
		if (StringHelper.isNotEmpty(usedTotalPage)) {
			sb.append(usedTotalPage.replace("$", totalPage + ""));
		}
		
		// 每页容量
		if (StringHelper.isNotEmpty(usedPageSize)) {
			sb.append(usedPageSize.replace("$", pageSize + ""));
		}

		// 当前页码
		if (StringHelper.isNotEmpty(usedCurrent)) {
			sb.append(usedCurrent.replace("$", currentPage + ""));
		}
		
		return sb.toString();

	}


	
	/**
	 * @param urlPattern
	 * @param sb
	 * @param valueOf
	 * @param i
	 * @param currentClass
	 * @param currentStyle
	 * @param b
	 * @since yangyu @ Jun 28, 2012
	 */
	private void buildPage(String urlPattern, StringBuilder sb, String title, int i, String currentClass, String currentStyle, boolean b) {
		if (StringHelper.isEmpty(currentStyle)) {
			buildDefaultPage(urlPattern, sb, title, i, currentClass, b);
		} else if (currentStyle.equalsIgnoreCase("span")) {
			buildSpanPage(urlPattern, sb, title, i, currentClass, b);
		}

	}

	private void buildPage(String urlPattern, StringBuilder sb, String title,
			int i, String defaultClass, String currentStyle) {
		if (StringHelper.isEmpty(currentStyle)) {
			buildDefaultPage(urlPattern, sb, title, i, defaultClass, false);
		} else if (currentStyle.equalsIgnoreCase("span")) {
			buildSpanPage(urlPattern, sb, title, i, defaultClass, false);
		}
	}

	/**
	 * @param urlPattern
	 * @param sb
	 * @param title
	 * @param i
	 * @param defaultClass
	 * @param b
	 * @since yangyu @ Jun 28, 2012
	 */
	private void buildSpanPage(String urlPattern, StringBuilder sb, String title, int i, String defaultClass, boolean isCurrent) {
		
		if (isCurrent) {
			sb.append("<span");
			if (!StringHelper.isEmpty(defaultClass)) {
				sb.append(" class='").append(defaultClass).append("'");
			}
			sb.append("'>").append(title).append("</span> ");
		} else {
			sb.append("<a href='");
			sb.append(urlPattern);

			if (urlPattern.contains("?")) {
				sb.append("&pageNo=").append(i);
			} else {
				sb.append("?pageNo=").append(i);
			}
			sb.append("'>").append(title).append("</a> ");
		}
		
	}

	private void buildDefaultPage(String urlPattern, StringBuilder sb, String title, int i, String defaultClass, boolean isCurrent) {
		if (isCurrent) {
			sb.append("<span");
			if (!StringHelper.isEmpty(defaultClass)) {
				sb.append(" class='").append(defaultClass).append("'");
			}
			sb.append(">").append(title).append("</span> ");
		} else {
			sb.append("<a href='");
			sb.append(urlPattern);

			if (urlPattern.contains("?")) {
				sb.append("&pageNo=").append(i);
			} else {
				sb.append("?pageNo=").append(i);
			}
			sb.append("'>").append(title).append("</a> ");
		}
	}
}
