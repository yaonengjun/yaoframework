/*
 * Created: fangxiang@Jan 21, 2011 10:23:43 AM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.io.StringWriter;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import com.trs.dev4.jdk16.cms.ICMSPublisher;
import com.trs.dev4.jdk16.tunning.PerformanceTimer;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 * 
 */
public class VelocityPublisher implements ICMSPublisher {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(VelocityPublisher.class);
	/**
	 * 模板路径
	 */
	private String propertiesFile;
	/**
	 * 
	 */
	private String templateDirectory;

	/**
	 * @see com.trs.dev4.jdk16.cms.ICMSPublisher#publish(java.lang.String,
	 *      java.util.Map, java.lang.String)
	 * @since fangxiang @ Jan 21, 2011
	 */
	@Override
	public void publish(String templateName, Map<String, Object> inputObjects,
			String outputFile) {
		PerformanceTimer pTimer = new PerformanceTimer();
		FileUtil.saveFile(outputFile, merge(templateName, inputObjects));
		logger.debug("File(" + outputFile
				+ ") merged and output with template(" + templateName
				+ "),elapsed(" + pTimer.getDuration() + ")ms.");
	}

	/**
	 * @return the {@link #propertiesFile}
	 */
	public String getPropertiesFile() {
		return propertiesFile;
	}

	/**
	 * @param propertiesFile
	 *            the {@link #propertiesFile} to set
	 */
	public void setPropertiesFile(String propertiesFile) {
		this.propertiesFile = propertiesFile;
	}

	/**
	 * @return the {@link #templateDirectory}
	 */
	public String getTemplateDirectory() {
		return templateDirectory;
	}

	/**
	 * @param templateDirectory
	 *            the {@link #templateDirectory} to set
	 */
	public void setTemplateDirectory(String templateDirectory) {
		this.templateDirectory = templateDirectory;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ICMSPublisher#merge(java.lang.String,
	 *      java.util.Map)
	 * @since fangxiang @ Jan 21, 2011
	 */
	@Override
	public String merge(String templateName, Map<String, Object> inputObjects) {
		if (StringHelper.isEmpty(templateDirectory)) {
			templateDirectory = this.getClass().getClassLoader()
					.getResource("").getPath()
					+ "velocity_templates/";
			logger.info("TemplateDirectory is null with template("
					+ templateName + "),use default (" + templateDirectory
					+ ").");
		}
		if (!FileUtil.dirExists(templateDirectory)) {
			logger.info("TemplateDirectory not exists with template("
					+ templateName + ") .");
			return "";
		}
		//
		PerformanceTimer pTimer = new PerformanceTimer();
		logger.debug("PropertiesFile:" + propertiesFile + ",templateDirectory:"
				+ templateDirectory);
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty(Velocity.FILE_RESOURCE_LOADER_PATH, templateDirectory);
		if (FileUtil.fileExists(propertiesFile)) {
			ve.init(propertiesFile);
		} else {
			ve.init();
		}
		if (!FileUtil.fileExists(StringHelper
				.smartAppendSlashToEnd(templateDirectory) + templateName)) {
			logger.info("TemplateName(" + templateName
					+ ") not exists in directory(" + templateDirectory + ").");
			return "";
		}
		// 取得velocity的模版
		Template t = ve.getTemplate(templateName);
		// 取得velocity的上下文context
		VelocityContext context = new VelocityContext();
		// 把数据填入上下文
		if (inputObjects != null) {
			for (String key : inputObjects.keySet()) {
				context.put(key, inputObjects.get(key));
				logger.debug("Put inputObject to VelocityContext with key("
						+ key
						+ ").");
			}
		}
		// 转换
		StringWriter writer = new StringWriter();
		t.merge(context, writer);
		String content = writer.toString();
		logger.debug("Content(" + content + ") merged with template("
				+ templateName + "),elapsed(" + pTimer.getDuration() + ")ms.");
		return content;
	}
}
