package com.trs.dev4.jdk16.cms.parser;

import org.apache.commons.lang.BooleanUtils;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 统一的属性解析Parser
 * 
 * @author yangyu
 * @since 2011-5-21
 */
public class SwitchTagParser implements ITagParser {

	protected final Logger logger = Logger.getLogger(SwitchTagParser.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.c ms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem , com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	public String parse(TagItem tagItem, TagContext tagContext) {

		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		
		PublishObject publishable = tagContext.getEntity();

		String keyValue = tagContext.getAttribute("VALUE");
		
		StringBuilder errors = new StringBuilder();

		boolean canPass = this.pass(keyValue, tagContext, publishable, errors);

		if (errors.length() != 0) {
			return TagParserUtils.writeError(errors.toString());
		}
		
		if (canPass) {
			TagItem cTagItem = tagContext.getTagItem();
			tagContext.setEntity(publishable);
			return contentGenerator.parseObject(publishable, cTagItem, tagContext);
		} else {
			return "";
		}
		
	}
		
	private boolean pass(String expression, TagContext tagContext, PublishObject publishable, StringBuilder errors) {

		String[] temps = StringHelper.split(expression, " ");
		if (temps.length == 3) {
			String value = temps[2];
			String oper = temps[1];
			String key = temps[0];
			
			if (publishable == null) {
				
				String[] keys = StringHelper.split(key, ".");
				publishable = tagContext.getPageContext().findObject(keys[0]);
				
				if (publishable == null) {
					errors.append("TRS_SWITCH置标缺少外层指标，无法获知属性属于哪个对象");
					return false;
				}
			}
			
			String srcValue = getSrcValue(publishable, key, tagContext);
			if (srcValue == null) {
				errors.append("TRS_SWITCH置标KEY值获取不到，请确认KEY（属性名）填写是否正确");
			}

			if (oper.equalsIgnoreCase("eq")) {
				if (value.startsWith("'") && value.endsWith("'")) {

					String actualValue = getDecoratedValue(tagContext, value);

					if (actualValue.equalsIgnoreCase(srcValue)) {
						return true;
					}

				} else {
					String actualValue = getDecoratedIntValue(tagContext, value);
					if (StringHelper.isNumeric(value)) {
						
						
						int intActualValue= NumberUtil.parseInt(actualValue, -1);
						int intValue = NumberUtil.parseInt(srcValue, -2);
						if (intActualValue == intValue) {
							return true;
						}
						
					} else if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
						
						
						boolean booleanActualValue = BooleanUtils.toBoolean(actualValue);
						boolean booleanValue = BooleanUtils.toBoolean(srcValue);
						
						if (booleanActualValue == booleanValue) {
							return true;
						}
						
					} 
				}
			} else if (oper.equalsIgnoreCase("gt")) {
				
				
				String actualValue = getDecoratedIntValue(tagContext, value);
				
				if (StringHelper.isNumeric(value)) {

					int intActualValue = NumberUtil.parseInt(actualValue, -1);
					int intValue = NumberUtil.parseInt(srcValue, -2);
					if (intActualValue < intValue) {
						return true;
					}

				}
				
			} else if (oper.equalsIgnoreCase("lt")) {
				

				String actualValue = getDecoratedIntValue(tagContext, value);
				if (StringHelper.isNumeric(value)) {

					int intActualValue = NumberUtil.parseInt(actualValue, -1);
					int intValue = NumberUtil.parseInt(srcValue, -2);
					if (intActualValue > intValue) {
						return true;
					}

				}
			} else if (oper.equalsIgnoreCase("ge")) {
				

				String actualValue = getDecoratedIntValue(tagContext, value);
				if (StringHelper.isNumeric(value)) {

					int intActualValue = NumberUtil.parseInt(actualValue, -1);
					int intValue = NumberUtil.parseInt(srcValue, -2);
					if (intActualValue <= intValue) {
						return true;
					}

				}
			} else if (oper.equalsIgnoreCase("le")) {
				

				String actualValue = getDecoratedIntValue(tagContext, value);
				if (StringHelper.isNumeric(value)) {

					int intActualValue = NumberUtil.parseInt(actualValue, -1);
					int intValue = NumberUtil.parseInt(srcValue, -2);
					if (intActualValue >= intValue) {
						return true;
					}

				}
			} else if (oper.equalsIgnoreCase("ne")) {
				

				if (value.startsWith("'") && value.endsWith("'")) {

					String actualValue = getDecoratedValue(tagContext, value);

					
					if (!actualValue.equalsIgnoreCase(srcValue)) {
						return true;
					}

				} else {
					
					String actualValue = getDecoratedIntValue(tagContext, value);

					if (StringHelper.isNumeric(value)) {

						int intActualValue = NumberUtil.parseInt(actualValue, -1);
						int intValue = NumberUtil.parseInt(srcValue, -2);
						if (intActualValue != intValue) {
							return true;
						}

					} else if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {

						boolean booleanActualValue = BooleanUtils.toBoolean(actualValue);
						boolean booleanValue = BooleanUtils.toBoolean(srcValue);

						if (booleanActualValue != booleanValue) {
							return true;
						}
					}
				}
			} else if (oper.equalsIgnoreCase("in")) {

				if (value.startsWith("'") && value.endsWith("'")) {

					String actualValue = getDecoratedValue(tagContext, value);

					String[] vals = StringHelper.split(actualValue, ",");
					for (String val : vals) {
						if (val.equalsIgnoreCase(srcValue)) {
							return true;
						}
					}
				}
			} else {
				errors.append("TRS_SWITCH标签value属性值指定表达式所使用的操作符错误，不存在的操作符，当前为" + temps[1] + "；");
				return false;
			}
		} else {
			errors.append("filterByField属性值指定表达式不能被识别，当前为" + expression + "；");
			return false;
		}
		return false;
	}

	private String getSrcValue(PublishObject publishable, String key, TagContext tagContext) {
		
		String srcValue = "";

		// 字符串
		if (key.startsWith("'") && key.endsWith("'")) {
			srcValue = getDecoratedValue(tagContext, key);
		} else if (StringHelper.isNumeric(key)) {
			srcValue = getDecoratedIntValue(tagContext, key);
		} else if (key.equalsIgnoreCase("true") || key.equalsIgnoreCase("false")) {
			return getDecoratedIntValue(tagContext, key);
		} else {
			srcValue = publishable.getPropertyAsStr(key);
		}
		
		return srcValue;
	}

	private String getDecoratedValue(TagContext tagContext, String value) {
		String actualValue = TagParserUtils.cookieStringValueDecorate(TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(
				StringHelper.substring(value, "'", "'"), tagContext), tagContext), tagContext);
		actualValue = TagParserUtils.requestBooleanValueDecorate(actualValue, tagContext);
		
		actualValue = TagParserUtils.buildRequestAttributeValue(tagContext, actualValue);
		
		this.extendsDecorate(value, tagContext);
		
		return actualValue;
	}

	/**
	 * TagParser可以通过重写此方法，扩展Switch置标的判断
	 * 
	 * @param value
	 * @param tagContext
	 * @since yangyu @ Jun 19, 2012
	 */
	protected String extendsDecorate(String value, TagContext tagContext) {
		return value;
	}

	private String getDecoratedIntValue(TagContext tagContext, String value) {
		String actualValue = TagParserUtils.cookieStringValueDecorate(TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(value,
				tagContext), tagContext), tagContext);
		actualValue = TagParserUtils.requestBooleanValueDecorate(actualValue, tagContext);
		actualValue = TagParserUtils.buildRequestAttributeValue(tagContext, actualValue);

		actualValue = this.extendsDecorate(value, tagContext);
		return actualValue;
	}
	
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_SWITCH", "DOMAIN SWITCH", BodyType.TAMPLATE);
	}
}
