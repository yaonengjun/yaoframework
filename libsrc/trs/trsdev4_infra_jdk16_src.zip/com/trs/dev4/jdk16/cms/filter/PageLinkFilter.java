/*
 * Created: liushen@Jan 30, 2012 2:09:45 PM
 */
package com.trs.dev4.jdk16.cms.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.IPageLinkManager;
import com.trs.dev4.jdk16.cms.ISiteManager;
import com.trs.dev4.jdk16.cms.PageContext;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.servlet24.BaseFilter;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 *
 */
public class PageLinkFilter extends BaseFilter implements Filter {

	private static final Logger LOG = Logger.getLogger(PageLinkFilter.class);
	
	private IPageLinkManager pageLinkMgr;
	private IContentGenerator contentGenerator;
	private ISiteManager siteManager;
	private String actionMethodParam;

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#doFilterInternal(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	protected void doFilterInternal(ServletRequest sreq, ServletResponse sresp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) sreq;
		HttpServletResponse response = (HttpServletResponse) sresp;
		RequestContext reqCtx = RequestContext.getWebRequestContext(request);
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");

		Site site = siteManager.getCurrentSite();
		if (site == null) {
			chain.doFilter(sreq, sresp);
		}else{
			
			String actionMethodPart = parseSpringMultiActionMethodPart(request);
			Map<String, Object> initObjects = loadObjectsForPageContext(request, reqCtx);
			
			PageLink pageLink = pageLinkMgr.find(reqCtx, actionMethodPart, site);
			
			if (pageLink == null || StringHelper.isEmpty(pageLink.getTemplateName())) {
				chain.doFilter(sreq, sresp);
			} else {
				PrintWriter writer = response.getWriter();
				PageContext pageContext = new PageContext(contentGenerator, reqCtx, initObjects);
				
				contentGenerator.generate(pageLink, pageContext, writer);
				
			}			
		}

	}

	/**
	 * @param request
	 * @return
	 * @since liushen @ Feb 9, 2012
	 */
	private String parseSpringMultiActionMethodPart(HttpServletRequest request) {
		if (StringHelper.isEmpty(actionMethodParam)) {
			return null;
		}
		String actionMethodValue = request.getParameter(actionMethodParam);
		if (StringHelper.isEmpty(actionMethodValue)) {
			return null;
		}
		return "?" + actionMethodParam + "=" + actionMethodValue;
	}

	/**
	 * 加载后续模板展现过程所需的上下文对象到PageContext中；本方法可供子类覆盖，以完成本系统特定的加载过程(如所浏览的用户等).
	 * 
	 * @return
	 * @since liushen @ Jan 31, 2012
	 */
	@Deprecated
	protected Map<String, Object> loadObjectsForPageContext(
			HttpServletRequest request) {
		return new HashMap<String, Object>();
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#initInternal(javax.servlet.FilterConfig)
	 */
	@Override
	protected boolean initInternal(FilterConfig config) throws ServletException {
		ServletContext application = config.getServletContext();
		WebApplicationContext applicationContext = WebApplicationContextUtils
				.getWebApplicationContext(application);
		pageLinkMgr = (IPageLinkManager) applicationContext
				.getBean("pageLinkManager");
		contentGenerator = (IContentGenerator) applicationContext
				.getBean("contentGenerator");
		siteManager = (ISiteManager) applicationContext.getBean("siteManager");
		// 解析系统使用的actionMethodParam到成员变量
		actionMethodParam = config.getInitParameter("actionMethodParam");
		LOG.info("init ok; actionMethodParam: " + (StringHelper.isEmpty(actionMethodParam) ? " not configured." : "is [" + actionMethodParam + "]"));
		afterInit(applicationContext);
		return true;
	}

	/**
	 * 加载后续模板展现过程所需的上下文对象到PageContext中；本方法可供子类覆盖，以完成本系统特定的加载过程(如所浏览的用户等).
	 * 
	 * @param reqCtx
	 * 
	 * @return
	 * @since liushen @ Jan 31, 2012
	 */
	protected Map<String, Object> loadObjectsForPageContext(HttpServletRequest request, RequestContext reqCtx) {
		return new HashMap<String, Object>();
	}

	/**
	 * 供子类完成其他成员的初始化。
	 * 
	 * @since liushen @ Jan 31, 2012
	 */
	protected void afterInit(WebApplicationContext applicationContext) {
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#destroyInternal()
	 */
	@Override
	protected void destroyInternal() {
		LOG.info("begin destory...");
		beforeDestory();
		pageLinkMgr = null;
		contentGenerator = null;
		LOG.info("destory ok.");
	}

	/**
	 * 供子类完成其他成员的销毁。
	 * 
	 * @since liushen @ Jan 31, 2012
	 */
	protected void beforeDestory() {
	}
}
