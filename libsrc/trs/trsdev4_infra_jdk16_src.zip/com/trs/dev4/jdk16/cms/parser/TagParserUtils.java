/*
 * Created: yangyu@May 21, 2012 11:52:01 AM
 */
package com.trs.dev4.jdk16.cms.parser;

import java.lang.reflect.Field;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.PageContent;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.ReflectUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 * 
 */
public class TagParserUtils {
	
	public static String userNameValueDecorate(String value, TagContext tagContext) {
		if (value.equalsIgnoreCase("currentUser.name")) {
			ISessionUser user = tagContext.getPageContext().getLoginedUser();
			if (user == null) {
				value = "Guest";
			} else {
				value = user.getUserName();
			}
		}
		return value;
	}

	/**
	 * @param substring
	 * @return
	 * @since yangyu @ Apr 10, 2012
	 */
	public static String paramStringValueDecorate(String value, TagContext tagContext) {

		if (value.startsWith("param.")) {
			String t_value = tagContext.getPageContext().getRequestContext().getParameter(value.substring(6));
			if (t_value == null) {
				return value + "can't be resolved";
			}
			value = t_value;
		}
		return value;
	}
	
	/**
	 * @param substring
	 * @return
	 * @since yangyu @ Apr 10, 2012
	 */
	public static String parentValueDecorate(String value, TagContext tagContext) {

		if (value.startsWith("parent.")) {
			String t_value = tagContext.getEntity().getPropertyAsStr(value.substring(7));
			if (t_value == null) {
				return value + "can't be resolved";
			}
			value = t_value;
		}
		return value;
	}
	
	public static String buildUrlPattern(TagContext tagContext) {
		return deleteParameter(tagContext, "pageNo");
	}
	
	public static String deleteParameter(TagContext tagContext, String param) {
		RequestContext requestContext = tagContext.getPageContext().getRequestContext();
		if (requestContext == null) {
			return "";
		}
		String queryString = requestContext.getQueryString();
		StringBuilder urlPattern = new StringBuilder(requestContext.getUri());

		if (!StringHelper.isEmpty(queryString)) {
			String[] queryStr = StringHelper.split(queryString, "&");
			StringBuilder query = new StringBuilder();

			for (String str : queryStr) {
				if (str.startsWith(param + "=")) {
					continue;
				}
				query.append(str).append("&");
			}
			if (query.length() != 0) {
				queryString = query.deleteCharAt(query.length() - 1).toString();
				urlPattern.append("?").append(queryString);
			}
		}
		
		return urlPattern.toString();
	}
	
	public static String getInnerHtml(TagItem tagItem, TagContext tagContext) {
		String innerHtml = "";

		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();

		PageContent childrenContent = new PageContent();
		PublishObject entity = tagContext.getEntity();

		for (TagItem childTag : tagItem.getChildren()) {

			if (StringHelper.isEmpty(childTag.getName())) {
				childrenContent.add(childTag);
				continue;
			}

			TagContext entityTagContext = new TagContext(tagContext, childTag);
			entityTagContext.setEntity(entity);
			contentGenerator.parseTag(childTag, childrenContent, entityTagContext.getPageContext(), entityTagContext);
		}

		innerHtml = childrenContent.merge();
		return innerHtml;
	}

	/**
	 * @param paramStringValueDecorate
	 * @param tagContext
	 * @return
	 * @since yangyu @ Jun 18, 2012
	 */
	public static String cookieStringValueDecorate(String value, TagContext tagContext) {
		if (value.startsWith("cookie.")) {
			RequestContext requestContext = tagContext.getPageContext().getRequestContext();
			if (requestContext == null) {
				return "";
			} else {
				
				String cookieValue = requestContext.getCookie(value.substring(7));
				if (StringHelper.isEmpty(cookieValue)) {
					cookieValue = "";
				}
				return cookieValue;
			}
		}
		return value;
	}

	/**
	 * @param actualValue
	 * @param tagContext
	 * @return
	 * @since yangyu @ Jun 19, 2012
	 */
	public static String requestBooleanValueDecorate(String actualValue, TagContext tagContext) {
		
		if (actualValue.equalsIgnoreCase("request.")) {
			RequestContext requestContext = tagContext.getPageContext().getRequestContext();

			String booleanValue = "";
			
			if (requestContext == null) {
				return "";
			} else {
				if (actualValue.startsWith("request.fromIOS")) {
					booleanValue = String.valueOf(RequestUtil.fromIOS(requestContext.getRequest()));
				}
			}
			return booleanValue;
		}
		
		return actualValue;
	}
	
	/**
	 * @param tagItem
	 * @param tagContext
	 * @param stringValue
	 * @return
	 * @since yangyu @ Jul 5, 2012
	 */
	public static String buildRequestAttributeValue(TagContext tagContext, String stringValue) {

		if (stringValue.startsWith("requestAttribute.")) {
			String value = stringValue.substring(17);
			RequestContext requestContext = tagContext.getPageContext().getRequestContext();
			if (requestContext == null) {
				return "requestContext is not exist";
			}
			return String.valueOf(requestContext.getAttribute(StringHelper.substring(value, "", ".")));
		}

		return stringValue;
	}

	/**
	 * @param string
	 * @param paramStringValueDecorate
	 * @param tagContext
	 * @param tagAware
	 * @return
	 * @since yangyu @ Jun 26, 2012
	 */
	public static Object enumValueDecorate(String key, String value, TagContext tagContext, ITagAware tagAware) {

		if (value.startsWith("enumValue.")) {
			Field field = ReflectUtil.getField(tagAware.getTagClass(), key);
			try {
				return field.getType().getField(value.substring(10)).get(field.getType());
			} catch (Exception e) {
				return null;
			}
		}
		return null;
	}
	
	public static String writeError(String error) {
		return "****ErrorMessage:" + error + " ******";
	}
}
