package com.trs.dev4.jdk16.cms;

import java.util.Map;

import net.sf.cglib.beans.BeanMap;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 置标组件解析对象
 * 
 * @author Administrator
 * 
 */
public class PublishObject{

	private BeanMap beanMappedObject; 
	
	private Object mappedObject;
	
	private int index;
	
	public Object getProperty(String name) {
		Object obj = null;
		
		if (name.equalsIgnoreCase("index")) {
			obj = index + 1;
		} else {
			if (mappedObject instanceof Map<?, ?>) {
				obj = ((Map) mappedObject).get(name);
			} else {
				obj = beanMappedObject.get(name);
			}

			if (null == obj) {
				return null;
			}
		}
		
		return obj;
	}
	
	public int getPropertyAsInt(String name) {
		Object obj = null;
		if (name.equalsIgnoreCase("index")) {
			obj = index + 1;
		} else {
			if (mappedObject instanceof Map<?, ?>) {
				obj = ((Map) mappedObject).get(name);
			} else {
				obj = beanMappedObject.get(name);
			}
			if (null == obj) {
				return -1;
			}
		}
		return StringHelper.parseInt(obj.toString());
	}
	
	public String getPropertyAsStr(String name) {
		
		Object obj = null;
		
		if (name.equalsIgnoreCase("index")) {
			obj = index + 1;
		} else {
			if (mappedObject instanceof Map<?, ?>) {
				obj = ((Map) mappedObject).get(name);
			} else {
				obj = beanMappedObject.get(name);
			}
			if (null == obj) {
				return null;
			}
		}
		return obj.toString();
	}

	protected PublishObject(){
		
	}
	
	public PublishObject(Object object){
		beanMappedObject = BeanMap.create(object);
		mappedObject = object;
	}

	public void put(String key,Object value){
		beanMappedObject.put(key, value);
	}


	/**
	 * @return the mappedObjectClass
	 */
	public Object getMappedObject() {
		return mappedObject;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public BeanMap getBeanMappedObject() {
		return beanMappedObject;
	}

	public void setBeanMappedObject(BeanMap beanMappedObject) {
		this.beanMappedObject = beanMappedObject;
	}

	public void setMappedObject(Object mappedObject) {
		this.mappedObject = mappedObject;
	}
	
	
}
