package com.trs.dev4.jdk16.cms.impl;

import java.util.LinkedList;
import java.util.List;

/**
 * 描述模板置标中的形式参数
 * 
 * 因为按照目前的设计，置标中的形式参数不保存到数据库，而是解析后存在于缓存中，所以没有把该类放在包
 * “com.trs.components.common.publish.persistent.template”中。
 * 
 * @author Martin (付成睿)
 */
public class TemplateParameter {

	/**
	 * 形式参数的类型
	 */
    public static class Type {

		/**
		 * 逻辑类型的变量，其值必须是10个数字和减号
		 */
        public final static Type BOOLEAN = new Type("BOOLEAN", "B");

		/**
		 * 整数类型的变量，其值必须是10个数字和减号
		 */
        public final static Type INTEGER = new Type("INTEGER", "I");

		/**
		 * 数值类型的变量，其值必须是10个数字、减号和小数点
		 */
        public final static Type NUMBER = new Type("NUMBER", "N");

		/**
		 * 字符串类型的变量，其值可以是任意字符串
		 */
        public final static Type STRING = new Type("STRING", "S");

        public final static Type MULTI = new Type("MULTI", "M");

		/**
		 * 变量类型的名称
		 */
        private String m_sName;

		/**
		 * 变量类型的名称
		 */
        private String m_sAlias;

		/**
		 * 私有的构造函数，不得外部实例化
		 * 
		 * @param name
		 *            变量类型的名称
		 */
        private Type(String name, String alias) {
            m_sName = name;
            m_sAlias = alias;
        }

		/**
		 * 返回变量类型的名称
		 * 
		 * @return 变量类型的名称
		 */
        public String getName() {
            return m_sName;
        }

		/**
		 * 返回变量类型的别名
		 * 
		 * @return 变量类型的别名
		 */
        public String getAlias() {
            return m_sAlias;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#toString()
         */
        @Override
		public String toString() {
            return "TemplateParameter.Type." + m_sName;
        }

    }

	/**
	 * 形式参数的候选值
	 */
    public static class Token {

		/**
		 * 可用值
		 */
        private String m_sValue;

		/**
		 * 可用值的显示信息
		 */
        private String m_sDisplay;

		/**
		 * 私有的构造函数，不得外部实例化
		 * 
		 * @param value
		 *            可用值
		 * @param display
		 *            可用值的显示信息
		 */
        private Token(String value, String display) {
            m_sValue = value;
            m_sDisplay = display;
        }

		/**
		 * 返回可用值的值
		 * 
		 * @return 可用值的值
		 */
        public String getValue() {
            return m_sValue;
        }

		/**
		 * 返回可用值的显示信息
		 * 
		 * @return 可用值的显示信息
		 */
        public String getDisplay() {
            return m_sDisplay;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#toString()
         */
        @Override
		public String toString() {
            return "TemplateParameter.Token." + m_sValue;
        }

    }

    private static Type[] VALID_TYPES = { Type.BOOLEAN, Type.INTEGER,
            Type.NUMBER, Type.STRING, Type.MULTI };

    private int m_iTemplateId;

    private String m_sTemplateName;

    private String m_sParameterName;

    private Type m_sParameterType;

    private String m_sParameterDefault;

    private String m_sParameterDefaultValue;

    private String m_sParameterDefaultDisplay;

	private List<Token> m_oEnumList;

    private Token[] m_sEnumValue;

	/**
	 * 用于分隔枚举的实际值和显示值的分隔字符，缺省为'`'，即键盘左上角的字符。
	 */
    private char m_cEnumSplit = '`';

    private int m_iCustomFlag;

	/**
	 * 预先声明同名变量时使用的对象
	 */
    private TemplateParameter m_oPreDeclared;

	/**
	 * 缺省构造方法
	 */
    public TemplateParameter() {
        setCanCustomDefault(true);
        m_sParameterType = Type.STRING;
    }

	/**
	 * 返回预先声明同名变量时使用的对象
	 * 
	 * @return 预先声明同名变量时使用的对象
	 */
    public TemplateParameter getPreDeclared() {
        return m_oPreDeclared;
    }

	/**
	 * 设置预先声明同名变量时使用的对象
	 * 
	 * @param preDeclared
	 *            预先声明同名变量时使用的对象
	 */
    public void setPreDeclared(TemplateParameter preDeclared) {
        m_oPreDeclared = preDeclared;
    }

	/**
	 * 返回形式参数的名称
	 * 
	 * @return 形式参数的名称
	 */
    public String getParameterName() {
        return m_sParameterName;
    }

	/**
	 * 设置形式参数的名称
	 * 
	 * @param parameterName
	 *            形式参数的名称
	 */
    public void setParameterName(String parameterName) {
        m_sParameterName = parameterName;
    }

	/**
	 * 返回形式参数的类型
	 * 
	 * @return 形式参数的类型
	 */
    public Type getParameterType() {
        return m_sParameterType;
    }

	/**
	 * 设置形式参数的类型
	 * 
	 * @param parameterType
	 *            形式参数的类型
	 */
    public void setParameterType(Type parameterType) {
        m_sParameterType = parameterType;
    }

	/**
	 * 设置形式参数的类型
	 * 
	 * @param parameterType
	 *            形式参数的类型的名称
	 */
    public void setParameterType(String sTypeName) {
        if (sTypeName == null || sTypeName.length() <= 0) {
            setParameterType(Type.STRING);
            return;
        }
        sTypeName = sTypeName.toUpperCase();
        for (int i = VALID_TYPES.length - 1; i >= 0; i--) {
            Type type = VALID_TYPES[i];
            if (sTypeName.equals(type.getName())
                    || sTypeName.equals(type.getAlias())) {
                setParameterType(type);
                return;
            }
        }
        setParameterType(Type.STRING);
    }

	/**
	 * 返回形式参数缺省值的完全设置
	 * 
	 * @return 形式参数的缺省值
	 */
    public String getParameterDefault() {
        return m_sParameterDefault;
    }

	/**
	 * 返回形式参数缺省值的有效值
	 * 
	 * @return 形式参数的缺省值
	 */
    public String getParameterDefaultValue() {
        if (m_oPreDeclared != null) {
            return m_oPreDeclared.getParameterDefaultValue();
        }
        return m_sParameterDefaultValue;
    }

	/**
	 * 返回形式参数缺省值的显示值
	 * 
	 * @return 形式参数的缺省值
	 */
    public String getParameterDefaultDisplay() {
        return m_sParameterDefaultDisplay;
    }

	/**
	 * 设置形式参数的缺省值
	 * 
	 * @param parameterDefault
	 *            形式参数的缺省值
	 */
    public void setParameterDefault(String parameterDefault) {
        if (parameterDefault != null) {
            int iSplit = parameterDefault.indexOf(m_cEnumSplit);
            if (iSplit >= 0) {
                m_sParameterDefaultValue = parameterDefault
                        .substring(0, iSplit);
                m_sParameterDefaultDisplay = parameterDefault
                        .substring(iSplit + 1);
            } else {
                m_sParameterDefaultValue = parameterDefault;
                m_sParameterDefaultDisplay = parameterDefault;
            }
        } else {
            m_sParameterDefaultValue = null;
            m_sParameterDefaultDisplay = null;
        }
        m_sParameterDefault = parameterDefault;
    }

	/**
	 * 返回有效的变量值的列表数组，如果变量值不是枚举类型，则返回 <code>null</code>。
	 * 
	 * @return 有效的变量值的列表数组或者 <code>null</code>
	 */
    public Token[] getEnumValue() {
        if (m_sEnumValue == null && m_oEnumList != null
                && m_oEnumList.size() > 0) {
            Token[] tokens = new Token[m_oEnumList.size()];
            m_oEnumList.toArray(tokens);
            m_sEnumValue = tokens;
        }
        return m_sEnumValue;
    }

	/**
	 * 添加可选择变量值的枚举
	 * 
	 * @param value
	 *            变量值的枚举值，认为其实际值和显示值采用 <code>m_cEnumSplit</code> 分隔
	 * 
	 * @see #setEnumSplit(char)
	 * @see #addEnumValue(String, String)
	 */
    public void addEnumValue(String value) {
        if (value != null) {
            int iSplit = value.indexOf(m_cEnumSplit);
            if (iSplit >= 0) {
                String sVal = value.substring(0, iSplit);
                String sDis = value.substring(iSplit + 1);
                addEnumValue(sVal, sDis);
            } else {
                addEnumValue(value, value);
            }
			// 清除已经构造好的枚举数组，如果存在的话
            m_sEnumValue = null;

            // wenyh@2006-4-3 16:44:01 add comment:
            // change to set the flag in addEnumValue(String,String) method;
			// 清除缺省的可定制标志
            // setCanCustomDefault(false);
        }
    }

	/**
	 * 添加可选择变量值的枚举
	 * 
	 * @param value
	 *            枚举值的实际值
	 * @param display
	 *            枚举值的显示值，可以为 <code>null</code> ，则显示值等于实际值
	 */
    public void addEnumValue(String value, String display) {
        if (value == null) {
			// 错误，直接返回
            return;
        }
        if (display == null) {
            display = value;
        }
        if (m_oEnumList == null) {
			m_oEnumList = new LinkedList<Token>();
        }
        m_oEnumList.add(new Token(value, display));

		// 清除缺省的可定制标志
        setCanCustomDefault(false);
    }

	/**
	 * 返回和指定的枚举值相关联的枚举显示名称，如果没有显示名称和该枚举值相关联， 则返回 <code>null</code>。
	 * 
	 * @return 和指定的枚举值相关联的枚举显示名称或者 <code>null</code>
	 */
    public String getEnumValueDisplay(String sEnumValue) {
        if (sEnumValue == null) {
            return null;
        }

        Token[] tokens = getEnumValue();
        if (tokens != null) {
            for (int i = tokens.length - 1; i >= 0; i--) {
                Token token = tokens[i];
                if (token != null
                        && (sEnumValue.equals(token.m_sValue) || sEnumValue
                                .equalsIgnoreCase(token.m_sValue)
                                && Type.BOOLEAN.getName().equals(
                                        m_sParameterType.getName()))) {
					// wenyh@2006-4-4 9:05:31 add comment:如果是布尔型,忽略大小写
                    return token.m_sDisplay;
                }
            }
        }

        return sEnumValue;
    }

	/**
	 * 返回枚举值的分隔字符
	 * 
	 * @return 枚举值的分隔字符
	 */
    public char getEnumSplit() {
        return m_cEnumSplit;
    }

	/**
	 * 设置枚举值的分隔字符
	 * 
	 * @param enumSplit
	 *            枚举值的分隔字符
	 */
    public void setEnumSplit(char enumSplit) {
        m_cEnumSplit = enumSplit;
    }

	/**
	 * 返回是否可以定制变量取值
	 * 
	 * @return 是否可以定制
	 */
    public boolean getCanCustom() {
        return m_iCustomFlag != 0;
    }

	/**
	 * 设置是否可以定制变量取值，不能定制变量取值，即只能从现有的枚举值中选择。
	 * 
	 * @param canCustom
	 *            是否可以定制
	 */
    public void setCanCustom(boolean canCustom) {
        if (canCustom)
            m_iCustomFlag |= 2;
        else
            m_iCustomFlag = 0;
    }

	/**
	 * 设置是否可以定制变量取值，缺省值部分
	 * 
	 * @param canCustom
	 *            是否可以定制
	 */
    private final void setCanCustomDefault(boolean canCustom) {
        if (canCustom)
            m_iCustomFlag |= 1;
        else
            m_iCustomFlag &= ~1;
    }

	/**
	 * 返回形式参数所在模板的ID
	 * 
	 * @return 形式参数所在模板的ID
	 */
    public int getTemplateId() {
        return m_iTemplateId;
    }

	/**
	 * 设置模板的ID
	 * 
	 * @param templateId
	 *            模板的ID
	 */
    public void setTemplateId(int templateId) {
        m_iTemplateId = templateId;
    }

	/**
	 * 返回形式参数所在模板的名称
	 * 
	 * @return 形式参数所在模板的名称
	 */
    public String getTemplateName() {
        return m_sTemplateName;
    }

	/**
	 * 设置模板的名称
	 * 
	 * @param templateName
	 *            模板的名称
	 */
    public void setTemplateName(String templateName) {
        m_sTemplateName = templateName;
    }

}