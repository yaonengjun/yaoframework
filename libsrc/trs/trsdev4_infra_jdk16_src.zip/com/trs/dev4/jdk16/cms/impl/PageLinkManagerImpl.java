package com.trs.dev4.jdk16.cms.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.IPageLinkManager;
import com.trs.dev4.jdk16.cms.ITemplateAware;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 链接管理
 * 
 * @author yangyu
 * @since 2011-5-31
 */
public class PageLinkManagerImpl extends CachedBaseManager<PageLink> implements
		IPageLinkManager {

	@Override
	public PageLink getByName(String urlPattern) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("urlPattern", urlPattern);
		return super.findFirst(sf, true);
	}

	/**
	 * @see IPageLinkManager#save(com.trs.dev4.jdk16.cms.bo.PageLink)
	 */
	@Override
	public PageLink save(PageLink newLink) {
		super.saveOrUpdate(newLink);
		return newLink;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IPageLinkManager#registerTemplateAware(com.trs.dev4.jdk16.cms.ITemplateAware)
	 * @since liushen @ Feb 1, 2012
	 */
	@Override
	public void registerTemplateAware(ITemplateAware bean) {
		if (bean == null) {
			return;
		}
		awares.put(bean.getClass().getName(), bean);
	}

	public PageLink find(RequestContext reqCtx, String actionMethodPart, Site site) {
		SearchFilter sf = SearchFilter.getDefault();
		String urlPattern = reqCtx.getUriAfterContextPath();
		if (StringHelper.isNotEmpty(actionMethodPart)) {
			urlPattern += actionMethodPart;
		}
		String httpMethod = reqCtx.getHttpMethod();
		sf.addEqCondition("urlPattern", urlPattern);
		if (HTTP_GET.equalsIgnoreCase(httpMethod)) {
			sf.addEqCondition("httpMethod", HTTP_GET);
		} else {
			sf.addLike("httpMethod", "%" + httpMethod);
		}

		if (site != null) {
			sf.addEqCondition("siteId", site.getId());
		}

		return super.findFirst(sf, true);
	}
	
	/**
	 * @see com.trs.dev4.jdk16.cms.IPageLinkManager#findTemplateName(RequestContext, String, Site)
	 */
	@Override
	public String findTemplateName(RequestContext reqCtx, String actionMethodPart, Site site) {
		
		PageLink pageLink = this.find(reqCtx, actionMethodPart, site);
		String result = findTemplateNameInternal(reqCtx, pageLink);
		return result;
	}

	/**
	 * @param reqCtx
	 * @param pageLink
	 * @return
	 * @since liushen @ Feb 2, 2012
	 */
	String findTemplateNameInternal(RequestContext reqCtx, PageLink pageLink) {
		if (pageLink == null) {
			return null;
		}
		String templateAwareImpl = pageLink.getTemplateAwareImpl();
		if (StringHelper.isEmpty(templateAwareImpl)) {
			return pageLink.getTemplateName();
		}
		ITemplateAware templateAware = findTemplateAware(templateAwareImpl);
		if (LOG.isDebugEnabled()) {
			LOG.debug("findTemplateAware: " + templateAwareImpl + " for [" + reqCtx.getUriWithQueryString() + "]: [" + templateAware + "]");
		}
		if (templateAware != null) {
			return templateAware.resolveTemplateName(reqCtx);
		}
		return pageLink.getTemplateName();
	}

	/**
	 * @param templateAwareImpl
	 * @return
	 * @since liushen @ Feb 1, 2012
	 */
	private ITemplateAware findTemplateAware(String templateAwareImpl) {
		return awares.get(templateAwareImpl);
	}
	
	private Map<String, ITemplateAware> awares = new HashMap<String, ITemplateAware>();

	static final String HTTP_GET = "GET";
	static final String HTTP_POST = "POST";

	private static final Logger LOG = Logger.getLogger(PageLinkManagerImpl.class);

}
