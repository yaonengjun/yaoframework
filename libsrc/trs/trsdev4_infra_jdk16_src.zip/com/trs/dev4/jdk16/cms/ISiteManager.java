/**
 * 
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 职责：站点管理接口，参见{@link IBaseManager}<br>
 * 
 * @author TRS信息技术股份有限公司
 * 
 * @since 2012-2-9
 * 
 */
public interface ISiteManager extends IBaseManager<Site>{
	
	/**
	 * 获取当前的站点
	 * 
	 * @return
	 * @since yangyu @ May 30, 2012
	 */
	public Site getCurrentSite();
	
}
