/*
 * Created: 2011-5-31
 */
package com.trs.dev4.jdk16.cms.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.model.BaseEntity;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 维护URL和模板展现、行为之间的关系.
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "pageLink")
@org.hibernate.annotations.GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_PAGELINK_ID") })
public class PageLink extends BaseEntity {
	
	public PageLink(){}

	/**
	 * 显示名称，需唯一.
	 */
	private String name;

	/**
	 * 该请求的URL模式，从contextPath后开始，不包括contextPath本身，比如，http://dev4.trs.net.cn/mas/
	 * my /main.do?action=foo&param1=bar，其URL模式则是/my/main.do?action=foo&param1=
	 * bar
	 */
	private String urlPattern;

	/**
	 * 该请求是GET方法还是POST方法；如果二者都适用则为"GETorPOST".
	 */
	private String httpMethod;

	/**
	 * 该URL使用的模板名.
	 */
	private String templateName;

	/**
	 * 额外解析模板的实现类的标识，用于根据URL中某个参数值不同来返回不同模板的情况; 如果没有这种需要，该属性设为<code>null</code>
	 * 即可。
	 */
	private String templateAwareImpl;

	/**
	 * 处理GET请求前，要执行的操作(脚本代码).
	 */
	private String beforeHttpGet;

	/**
	 * GET请求处理完成后，要执行的操作(脚本代码).
	 */
	private String afterHttpGet;

	/**
	 * 对于POST请求，使用的模板名.
	 */
	private String templateNameOfHttpPost;

	/**
	 * 处理POST请求前，要执行的操作(脚本代码).
	 */
	private String beforeHttpPost;

	/**
	 * POST请求处理完成后，要执行的操作(脚本代码).
	 */
	private String afterHttpPost;

	/**
	 * 站点Id
	 */
	@Column(name = "`siteId`")
	private int siteId;
	
	@Column(name = "`PARSERTYPE`")
	@Enumerated(value = EnumType.STRING)
	private ParserType parserType;
	
	public static enum ParserType {
		COMMON("common"), BIGPIPE("bigpipe");

		private String description;

		/**
		 * 
		 * @since liushen @ May 26, 2011
		 */
		private ParserType(String description) {
			this.description = description;
		}

		/**
		 * @see java.lang.Enum#toString()
		 * @since liushen @ May 26, 2011
		 */
		@Override
		public String toString() {
			return description;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseEntity#toString()
	 * @since liushen @ Feb 7, 2012
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[").append(getClass().getSimpleName()).append("@").append(Integer.toHexString(hashCode()));
		builder.append(", id=").append(getId());
		builder.append(", uri: ").append(getUrlPattern());
		builder.append(", httpMethod=").append(getHttpMethod());
		builder.append(", templateName=").append(getTemplateName());
		if (StringHelper.isEmpty(templateAwareImpl)) {
			builder.append("; no templateAwareImpl");
		} else {
			builder.append(", templateAwareImpl=").append(getTemplateAwareImpl());
		}
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the urlPattern
	 */
	public String getUrlPattern() {
		return urlPattern;
	}

	/**
	 * @param urlPattern the urlPattern to set
	 */
	public void setUrlPattern(String urlPattern) {
		this.urlPattern = urlPattern;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Get the {@link #templateName}.
	 * 
	 * @return the {@link #templateName}.
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * Set the {@link #templateName}.
	 * 
	 * @param templateName
	 *            the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * Get the {@link #beforeHttpGet}.
	 * 
	 * @return the {@link #beforeHttpGet}.
	 */
	public String getBeforeHttpGet() {
		return beforeHttpGet;
	}

	/**
	 * Set the {@link #beforeHttpGet}.
	 * 
	 * @param beforeHttpGet
	 *            the beforeHttpGet to set
	 */
	public void setBeforeHttpGet(String beforeHttpGet) {
		this.beforeHttpGet = beforeHttpGet;
	}

	/**
	 * Get the {@link #afterHttpGet}.
	 * 
	 * @return the {@link #afterHttpGet}.
	 */
	public String getAfterHttpGet() {
		return afterHttpGet;
	}

	/**
	 * Set the {@link #afterHttpGet}.
	 * 
	 * @param afterHttpGet
	 *            the afterHttpGet to set
	 */
	public void setAfterHttpGet(String afterHttpGet) {
		this.afterHttpGet = afterHttpGet;
	}

	/**
	 * Get the {@link #templateNameOfHttpPost}.
	 * 
	 * @return the {@link #templateNameOfHttpPost}.
	 */
	public String getTemplateNameOfHttpPost() {
		return templateNameOfHttpPost;
	}

	/**
	 * Set the {@link #templateNameOfHttpPost}.
	 * 
	 * @param templateNameOfHttpPost
	 *            the templateNameOfHttpPost to set
	 */
	public void setTemplateNameOfHttpPost(String templateNameOfHttpPost) {
		this.templateNameOfHttpPost = templateNameOfHttpPost;
	}

	/**
	 * Get the {@link #beforeHttpPost}.
	 * 
	 * @return the {@link #beforeHttpPost}.
	 */
	public String getBeforeHttpPost() {
		return beforeHttpPost;
	}

	/**
	 * Set the {@link #beforeHttpPost}.
	 * 
	 * @param beforeHttpPost
	 *            the beforeHttpPost to set
	 */
	public void setBeforeHttpPost(String beforeHttpPost) {
		this.beforeHttpPost = beforeHttpPost;
	}

	/**
	 * Get the {@link #afterHttpPost}.
	 * 
	 * @return the {@link #afterHttpPost}.
	 */
	public String getAfterHttpPost() {
		return afterHttpPost;
	}

	/**
	 * Set the {@link #afterHttpPost}.
	 * 
	 * @param afterHttpPost
	 *            the afterHttpPost to set
	 */
	public void setAfterHttpPost(String afterHttpPost) {
		this.afterHttpPost = afterHttpPost;
	}

	/**
	 * Get the {@link #httpMethod}.
	 * 
	 * @return the {@link #httpMethod}.
	 */
	public String getHttpMethod() {
		return httpMethod;
	}

	/**
	 * Set the {@link #httpMethod}.
	 * 
	 * @param httpMethod
	 *            the httpMethod to set
	 */
	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	/**
	 * @return the {@link #templateAwareImpl}
	 */
	public String getTemplateAwareImpl() {
		return templateAwareImpl;
	}

	/**
	 * @param templateAwareImpl
	 *            the {@link #templateAwareImpl} to set
	 */
	public void setTemplateAwareImpl(String templateAwareImpl) {
		this.templateAwareImpl = templateAwareImpl;
	}

	/**
	 * @return the {@link #siteId}
	 */
	public int getSiteId() {
		return siteId;
	}

	/**
	 * @param siteId
	 *            the {@link #siteId} to set
	 */
	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}

	public ParserType getParserType() {
		return parserType;
	}

	public void setParserType(ParserType parserType) {
		this.parserType = parserType;
	}

}
