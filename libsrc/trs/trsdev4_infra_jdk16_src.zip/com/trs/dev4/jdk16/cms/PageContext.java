package com.trs.dev4.jdk16.cms;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 发布的上下文
 * 
 */
public class PageContext {
	/**
	 * 
	 */
	private Map<String, String> m_extraAttributes;

	private RequestContext requestContext;

	private Map<String, Object> contextObjects = new ConcurrentHashMap<String, Object>();

//	private ApplicationContext applicationContext;

	// private IConfigManager configManager;

	private Locale locale;

	private ISessionUser loginedUser;

	private Map<String, String> fakeParameters = null;

	private Map<String, Object> contextObjectsByClass = new ConcurrentHashMap<String, Object>();
	/**
	 * 
	 */
	private Map<String, String> m_variableAttributes;
	/**
     * 
     */
	private Template m_oTemplate = null;

	/**
	 * buffer for warnings
	 */
	private StringBuffer m_buffWarnings = null;

	/**
	 * 发布后的文件名，只有细览才有意义，而且只包括细览的第一个页面
	 */
	private String m_sFileName = null;
	/**
     * 
     */
	private IContentGenerator contentGenerator = null;

	/**
	 * constructor
	 * 
	 * @param pageContext
	 *            the Original PublishPageContext
	 */
	protected PageContext(IContentGenerator contentGenerator) {
		this.contentGenerator = contentGenerator;
	}

	/**
	 * @see IClearable#clear()
	 */
	public void clear() {
		if (m_buffWarnings != null) {
			m_buffWarnings.setLength(0);
		}
	}

	// =========================================================================
	// handle warnings

	/**
	 * add warning
	 * 
	 * @param _sTitle
	 *            title of the warning
	 * @param _sDesc
	 *            detailed description for the warning
	 */
	public void addWarning(String _sObjName, int _nObjId, String _sDesc) {
		if (m_buffWarnings == null) {
			m_buffWarnings = new StringBuffer();
		}
		m_buffWarnings.append(_sObjName).append("(ID=").append(_nObjId)
				.append("): ");
		m_buffWarnings.append(_sDesc).append("\n");
	}

	/**
	 * add warning
	 * 
	 * @param _sDesc
	 *            detailed description for the warning
	 */
	public void addWarning(String _sDesc) {
		if (m_buffWarnings == null) {
			m_buffWarnings = new StringBuffer();
		}
		m_buffWarnings.append(_sDesc).append("\n");
	}

	/**
	 * Returns the warnings as string; returns null if no warnings.
	 * 
	 * @return the warnings as string; returns null if no warnings
	 */
	public String getWarnings() {
		return m_buffWarnings == null ? null : m_buffWarnings.toString();
	}

	/**
	 * Returns <code>true</code> if there is warnings.
	 * 
	 * @return <code>true</code> if there is warnings
	 */
	public boolean hasWarnings() {
		return m_buffWarnings != null;
	}

	/**
	 * @return Returns the fileName.
	 */
	public String getFileName() {
		return m_sFileName;
	}

	/**
	 * @param fileName
	 *            The fileName to set.
	 */
	public void setFileName(String fileName) {
		m_sFileName = fileName;
	}

	/**
	 * Returns the specified extra attribute.
	 * 
	 * @param _sName
	 *            style name
	 * @return the specified attribute value.
	 */
	public String getExtraAttribute(String _sName) {
		if (m_extraAttributes == null)
			return null;

		// else
		return m_extraAttributes.get(_sName.toUpperCase());
	}

	public void setExtraAttribute(String _sName, String _sValue) {
		if (m_extraAttributes == null) {
			m_extraAttributes = new HashMap<String, String>(1);
		}
		m_extraAttributes.put(_sName.toUpperCase(), _sValue);
	}

	/**
	 * 获取相关模板
	 * 
	 * @return
	 */
	public Template getTemplate() {
		return m_oTemplate;
	}

	/**
	 * 设置相关模板
	 * 
	 * @param template
	 */
	public void setTemplate(Template template) {
		m_oTemplate = template;
	}

	/**
	 * 返回指定变量的赋值
	 * 
	 * @param _sName
	 *            变量名称
	 * @return 变量的赋值
	 */
	public String getVariableAttribute(String _sName) {
		if (_sName == null) {
			return null;
		}
		if (m_variableAttributes == null) {
			return null;
		}
		return m_variableAttributes.get(_sName);
	}

	/**
	 * 给指定的变量赋值
	 * 
	 * @param _sName
	 *            变量名
	 * @param _sValue
	 *            变量值
	 */
	public void setVariableAttribute(String _sName, String _sValue) {
		if (_sName == null || _sName.length() <= 0) {
			return;
		}
		if (m_variableAttributes == null) {
			m_variableAttributes = new HashMap<String, String>();
		}
		m_variableAttributes.put(_sName.toUpperCase(), _sValue);
	}

	/**
	 * @return the {@link #contentGenerator}
	 */
	public IContentGenerator getContentGenerator() {
		return contentGenerator;
	}

	/**
	 * @param contentGenerator
	 * @param requestContext
	 * @param initObjects
	 */
	public PageContext(IContentGenerator contentGenerator,
			RequestContext requestContext, Map<String, Object> initObjects) {

		this.contentGenerator = contentGenerator;
		this.requestContext = requestContext;
		if (null != initObjects) {
			this.contextObjects.putAll(initObjects);
			this.loginedUser = (ISessionUser) contextObjects.get("loginedUser");
			this.locale = (Locale) contextObjects.get("locale");
		}
	}

	/**
	 * 从request 中取得 header
	 * 
	 * @param headerName
	 * @param defaultVal
	 * @return
	 */
	public String getRequestHeader(String headerName, String defaultVal) {
		if (null == requestContext) {
			return defaultVal;
		}
		return requestContext.getHeader(headerName);
	}

	/**
	 * 从request 中取得 header
	 * 
	 * @param headerName
	 * @return
	 */
	public String getRequestHeader(String headerName) {
		return this.getRequestHeader(headerName, null);
	}

	/**
	 * @param cookieName
	 * @param defaultVal
	 * @return
	 */
	public String getRequestCookie(String cookieName, String defaultVal) {
		if (null == requestContext) {
			return defaultVal;
		}
		return requestContext.getCookie(cookieName);
	}

	/**
	 * @param cookieName
	 * @return
	 */
	public String getRequestCookie(String cookieName) {
		return this.getRequestCookie(cookieName, null);
	}

	/**
	 * @param cookieName
	 * @param defaultVal
	 * @return
	 */
	public int getRequestCookie(String cookieName, int defaultVal) {
		String requestCookie = this.getRequestCookie(cookieName);
		if (StringHelper.isEmpty(requestCookie)) {
			return defaultVal;
		}
		return StringHelper.parseInt(requestCookie);
	}

	/**
	 * 获取int类型的参数
	 * 
	 * @param parameterName
	 * @param defaultVal
	 * @return
	 */
	public int getRequestParameter(String parameterName, int defaultVal) {
		if (null == requestContext) {
			return defaultVal;
		}
		String parameter = requestContext.getParameter(parameterName);
		if (StringHelper.isEmpty(parameter)) {
			return fakeParameters != null ? StringHelper.parseInt(fakeParameters.get(parameterName)) : defaultVal;
		}
		return StringHelper.parseInt(parameter);
	}

	/**
	 * 获取String类型的参数
	 * 
	 * @param parameterName
	 * @param defaultVal
	 * @return
	 */
	public String getRequestParameter(String parameterName, String defaultVal) {
		if (null == requestContext) {
			return defaultVal;
		}
		String parameter = requestContext.getParameter(parameterName);
		if (StringHelper.isEmpty(parameter)) {
			return fakeParameters != null ? fakeParameters.get(parameterName) : defaultVal;
		}

		return parameter;
	}

	/**
	 * 获取Attribute里面的对象
	 * 
	 * @return
	 */
	public Object getRequestAttribute(String attributeName) {
		if (null == requestContext) {
			return null;
		}
		return requestContext.getAttribute(attributeName);
	}

	/**
	 * 获取Attribute里面的int类型对象；
	 * 
	 * @param attributeName
	 * @param defaultVal
	 * @return
	 */
	public int getRequestAttribute(String attributeName, int defaultVal) {

		String attribute = getRequestAttribute(attributeName, null);
		if (StringHelper.isEmpty(attribute)) {
			return defaultVal;
		}
		return StringHelper.parseInt(attribute);
	}

	/**
	 * 获取Attribute里面的int类型对象；
	 * 
	 * @param attributeName
	 * @param defaultVal
	 * @return
	 */
	public String getRequestAttribute(String attributeName, String defaultVal) {
		if (null == requestContext) {
			return defaultVal;
		}
		Object object = getRequestAttribute(attributeName);
		if (null == object) {
			return defaultVal;
		}
		return object.toString();
	}

	// /**
	// *
	//获取application范围的对象,ObjectScope:Application,Request,Session,Page,Context,All
	// * @param name
	// * @param scope
	// * @return
	// */
	// Object findObject(String name) {
	// ths
	// return null;
	// }

	// String getApplicationContext(){}// 获取Spring的ApplicationContext对象；

	/**
	 * @param varName
	 * @param object
	 */
	public Object registerObject(String varName, Object object) {
		contextObjectsByClass.put(object.getClass().getSimpleName(), object);
		return contextObjects.put(varName, object);
	}

	/**
	 * @param varName
	 */
	public Object unregisterObject(String varName) {
		Object object = contextObjects.remove(varName);
		if (null != object) {
			contextObjectsByClass.remove(object.getClass().getSimpleName());
		}
		return object;
	}

	/**
	 * 判断是否已经登陆
	 * 
	 * @return
	 */
	public boolean isLogined() {
		if (null == requestContext) {
			return false;
		}
		return loginedUser != null;
	}

	/**
	 * 获取当前登陆的用户
	 * 
	 * @return
	 */
	public ISessionUser getLoginedUser() {
		return this.loginedUser;
	}

	/**
	 * 获取当前指定类型的对象
	 * 
	 * @param clazz
	 * @return
	 */
	public PublishObject getCurrentObject(String className) {
		Object object = contextObjectsByClass.get(className);
		if (null == object) {
			return null;
		}
		return this.wrap(object);
	}

	/**
	 * 根据变量名获取对象
	 * 
	 * @param varName
	 * @return
	 */
	public PublishObject findObject(String varName) {
		Object object = contextObjects.get(varName);
		if (null == object) {
			return null;
		}
		return wrap(object);
	}

	// /**
	// * 获取系统配置
	// *
	// * @return
	// */
	// public IConfigManager getConfigManager() {
	// return this.configManager;
	// }
	//
	/**
	 * @return
	 */
	public Locale getLocale() {
		return this.locale;
	}

	/**
	 * 集合封装
	 * 
	 * @param objects
	 * @return
	 */
	// public PagedList<PublishObject> wrap(PagedList<Object> objects) {
	// return null;
	// }
	/**
	 * 适当的封装
	 * 
	 * @param object
	 * @return
	 */
	public PublishObject wrap(Object object) {
		PublishObject entity = null;
		if (object instanceof PublishObject) {
			entity = (PublishObject) object;
		} else {
			entity = new PublishObject(object);
		}
		return entity;
	}

	/**
	 * 增加测试用的请求request参数,仅供单元测试用。
	 * 
	 * @param parameterName
	 * @param parameterValue
	 */
	public void setFakeParameter(String parameterName, String parameterValue) {
		if (null == parameterName || null == parameterValue) {
			return;
		}
		if (fakeParameters == null) {
			fakeParameters = new HashMap<String, String>();
		}
		fakeParameters.put(parameterName, parameterValue);
	}

	/**
	 * 获取web请求的上下文对象。
	 * 
	 * @return requestContext
	 * @since xuyan @ 2012-3-9
	 */
	public RequestContext getRequestContext() {
		return requestContext;
	}
}