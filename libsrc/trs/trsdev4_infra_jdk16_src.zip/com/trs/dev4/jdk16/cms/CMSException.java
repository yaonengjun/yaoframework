/*
 * Created: TRS@Feb 16, 2011 1:55:07 PM
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.exception.BussinessException;

/**
 * 记录内容发布的异常 <br>
 * 
 */
public class CMSException extends BussinessException {

	/**
	 * @param msg
	 */
	public CMSException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param cause
	 */
	public CMSException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @since TRS @ Feb 16, 2011
	 */
	private static final long serialVersionUID = 1L;

}
