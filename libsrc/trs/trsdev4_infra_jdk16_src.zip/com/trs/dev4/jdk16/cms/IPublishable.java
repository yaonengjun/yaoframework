/*
 * Created: TRS@Feb 23, 2011 11:59:44 PM
 */
package com.trs.dev4.jdk16.cms;

/**
 * 标记对象可发布 <br>
 * 
 */
public interface IPublishable {
	/**
	 * 根据名称获取对象的属性
	 * 
	 * @param name
	 * @return
	 * @since TRS @ Feb 24, 2011
	 */
	String getProperty(String name);
}
