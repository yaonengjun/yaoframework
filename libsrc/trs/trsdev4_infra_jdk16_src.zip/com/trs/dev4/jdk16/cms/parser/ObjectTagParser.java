/**
 * Created:         2006-3-28 18:41:21
 * Last Modified:   2006-3-28/2006-3-28
 * Description:
 *      class BaseTagParser
 */
package com.trs.dev4.jdk16.cms.parser;

import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

public class ObjectTagParser implements ITagParser {
	
	protected static Logger logger = Logger.getLogger(ObjectTagParser.class);
	
	
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		Map<String,String> attributeMap = tagContext.getAttributes();
		StringBuilder errors = new StringBuilder();
		
		
		String obj = attributeMap.get("OBJ");
		if(StringHelper.isEmpty(obj)){
			return TagParserUtils.writeError("TRS_OBJECT标签需要指定obj属性");
		}
		
		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		ITagAware tagAware = contentGenerator.getAware(obj);
		if(null == tagAware){
			return TagParserUtils.writeError("所指定的数据源TagAware为" + obj + "，不存在；");
		}
		Object object  = tagContext.getEntity();
		
		
		if(object == null){
			object = buildPublishObject(tagContext, tagAware, errors);
		}
		
		if(object == null){
			return TagParserUtils.writeError(errors.toString());
		}
		PublishObject publishObject = null;
		
		if (object instanceof PublishObject) {
			publishObject = (PublishObject) object;
		} else {
			publishObject = new PublishObject(object);
		}
		return contentGenerator.parseObject(publishObject, tagItem, tagContext);
	}

	private Object buildPublishObject(TagContext tagContext, ITagAware tagAware, StringBuilder errors) {
		int id = 0;
		
		String value = tagContext.getAttribute("id", "");
		
		// 指定ID的情况
		if (!StringHelper.isEmpty(value)) {
			String intValue = TagParserUtils.parentValueDecorate(TagParserUtils.userNameValueDecorate(TagParserUtils
					.paramStringValueDecorate(value, tagContext), tagContext), tagContext);
			if (!StringHelper.isNumeric(intValue)) {
				errors.append("id属性值须是数值类型");
				return null;
			} else {
				id = NumberUtil.parseInt(intValue);
			}

			return tagAware.getPublishObject(id);
		} else {
			
			SearchFilter sf = SearchFilter.getDefault();
			
			String filterByField = tagContext.getAttribute("filterByField", "");
			if (!StringHelper.isEmpty(filterByField)) {
				buildFilterByField(sf, filterByField, tagContext, errors);
			}
			
			if (errors.length() != 0) {
				
				return null;
			}
			
			return tagAware.getPublishObject(sf, tagContext);
		}

	}

	/**
	 * @param sf
	 * @param errors
	 * @since yangyu @ 2012-4-4
	 */
	private void buildFilterByField(SearchFilter sf, String filterByField, TagContext tagContext, StringBuilder errors) {
		String[] conditions = StringHelper.split(filterByField, ";");
		for (String condition : conditions) {
			String[] temps = StringHelper.split(condition, " ");
			if (temps.length == 3) {
				Object buildValue = buildValue(temps[2], tagContext, errors);
				if (errors.length() > 0) {
					return;
				}
				
				if (temps[1].equalsIgnoreCase("eq")) {
					sf.addEqCondition(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("gt")) {
					sf.addGreaterThan(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("lt")) {
					sf.addLesserThan(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("ge")) {
					sf.addGreaterThanEquals(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("le")) {
					sf.addLesserThanEquals(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("like")) {
					sf.addLike(temps[0], buildValue);
				} else if (temps[1].equalsIgnoreCase("ne")) {
					sf.addNotEqCondition(temps[0], buildValue);
				} else {
					errors.append("filterByField属性值指定表达式所使用的操作符错误，不存在的操作符，当前为" + temps[1] + "；");
				}
			} else if (temps.length == 4 && temps[1].equalsIgnoreCase("between")) {
				sf.addBetweenCondition(temps[0], temps[2], temps[3]);
			} else {
				errors.append("filterByField属性值指定表达式不能被识别，当前为" + filterByField + "；");
			}
		}
	}

	private Object buildValue(String value, TagContext tagContext, StringBuilder errors) {
		
		if (value.startsWith("'") && value.endsWith("'")) {
			return TagParserUtils.parentValueDecorate(TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(TagParserUtils
					.userNameValueDecorate(StringHelper.substring(value, "'", "'"), tagContext), tagContext), tagContext), tagContext);
		} else {
			value = TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(value, tagContext), tagContext);
			if (StringHelper.isNumeric(value)) {
				return NumberUtil.parseInt(value);
			} else if (value.equalsIgnoreCase("true")) {
				return new Boolean(true);
			} else if (value.equalsIgnoreCase("false")) {
				return new Boolean(false);
			} else {
				errors.append("filterByField属性值指定表达式value值有错误，不能被识别，当前是" + value + ",如果是字符串类型需要添加引号；");
				return null;
			}
		}

	}

	@Override
	public TagBeanInfo getBeanInfo() {
		return  new TagBeanInfo("TRS_OBJECT", "generate datetime",
				BodyType.EMPTY);
	}
	
}