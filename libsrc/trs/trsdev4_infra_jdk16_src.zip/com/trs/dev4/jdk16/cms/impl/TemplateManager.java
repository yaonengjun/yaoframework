/*
 * Created: TRS@Feb 16, 2011 9:12:39 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.HashMap;
import java.util.Map;

import com.trs.dev4.jdk16.cms.ITemplateManager;
import com.trs.dev4.jdk16.cms.TemplateDocument;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseManager;

/**
 * 用于模板{@link ITemplate}管理
 * 
 */
public class TemplateManager extends BaseManager<Template> implements
		ITemplateManager {
	/**
	 * 
	 */
	private Map<String, TemplateDocument> templateDocuments = new HashMap<String, TemplateDocument>();
	/**
	 * 
	 */
	private Map<String, Template> templates = new HashMap<String, Template>();

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplate(java.lang.String)
	 * @since TRS @ Feb 16, 2011
	 */
	@Override
	public Template getTemplate(String templateName) {
		Template template = templates.get(templateName);
		if (template == null) {
			template = super.findFirst("name", templateName);
		}
		return template;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplateDocument(java.lang.String)
	 * @since TRS @ Feb 16, 2011
	 */
	@Override
	public TemplateDocument getTemplateDocument(String templateName) {
		TemplateDocument templateDoc = templateDocuments.get(templateName);
		if (templateDoc != null) {
			return templateDoc;
		}
		Template template = getTemplate(templateName);
		if (null != template){
			templateDoc = new TemplateDocument(template.getContent());
		}
		return templateDoc;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#parseTemplateDocument(java.lang.String)
	 * @since TRS @ Feb 16, 2011
	 */
	@Override
	public TemplateDocument parseTemplateDocument(String templateContent) {
		return new TemplateDocument(templateContent);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplateByObjectType(java.lang.String,
	 *      int)
	 */
	@Override
	public Template getTemplateByObjectType(String objectType, int objectId) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("objectType", objectType);
		sf.addEqCondition("objectId", objectId);
		return super.findFirst(sf);
	}

}
