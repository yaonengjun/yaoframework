/*
 * Created: fangxiang@Jan 21, 2011 10:20:45 AM
 */
package com.trs.dev4.jdk16.cms;

import java.util.Map;

/**
 * 将动态内容按照静态模板发布成静态文件.<br>
 * 
 */
public interface ICMSPublisher {
	/**
	 * 根据模板名，将制定的内容发布成静态内容，并保存到指定文件位置
	 * 
	 * @param templateName
	 *            模板名
	 * @param inputObjects
	 *            输入的参数
	 * @param outputFile
	 *            输出文件
	 * @since TRS @ Jan 21, 2011
	 */
	public void publish(String templateName, Map<String, Object> inputObjects,
			String outputFile);

	/**
	 * 根据模板名，将制定的内容生成静态内容。
	 * 
	 * @param templateName
	 *            模板名
	 * @param inputObjects
	 *            输入参数
	 * @return 生成的静态内容
	 * @since fangxiang @ Jan 21, 2011
	 */
	public String merge(String templateName, Map<String, Object> inputObjects);
}
