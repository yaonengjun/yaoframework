/*
 * Created: yangyu@2012-6-10 下午12:13:58
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 * 
 */
public class LinkGroupTagParser extends ObjectsTagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since yangyu @ 2012-6-10
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_LINKGROUP", "generate links", BodyType.EMPTY);
	}
	
	@Override
	public final String parse(TagItem tagItem, TagContext tagContext) {

		String obj = tagContext.getAttribute("OBJ");
		if (!StringHelper.isEmpty(obj)) {
			return super.parse(tagItem, tagContext);
		} else {
			return TagParserUtils.getInnerHtml(tagItem, tagContext);
		}

	}

	@Override
	protected String getLoopType(TagContext tagContext) {
		String loopType = tagContext.getAttribute("loopType", "loop");
		return loopType;
	}
}
