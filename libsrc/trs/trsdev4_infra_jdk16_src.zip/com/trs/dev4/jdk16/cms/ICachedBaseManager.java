package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * <b>职责:</b>缓存管理基类接口 <br>
 * 
 * @author TRS信息技术股份有限公司
 * @since May 2, 2012 4:34:33 PM
 */
public interface ICachedBaseManager<T> extends IBaseManager<T> {

	/**
	 * <b>职责:</b> 获取分页的缓存数据 <br>
	 * 
	 * @param searchFilter 查询条件，参见{@link SearchFilter}
	 * @param cached 是否从缓存中获取数据，true是，false不是
	 * @return 缓存的分页数据，参见{@link PagedList}
	 */
	public PagedList<T> pagedObjects(SearchFilter searchFilter, boolean cached);

	/**
	 * <b>职责:</b> 获取缓存中的总数<br>
	 * 
	 * @param searchFilter 查询条件，参见{@link SearchFilter}
	 * @param cached 是否从缓存中获取数据，true是，false不是
	 * @return 符合查询条件的总数
	 */
	public int total(SearchFilter searchFilter, boolean cached);

	/**
	 * 获取缓存中全部的数据
	 * 
	 * @param cached 是否从缓存中获取数据
	 * @return 全部数据的分页
	 */
	public PagedList<T> pagedAll(boolean cached);

	/**
	 * 根据查询条件查询唯一的数据
	 * 
	 * @param sf查询条件
	 * @param cached 是否使用缓存
	 * @return 唯一的数据
	 */
	public T findUnique(SearchFilter sf, boolean cached);

	/**
	 * 根据查询条件查询第一条数据
	 * 
	 * @param sf 查询条件
	 * @param cached 是否使用缓存
	 * @return
	 */
	public T findFirst(SearchFilter sf, boolean cached);

	/**
	 * <b>职责:</b> 构造缓存配置名称<br>
	 * 
	 * @return 缓存配置名称
	 */
	public String buildCachedConfig();

	/**
	 * <b>职责:</b> 初始化对象缓存的时间,单位：秒 <br>
	 * 
	 * @return 缓存时间
	 */
	public int getDefaultExpiration();

	/**
	 * <b>职责:</b>初始化id列表缓存的时间,单位：秒 <br>
	 * 
	 * @return 缓存时间
	 */
	public int getDefaultListExpiration();

	/**
	 * <b>职责:</b>初始化总数目缓存的时间,单位：秒 <br>
	 * 
	 * @return 缓存时间
	 */
	public int getDefaultTotalExpiration();

}
