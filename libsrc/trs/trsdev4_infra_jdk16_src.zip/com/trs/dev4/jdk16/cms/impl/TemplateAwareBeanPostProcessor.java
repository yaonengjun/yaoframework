/*
 * Created: liushen@Feb 1, 2012 5:06:50 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.IPageLinkManager;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.ITemplateAware;

/**
 * 在Spring环境下，完成 {@link ITemplateAware} 以及 {@link ITagParser} 的自注册。 <br>
 * 
 */
public class TemplateAwareBeanPostProcessor implements BeanPostProcessor {

	private static final Logger LOG = Logger.getLogger(TemplateAwareBeanPostProcessor.class);

	private IPageLinkManager pageLinkManager;
	private IContentGenerator contentGenerator;

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object, java.lang.String)
	 * @since liushen @ Feb 1, 2012
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		return bean;
	}

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object, java.lang.String)
	 * @since liushen @ Feb 1, 2012
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		if (bean instanceof ITemplateAware) {
			LOG.debug("found ITemplateAware bean [" + beanName + "] (" + bean.getClass() + ")");
			pageLinkManager.registerTemplateAware((ITemplateAware) bean);
		}
		if (contentGenerator != null) {
			if (bean instanceof ITagParser) {
				LOG.debug("found ITagParser bean [" + beanName + "] (" + bean.getClass() + ")");
				contentGenerator.registerParser((ITagParser) bean);
			}
		}
		return bean;
	}

	/**
	 * @param pageLinkManager
	 *            the {@link #pageLinkManager} to set
	 */
	public void setPageLinkManager(IPageLinkManager pageLinkManager) {
		this.pageLinkManager = pageLinkManager;
	}

	/**
	 * @param contentGenerator
	 *            the {@link #contentGenerator} to set
	 */
	public void setContentGenerator(IContentGenerator contentGenerator) {
		this.contentGenerator = contentGenerator;
	}

}
