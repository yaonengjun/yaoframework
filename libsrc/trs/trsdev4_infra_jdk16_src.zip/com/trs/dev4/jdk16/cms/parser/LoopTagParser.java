/*
 * Created: yangyu@Jun 8, 2012 11:16:26 AM
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;

/**
 * 职责: <br>
 * 
 */
public class LoopTagParser implements ITagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since yangyu @ Jun 8, 2012
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_LOOP", "LOOP", BodyType.EMPTY);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since yangyu @ Jun 8, 2012
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		
		tagItem.setAttributes(tagContext.getParent().getAttributes());
		
		return contentGenerator.parseLoop(tagItem, tagContext);
	}

}
