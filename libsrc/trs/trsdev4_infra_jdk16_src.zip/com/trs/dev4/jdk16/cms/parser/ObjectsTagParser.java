/**
 * Created:         2006-3-28 18:41:21
 * Last Modified:   2006-3-28/2006-3-28
 * Description:
 *      class BaseTagParser
 */
package com.trs.dev4.jdk16.cms.parser;

import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * List类型的置标基类
 * 
 * @author yangyu
 * @since 2011-5-21
 */
public class ObjectsTagParser implements ITagParser {
	
	/*
	 * (non-Javadoc)
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem, com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		String obj = tagContext.getAttribute("OBJ");

		if(StringHelper.isEmpty(obj )){
			return TagParserUtils.writeError("TRS_OBJECTS标签需要指定obj属性；");
		}
		
		int pageNo = buildPageNo(tagContext);
		int pageSize = buildPageSize(tagContext);
		int fromNum = this.buildFrom(tagContext);
		int toNum = this.buildTo(tagContext);
		
		SearchFilter sf = null;
		if (pageSize < 0) {
			
			if (toNum < 0) {
				sf = SearchFilter.getNoPagedFilter();
			} else {
				sf = SearchFilter.getSearchFilter(pageNo - 1, toNum);
			}
			
		} else {
			sf = SearchFilter.getSearchFilter(pageNo - 1, pageSize);	
		}
				
		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		ITagAware tagAware = contentGenerator.getAware(obj);
		
		if (null == tagAware) {
			return TagParserUtils.writeError("所指定的数据源TagAware为" + obj + "，不存在；");
		}
		
		
		String filterByField = tagContext.getAttribute("filterByField", "");
		String orderby = tagContext.getAttribute("orderBy", "");
		
		StringBuilder errors = new StringBuilder();
		
		if (!StringHelper.isEmpty(filterByField)) {
			buildFilterByField(sf, filterByField, tagContext, tagAware, errors);
		}

		if (!StringHelper.isEmpty(orderby)) {
			buildOrderBy(sf, orderby, tagContext);
		}
		
		if (errors.length() != 0) {
			return TagParserUtils.writeError(errors.toString());
		}
		
		PagedList pageList = tagAware.pagedPublishObjects(tagItem, tagContext, sf);
		
		if (fromNum > 0 && fromNum <= pageList.getTotalItemCount()) {
			List elements = pageList.getPageItems();

			pageList = new PagedList(elements.subList(fromNum - 1, (toNum > 0 && toNum < elements.size()) ? toNum : elements.size()));
			
		} else if (fromNum > pageList.getTotalItemCount()) {
			pageList = new PagedList(new ArrayList());
		}
		
		String loopType = getLoopType(tagContext);

		return contentGenerator.parseObjects(loopType, pageList, tagItem, tagContext, tagAware);
	}

	protected String getLoopType(TagContext tagContext) {
		String loopType = tagContext.getAttribute("loopType", "noLoop");
		return loopType;
	}

	/**
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Apr 19, 2012
	 */
	private int buildPageSize(TagContext tagContext) {
		String ps = tagContext.getAttribute("pageSize", "");
		int pageSize = buildIntValue(tagContext, ps);
		if (pageSize < 0) {
			pageSize = NumberUtil.parseInt(ps, -1);
		}
		return pageSize;
	}
	
	private int buildFrom(TagContext tagContext) {
		String from = tagContext.getAttribute("from", "");
		return NumberUtil.parseInt(from, -1);
	}

	private int buildTo(TagContext tagContext) {
		String to = tagContext.getAttribute("to", "");
		return NumberUtil.parseInt(to, -1);
	}

	/**
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Apr 19, 2012
	 */
	private int buildPageNo(TagContext tagContext) {
		String pn = tagContext.getAttribute("pageNo", "");
		int pageNo = buildIntValue(tagContext, pn);
		if (pageNo < 0) {
			pageNo = NumberUtil.parseInt(pn, 1);
		}
		return pageNo;
	}

	/**
	 * @param sf
	 * @param tagContext
	 * @since yangyu @ 2012-4-4
	 */
	private void buildOrderBy(SearchFilter sf, String orderBy, TagContext tagContext) {

		String order = TagParserUtils.paramStringValueDecorate(orderBy, tagContext);
		if (!StringHelper.isEmpty(order)) {
			
			// TODO: orderBy的格式判断以及替换格式问题
			sf.setOrderBy(order.replace("_", " "));
		}
	}

	private int buildIntValue(TagContext tagContext, String value) {
		int defaultVal = -1;
		if (!StringHelper.isEmpty(value)) {

			if (value.startsWith("param.")) {
				value = TagParserUtils.paramStringValueDecorate(value, tagContext);
			}
			if (StringHelper.isNumeric(value)) {
				defaultVal = NumberUtil.parseInt(value, 1);
			}

		}
		return defaultVal;
	}

	/**
	 * @param sf
	 * @param tagAware
	 * @param errors
	 * @since yangyu @ 2012-4-4
	 */
	private void buildFilterByField(SearchFilter sf, String filterByField, TagContext tagContext, ITagAware tagAware, StringBuilder errors) {

		String[] conditions = StringHelper.split(filterByField, ";");
		for (String condition : conditions) {
			String[] temps = StringHelper.split(condition, " ");
			
			if (temps.length == 3) {
				Object buildValue = buildValue(temps[0], temps[2], tagContext, tagAware, errors);
				if (buildValue == null) {
					return;
				}
				if (temps[1].equalsIgnoreCase("eq")) {
					if (buildValue != null) {
						sf.addEqCondition(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("gt")) {
					if (buildValue != null) {
						sf.addGreaterThan(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("lt")) {
					if (buildValue != null) {
						sf.addLesserThan(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("ge")) {
					if (buildValue != null) {
						sf.addGreaterThanEquals(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("le")) {
					if (buildValue != null) {
						sf.addLesserThanEquals(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("like")) {
					if (buildValue != null) {
						sf.addLike(temps[0], buildValue);
					}
				} else if (temps[1].equalsIgnoreCase("ne")) {
					if (buildValue != null) {
						sf.addNotEqCondition(temps[0], buildValue);
					}
				} else {
					errors.append("filterByField属性值指定表达式所使用的操作符错误，不存在的操作符，当前为" + temps[1] + "；");
				}
			} else if (temps.length == 4 && temps[1].equalsIgnoreCase("between")) {
				sf.addBetweenCondition(temps[0], temps[2], temps[3]);			
			} else {
				errors.append("filterByField属性值指定表达式不能被识别，当前为" + filterByField + "；");
			}
		}
	}
	
	private Object buildValue(String key, String value, TagContext tagContext, ITagAware tagAware, StringBuilder errors) {
		
		if (value.startsWith("'") && value.endsWith("'")) {
			return TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(TagParserUtils.userNameValueDecorate(StringHelper.substring(
					value, "'", "'"),
					tagContext),
					tagContext),
					tagContext);
		} else if (value.startsWith("enumValue.")) {
			
			return TagParserUtils.enumValueDecorate(key, value, tagContext, tagAware);
		} else {
			value = TagParserUtils.paramStringValueDecorate(TagParserUtils.parentValueDecorate(value, tagContext), tagContext);
			
			if (value == null) {
				errors.append("filterByField属性值指定表达式value值有错误，不能被识别，解析出的结果为null；");
				return null;
			}
			
			if (StringHelper.isNumeric(value)) {
				return NumberUtil.parseInt(value);
			} else if (value.equalsIgnoreCase("true")) {
				return new Boolean(true);
			} else if (value.equalsIgnoreCase("false")) {
				return new Boolean(false);
			} else {
				errors.append("filterByField属性值指定表达式value值有错误，不能被识别，当前是" + value + ",如果是字符串类型需要添加引号；");
				return null;
			}
		}

	}
	
	@Override
	public TagBeanInfo getBeanInfo() {
		return  new TagBeanInfo("TRS_OBJECTS", "generate datetime",
				BodyType.EMPTY);
	}
	
}