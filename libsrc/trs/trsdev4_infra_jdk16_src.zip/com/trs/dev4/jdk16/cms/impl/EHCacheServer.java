package com.trs.dev4.jdk16.cms.impl;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cacheserver.impl.LocalCacheServer;

/**
 * TODO 职责说明
 * 
 * @author yangyu
 * @since Apr 25, 2012 10:12:05 AM
 */
public class EHCacheServer implements ICacheServer {

	/**
	 * 
	 */
	protected static Logger logger = Logger.getLogger(LocalCacheServer.class);
	/**
	 * 
	 */
	private Cache ehCacheServer = null;
	/**
	 * 最长过期时间
	 */
	int maxExpire = 20 * 60;

	/**
	 * 当前应用的缓存前缀
	 */
	String appKey = "trs:";

	public void start() {
		CacheManager singletonManager = CacheManager.create();
		Cache memoryOnlyCache = new Cache("testCache", 5000, false, false, 5, 2);
		singletonManager.addCache(memoryOnlyCache);
		ehCacheServer = singletonManager.getCache("testCache");
	}

	/**
	 * 设置最长过期时间
	 * 
	 * @param maxExpire
	 * @since liuyou @ 2010-5-23
	 */
	public void setMaxExpire(int maxExpire) {
		this.maxExpire = maxExpire;
	}

	/**
	 * 过期时间的处理，超长或者为负时设置为最长过期时间
	 * 
	 * @param expire
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	public int getExpire(int expire) {
		return (expire <= 0 || expire > maxExpire) ? maxExpire : expire;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String, int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void add(String key, int expr, Object value) {
		Element element = new Element(key, value);
		element.setTimeToLive(expr);
		ehCacheServer.put(element);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#delete(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void delete(String key) {
		ehCacheServer.remove(key);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public Object get(String key) {
		Element element = ehCacheServer.get(key);
		if (element == null) {
			return null;
		}
		return element.getObjectValue();
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String, int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		this.set(key, expr, value);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String, int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void set(String key, int expr, Object value) {
		this.add(key, expr, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String, java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void set(String key, Object value) {
		this.set(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String, java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void add(String key, Object value) {
		this.add(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String, java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void replace(String key, Object value) {
		this.replace(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String, java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public Object get(String key, Object defaultVal) {
		Object value = this.get(key);
		return value == null ? defaultVal : value;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#clearAll()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void clearAll() {
		ehCacheServer.removeAll();
	}

}
