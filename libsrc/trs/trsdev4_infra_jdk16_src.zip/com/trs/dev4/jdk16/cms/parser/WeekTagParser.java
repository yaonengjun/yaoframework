/*
 * Created: TRS@Mar 3, 2011 10:39:38 PM
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;

/**
 * 解析TRS_WEEK标签，供测试用
 * 
 */
public class WeekTagParser implements ITagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_WEEK", "Display Week information",
				BodyType.EMPTY);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem, com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		return tagContext.getEntity().getProperty("title").toString();
	}
}
