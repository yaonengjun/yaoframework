/*
 * Created: yangyu@Jun 4, 2012 2:56:13 PM
 */
package com.trs.dev4.jdk16.cms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.PageContext;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.servlet24.ResponseUtil;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: .<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class AjaxTemplateAction implements Controller {

	private IContentGenerator contentGenerator;
	
	/**
	 * @see org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * @since yangyu @ Jun 4, 2012
	 */
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String templateName = RequestUtil.getParameter(request, "templateName", "");
		
		if (StringHelper.isEmpty(templateName)) {
			ResponseUtil.json(response, "no template");
		}
		
		RequestContext requestContext = RequestContext.getWebRequestContext(request);
		
		Map<String, Object> model = new HashMap<String, Object>(); 
		
		PageContext pageContext = new PageContext(contentGenerator, requestContext, model);
		
		ResponseUtil.json(response, contentGenerator.generate(templateName, pageContext));
		
		return null;
	}

	public IContentGenerator getContentGenerator() {
		return contentGenerator;
	}

	public void setContentGenerator(IContentGenerator contentGenerator) {
		this.contentGenerator = contentGenerator;
	}

}
