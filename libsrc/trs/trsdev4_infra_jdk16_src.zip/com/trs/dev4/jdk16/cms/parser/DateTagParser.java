/*
 * Created: TRS@Mar 3, 2011 10:39:38 PM
 */
package com.trs.dev4.jdk16.cms.parser;

import java.util.Date;
import java.util.Map;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 解析TRS_DATETIME标签，供测试用
 * 
 */
public class DateTagParser implements ITagParser {


	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_DATETIME", "generate datetime",
				BodyType.EMPTY);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		// 标签里的参数Map
		Map<String, String> attributeMap = tagContext.getAttributes();
		String pattern = attributeMap.get("PATTERN");
		Long LdateTime = new Date().getTime();
		if (StringHelper.isNotEmpty(pattern)) {
			return DateUtil.date2String(new Date(LdateTime), pattern);
		}
		return (new Date()).toString();
	}
}
