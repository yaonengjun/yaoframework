package com.trs.dev4.jdk16.cms;

import java.util.List;

import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 负责给置标解析提供数据
 */
public interface ITagAware {

	
	PagedList pagedPublishObjects(TagItem tagItem, TagContext tagContext, SearchFilter searchFilter);

	/**
	 * 根据Object类型的标签定义的内容，从系统中获取相应的数据源
	 * 
	 * @param id
	 *            标签指定的ID
	 */
	Object getPublishObject(int id);
	
	Object getPublishObject(SearchFilter obj, TagContext tagContext);

	List<ForeignRelationship> listForeignRelationships();
	
	Class<?> getTagClass();

	/**
	 * @param propertyAsStr
	 * @param tagContext
	 * @return
	 * @since yangyu @ Jun 6, 2012
	 */
	Object getPublishObject(String propertyAsStr, TagContext tagContext);

	/**
	 * @param publishable
	 * @param key
	 * @param tagContext
	 * @return
	 * @since yangyu @ 2012-6-17
	 */
	Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext);
}
