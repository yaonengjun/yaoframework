/**
 * Created:         2005-4-19 15:53:32
 * Last Modified:   2006.01.19
 * Description:
 *      class TagItem
 * Update Log:
 * 	2006.08.14	WenYehui
 * 		添加获取/设置父TagItem的方法
 * 	2006.08.08 	WenYehui
 * 		添加findItems方法
 * 	2006.01.19	FuChengrui
 * 		在setAttribute的同时完成对置标属性是否为变量的解析，并缓存相应的模板变量。
 *	2005.12.27	FuChengrui
 *		增加了两个静态方法isVariableParameter()splitVariableParameter()，
 *		分别用以判断指定的字符串是否模板变量和分割模板变量为变量名和缺省值。
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import com.trs.dev4.jdk16.cms.CMSException;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 用于描述模板{@link ITemplate}中的标签
 */
public class TagItem {

	/**
	 * 判断指定的值是不是模板变量
	 */
    public final static boolean isVariableParameter(String _sValue) {
        if (_sValue == null || _sValue.length() <= 3) {
            return false;
        }
        if (_sValue.charAt(0) != '$' || _sValue.charAt(1) != '{'
                || _sValue.charAt(_sValue.length() - 1) != '}') {
            return false;
        }
        return true;
    }

    // tag name like "TRS_OUTLINE", "TRSPICNEWS", "TRS_COLUMN", etc.
    private String m_sName;

	private HashMap<String, String> m_hAttributes = null; // the tag item
															// properties

	private Hashtable<String, String> m_hExtraAttributes = null; // the tag item
																	// properties

	private HashMap<String, TemplateParameter> m_hVariableParameters = null; // the
																				// tag
																	// item
																	// properties

	private List<TagItem> m_children = null; // the tag item children

    private int m_iBeginLineNo;

    private int m_iBeginColumn;

    private int m_iCloseLineNo;

    private int m_iCloseColumn;

	/*
	 * 父节点
	 */
	private TagItem m_parentItem; // wenyh@2006-8-14 15:38:41 add comment:添加

	/**
	 * 当前置标是否变量声明置标 2006.02.26 其实专门用于声明变量的置标的解析，放在TagItem类中并不是很合适，
	 * 但是短时间内不会对TagDocumentReader进行大的改动，所以不得已。 在设置置标名称的时候决定该成员变量的真假，在后续的设置置标属性
	 * 的时候，根据该成员变量的值采用完全不同的方法。
	 */
    private boolean m_zIsVariableDeclare;

	/**
	 * 当前置标声明的变量
	 */
	private TemplateParameter m_oVariableParameter;
	/**
	 * 
	 */
	private String content;

	/**
	 * constructor: default
	 */
	public TagItem() {
    }

	/**
	 * 
	 * @param _tagText
	 */
	public TagItem(String _tagText) {
		content = _tagText;
	}

    /**
     * @see IClearable#clear()
     */
    public void clear() {
        if (m_hAttributes != null && !m_hAttributes.isEmpty()) {
            m_hAttributes.clear();
        }
        if (m_hExtraAttributes != null && !m_hExtraAttributes.isEmpty()) {
            m_hExtraAttributes.clear();
        }
    }

    /**
     * @return Returns the tag name.
     */
    public String getName() {
        return m_sName;
    }

    /**
     * @param name
     *            the tag name.
     */
    public void setName(String name) {
        if (name != null) {
            name = name.toUpperCase();
        }
        if (m_sName == null) {
			// 如果原来没有设置置标名称，则认为是在解析模板时的首次设置，
			// 所以需要进行是不是变量声明的判断。
			m_sName = name;
			// m_zIsVariableDeclare = isVariableDeclare(name);
			// if (m_zIsVariableDeclare) {
			// m_oVariableParameter = new TemplateParameter();
			// m_hVariableParameters = new HashMap();
			// m_hVariableParameters.put(null, m_oVariableParameter);
			// }
        } else {
			// 如果原来已经有了置标名称，则认为是在模板标准化时进行的修改，
			// 因为各个属性值的设置和顺序是相关的，在标准化时顺序已经丢失，
			// 所在一在标准化时一律忽略是不是变量声明的判断。
			m_sName = name;
            m_zIsVariableDeclare = false;
        }
    }

    /**
     * @return Returns all the attributes.
     */
	public HashMap<String, String> getAttributes() {
        return m_hAttributes;
    }

    /**
     * get a attribute value
     * 
     * @param _sName
     *            the attribute name
     * @return Returns the attribute value if found; <BR>
     *         otherwise, returns <code>null</null>.
     */
    public String getAttribute(String _sName) {
        if (m_hAttributes == null || _sName == null) {
            return null;
        }

        // else
        return m_hAttributes.get(_sName.toUpperCase());
    }

    /**
     * get the timmed value of a attribute
     * 
     * @param _sName
     *            the attribute name.
     * @return Returns the trimmed value of the attribute if found; <BR>
     *         otherwise, returns <code>null</code>.
     */
    public String getAttributeTrim(String _sName) {
        String sValue = this.getAttribute(_sName);
        return sValue == null ? null : sValue.trim();
    }

    /**
     * get a required attribute value
     * 
     * @param _sName
     *            the attribute name
     * @return Returns the attribute value.
     *             if the attribute is not found.
     */
	public String getRequiredAttribute(String _sName) {
        String sValue = this.getAttribute(_sName);
        if (sValue == null || sValue.length() == 0) {
			throw new CMSException("Attribute [" + _sName + "] required!");
        }

        // else
        return sValue;
    }

    /**
     * get the trimmed value of a required attribute.
     * 
     * @param _sName
     *            the attribute name.
     * @return Returns the trimmed value of the attribute if found.
     */
	public String getRequiredAttributeTrim(String _sName) {
        String sValue = this.getAttributeTrim(_sName);
        if (sValue == null || sValue.length() == 0) {
			throw new CMSException("Property [" + _sName + "] required!");
        }

        // else
        return sValue;
    }

    /**
	 * get the integer attribute value
	 * 
	 * @param _sName
	 *            the attribute name.
	 * @param _nDefault
	 *            default value if the attribute value is not set.
	 * @return Returns the integer value of the attribute.
	 * @throws CMSException
	 *             if the attribute value is not integer.
	 */
	public int getIntAttribute(String _sName, int _nDefault) {
        String sValue = this.getAttributeTrim(_sName);
        if (sValue == null || sValue.length() == 0)
            return _nDefault;
        // else
        try {
            return Integer.parseInt(sValue);
        } catch (Exception ex) {
			throw new CMSException("Value ["
                    + sValue + "] of attribute [" + _nDefault
                    + "] is not integer!", ex);
        }
    }

	/**
	 * get the String attribute value
	 * 
	 * @param _sName
	 *            the attribute name.
	 * @param _nDefault
	 *            default value if the attribute value is not set.
	 * @return Returns the String value of the attribute.
	 * @since yangyu @ 2012-4-3
	 */
	public String getStringAttribute(String _sName, String _nDefault) {
		String sValue = this.getAttributeTrim(_sName);
		if (sValue == null || sValue.length() == 0) {
			return _nDefault;
		}
		return sValue;
	}

    /**
     * get the boolean attribute value
     * 
     * @param _sName
     *            the attribute name
     * @param _bDefault
     *            the default value if the attribute is not found.
     * @return Returns the boolean value of the attribute if found; <BR>
     *         otherwise, returns the default value.
     */
    public boolean getBooleanAttribute(String _sName, boolean _bDefault) {
        String sValue = this.getAttribute(_sName);
        if (sValue == null || (sValue = sValue.trim()).length() == 0)
            return _bDefault;
        // else
        return sValue.equalsIgnoreCase("true");
    }

    /**
     * @param _attributes
     *            the attributes collection.
     */
	public void setAttributes(HashMap<String, String> _attributes) {
        m_hAttributes = _attributes;
    }

    /**
	 * Sets the value of a attribute
	 * 
	 * @param _sName
	 *            the attribute name
	 * @param _sValue
	 *            the attribute value.
	 * @throws CMSException
	 *             if the attribute name is not specified.
	 */
	public void setAttribute(String _sName, String _sValue) {
        if (_sName == null || (_sName = _sName.trim()).length() == 0) {
			throw new CMSException("Property name required!");
        }

		// else 属性名称有效
        _sName = _sName.toUpperCase();

		// else 不是模板变量声明置标
        if (_sValue == null) {
            if (m_zIsVariableDeclare) {
                parseVariableDeclare(_sName, _sValue);
            } else if (m_hVariableParameters != null) {
                m_hVariableParameters.remove(_sName);
            }
            if (m_hAttributes != null) {
                m_hAttributes.remove(_sName);
            }
        } else {
            if (m_zIsVariableDeclare) {
                parseVariableDeclare(_sName, _sValue);
            } else if (isVariableParameter(_sValue)) {
                setVariableParameter(_sName, _sValue);
            }
            if (m_hAttributes == null) {
				m_hAttributes = new HashMap<String, String>();
            }
            m_hAttributes.put(_sName.toUpperCase(), _sValue);
        }
    }

    /**
     * Sets the value of a attribute
     * 
     * @param _sName
     *            the attribute name
     * @param _nValue
     *            the attribute value.
     */
	public void setAttribute(String _sName, int _nValue) {
        setAttribute(_sName, String.valueOf(_nValue));
    }

    /**
	 * Sets the value of a boolean property.
	 * 
	 * @param _sName
	 *            the property name.
	 * @param _bValue
	 *            the property value.
	 * @throws CMSException
	 *             if failed to write attribute value.
	 */
	public void setAttribute(String _sName, boolean _bValue) {
        this.setAttribute(_sName, _bValue ? "true" : "false");
    }

    /**
     * Removes a specified attribute and returns the old value if the attribute
     * is removed.
     * 
     * @param _sName
     *            the attribute name
     * @return the old value if the attribute is found and removed.
     */
    public String removeAttribute(String _sName) {
        if (_sName == null) {
            return null;
        }
        _sName = _sName.toUpperCase();
        if (m_hVariableParameters != null) {
            m_hVariableParameters.remove(_sName);
        }
        if (m_hAttributes != null) {
            return m_hAttributes.remove(_sName);
        }
        return null;
    }

	/**
	 * 获取当前标签的所有子标签
	 * 
	 * @return Returns the children list.
	 */
	public List<TagItem> getChildren() {
        return m_children;
    }

    /**
     * Returns <code>true</code> if this tag item has children;
     * <code>false</code>, otherwise.
     * 
     * @return <code>true</code> if this tag item has children;
     *         <code>false</code>, otherwise.
     */
    public boolean hasChildren() {
        return m_children != null && m_children.size() > 0;
    }

    /**
     * Returns <code>true</code> if this tag contains a child with the specified
     * name; <code>false</code>, otherwise.
     * 
     * @param _sName
     *            the child tag name
     * @return <code>true</code> if this tag contains a child with the specified
     *         name; <code>false</code>, otherwise.
     */
    public boolean containsChild(String _sName) {
        if (m_children == null) {
            return false;
        }

        // else
        Object child;
        for (int i = 0, nSize = m_children.size(); i < nSize; i++) {
            child = m_children.get(i);
            if (child != null && (child instanceof TagItem)
                    && ((TagItem) child).getName().equalsIgnoreCase(_sName)) {
                return true;
            }
        }

        // else, not found
        return false;
    }

    /**
     * Returns the first child if it is a string.
     * 
     * @return the first child if it is a string; otherwise, return
     *         <code>null</code>
     */
    public String getText() {
        if (m_children != null && !m_children.isEmpty()) {
            TagItem firstChild = m_children.get(0);
            if (firstChild != null && (firstChild.getContent() instanceof String))
                return firstChild.getContent();
        }

        // else
        return null;
    }

    /**
     * Returns the first child if it is a string.
     * 
     * @return the first child if it is a string; otherwise, return
     *         <code>null</code>
     */
    public String setText(String sNewValue) {
        String sOldValue = getText();

        if (sNewValue == null) {
            return sOldValue;
        }

        if (m_children == null) {
			m_children = new ArrayList<TagItem>();
        }
        if (m_children.isEmpty()) {
			m_children.add(new TagItem(sNewValue));
        } else {
            Object firstChild = m_children.get(0);
            if (firstChild != null && (firstChild instanceof String)) {
				m_children.set(0, new TagItem(sNewValue));
            } else {
				m_children.add(0, new TagItem(sNewValue));
            }
        }

        return sOldValue;
    }

    /**
     * @param _children
     *            the children list.
     */
	public void setChildren(List<TagItem> _children) {
        m_children = _children;
    }

    /**
     * add a TagItem child
     * 
     * @param _child
     *            the child
     */
    public void addChild(TagItem _child) {
        if (_child == null)
            return;

        // else
        if (m_children == null) {
			m_children = new ArrayList<TagItem>();
        }
        m_children.add(_child);
		// if (m_oVariableParameter != null
		// && PublishConstants.TAGNAME_VARIABLE_ENUM.equals(_child
		// .getName())) {
		// m_oVariableParameter.addEnumValue(_child.getAttribute("VALUE"),
		// _child.getAttribute("DISPLAY"));
		// }
    }

    /**
     * add a string child
     * 
     * @param _child
     *            the child
     */
    public void addChild(String _child) {
        if (_child == null)
            return;

        // else
        if (m_children == null) {
			m_children = new ArrayList<TagItem>();
        }
		m_children.add(new TagItem(_child));
    }

    /**
     * @see Object#toString()
     */
    @Override
	public String toString() {
		//
		if (StringHelper.isEmpty(this.getName())) {
			return this.content;
		}
        StringBuffer buff = new StringBuffer();
        // 1. to output name
        buff.append("<").append(this.getName());

        // 2. to output attributes
        if (m_hAttributes != null) {
			Iterator<?> keyItr = m_hAttributes.keySet().iterator();
			while (keyItr.hasNext()) {
				String key = (String) keyItr.next();
				buff.append(' ').append(key).append("=\"");
				buff.append(StringHelper.replaceAll(m_hAttributes.get(key),
                        "\"", "\\\""));
                buff.append("\"");
            }
        }

        // 3. to output start tag end
        buff.append(">");

        // 4. to output children
        if (m_children != null) {
            Object aChild;
            for (int i = 0; i < m_children.size(); i++) {
                aChild = m_children.get(i);
                if (aChild instanceof TagItem) {
                    buff.append(((TagItem) aChild).toString());
                } else {
                    buff.append(aChild.toString());
                }
            }// endfor
        }

        // 5. to output end tag
        buff.append("</").append(this.getName()).append(">");

        return buff.toString();
    }

	/**
	 * 返回置标的开始位置在模板正文中的列号
	 * 
	 * @return 置标的开始位置在模板正文中的列号
	 */
    public int getBeginColumn() {
        return m_iBeginColumn;
    }

	/**
	 * 设置置标的开始位置在模板正文中的列号
	 * 
	 * @param 置标的开始位置在模板正文中的列号
	 */
    public void setBeginColumn(int beginColumn) {
        m_iBeginColumn = beginColumn;
    }

	/**
	 * 返回置标的开始位置在模板正文中的行号
	 * 
	 * @return 置标的开始位置在模板正文中的行号
	 */
    public int getBeginLineNo() {
        return m_iBeginLineNo;
    }

	/**
	 * 设置置标的开始位置在模板正文中的行号
	 * 
	 * @param 置标的开始位置在模板正文中的行号
	 */
    public void setBeginLineNo(int beginLineNo) {
        m_iBeginLineNo = beginLineNo;
    }

	/**
	 * 返回置标的结束位置在模板正文中的列号
	 * 
	 * @return 置标的结束位置在模板正文中的列号
	 */
    public int getCloseColumn() {
        return m_iCloseColumn;
    }

	/**
	 * 设置置标的结束位置在模板正文中的列号
	 * 
	 * @param 置标的结束位置在模板正文中的列号
	 */
    public void setCloseColumn(int closeColumn) {
        m_iCloseColumn = closeColumn;
    }

	/**
	 * 返回置标的结束位置在模板正文中的行号
	 * 
	 * @return 置标的结束位置在模板正文中的行号
	 */
    public int getCloseLineNo() {
        return m_iCloseLineNo;
    }

	/**
	 * 设置置标的结束位置在模板正文中的行号
	 * 
	 * @param 置标的结束位置在模板正文中的行号
	 */
    public void setCloseLineNo(int closeLineNo) {
        m_iCloseLineNo = closeLineNo;
    }

	/**
	 * 返回置标的名称并附加上置标的开始位置在模板正文中的行和列信息的字符串描述
	 * 
	 * @return 置标的名称并附加上置标的开始位置在模板正文中的行和列信息的字符串描述
	 */
    public String getDescWithPos() {
        StringBuffer sb = new StringBuffer();

        sb.append("<");
        sb.append(getName());
		sb.append("[行:").append(m_iBeginLineNo).append(',');
		sb.append("列:").append(m_iBeginColumn).append(']');
        sb.append(">");
        return sb.toString();
    }

	/**
	 * 设置置标的扩展属性(非置标原有属性，为逻辑属性)
	 * 
	 * @param _sAttrName
	 * @param _sValue
	 */
    public void setExtraAttribute(String _sAttrName, String _sValue) {
        if (m_hExtraAttributes == null) {
			Hashtable<String, String> hTemp = new Hashtable<String, String>(1);
            hTemp.put(_sAttrName.toUpperCase(), _sValue);
            m_hExtraAttributes = hTemp;
        } else {
            m_hExtraAttributes.put(_sAttrName.toUpperCase(), _sValue);
        }
    }

    /**
     * @param _sAttrName
     * @return
     */
    public String getExtraAttributeValue(String _sAttrName) {
        if (m_hExtraAttributes == null)
            return null;

        Object value = m_hExtraAttributes.get(_sAttrName.toUpperCase());
        if (value == null) {
            return null;
        }

        return value.toString();
    }

	/**
	 * 以<code>java.util.HashMap</code>的形式返回所有的可变模板参数
	 * 
	 * @return 所有的可变模板参数
	 */
	public HashMap<String, TemplateParameter> getVariableParameters() {
        return m_hVariableParameters;
    }

	/**
	 * 返回指定名称的可变模板参数对象
	 * 
	 * @return 可变模板参数对象或者<code>null</code>
	 */
    public TemplateParameter getVariableParameter(String _sName) {
        if (_sName == null || m_hVariableParameters == null) {
            return null;
        }
        return m_hVariableParameters.get(_sName
                .toUpperCase());
    }

	/**
	 * 设置可变的模板参数 因为是私有方法，只可能内部调用，所以对于参数的合法性检查，放到调用该方法的方法中进行， 而且参数
	 * <code>_sName</code>再传入之前已经转换为大写。
	 * 
	 * @param _sName
	 *            可变模板参数的名称
	 * @param _sValue
	 *            可变模板参数的值，其实是包括类型和缺省值的字符串
	 */
    private void setVariableParameter(String _sName, String _sValue) {
		/*
		 * 关于模板变量的格式，采用冒号分割各个域，如下
		 * “变量名称:变量类型:变量缺省值:可用的变量取值的枚举1:可用的变量取值的枚举2[:...]”
		 * 
		 * 可以存在如下的几种简写格式: 1，没有可用取值的枚举，其中最后的方括号内的冒号是可有可无的 “变量名称:变量类型:变量缺省值[:]”
		 * 
		 * 2，没有变量缺省值，其中最后一个冒号是必须的 “变量名称:变量类型:”
		 * 
		 * 3，没有明示的变量类型，但是有缺省值，甚至变量取值枚举，其中第二个冒号是必须的， 变量类型为缺省类型，即字符串类型
		 * “变量名称::变量缺省值:可用的变量取值的枚举1:可用的变量取值的枚举2[:...]”
		 * 
		 * 4，没有明示的变量类型，也没有缺省值，但是有变量取值枚举，其中第二、三个冒号是必须的， 变量类型为缺省类型，即字符串类型
		 * “变量名称:::可用的变量取值的枚举1:可用的变量取值的枚举2[:...]”
		 * 
		 * 5，只有变量名称 “变量名称”
		 * 
		 * 6，只有变量名称和缺省值 “变量名称:变量缺省值”
		 * 
		 * 如果给出了可用的变量取值枚举，则变量在实际设置时只能从可用的取值中选择，
		 * 而不能输入新的取值，为了可以输入新的取值，规定如果在枚举的最后一个可用
		 * 取值的后面附加一个冒号，则意味着除了从枚举的值中选择，还可以输入新值。
		 */

        if (m_hVariableParameters == null) {
			m_hVariableParameters = new HashMap<String, TemplateParameter>();
        }
        TemplateParameter aParameter = new TemplateParameter();
        m_hVariableParameters.put(_sName, aParameter);
        String sValue = _sValue.substring(2, _sValue.length() - 1);

        int iNameSplit = sValue.indexOf('~');
        if (iNameSplit <= 0) {
            aParameter.setParameterName(sValue);
            return;
        }
        aParameter.setParameterName(sValue.substring(0, iNameSplit++));

        int iTypeSplit = sValue.indexOf('~', iNameSplit);
        if (iTypeSplit <= 0) {
            aParameter.setParameterType(TemplateParameter.Type.STRING);
            aParameter.setParameterDefault(sValue.substring(iNameSplit));
            return;
        }
        aParameter.setParameterType(sValue.substring(iNameSplit, iTypeSplit++));

        int iDefaultSplit = sValue.indexOf('~', iTypeSplit);
        if (iDefaultSplit <= 0) {
            aParameter.setParameterDefault(sValue.substring(iTypeSplit));
            return;
        }
        aParameter.setParameterDefault(sValue.substring(iTypeSplit,
                iDefaultSplit++));

        int iSplitThis = 0;
        int iSplitLast = iDefaultSplit;
        while (true) {
            iSplitThis = sValue.indexOf('~', iSplitLast);
            if (iSplitThis > 0) {
                aParameter.addEnumValue(sValue
                        .substring(iSplitLast, iSplitThis));
                iSplitLast = iSplitThis + 1;
            } else {
                break;
            }
        }
        if (iSplitLast < sValue.length()) {
            aParameter.addEnumValue(sValue.substring(iSplitLast));
        } else {
            aParameter.setCanCustom(true);
        }
    }

    private void parseVariableDeclare(String _sName, String _sValue) {
        if (m_oVariableParameter == null) {
            throw new IllegalStateException("'m_oVariableParameter' is null");
        }
        if ("NAME".equals(_sName)) {
            if (_sValue == null) {
                throw new IllegalArgumentException("'Variable name' is null");
            }
            m_oVariableParameter.setParameterName(_sValue);
            return;
        }
        if ("TYPE".equals(_sName)) {
            m_oVariableParameter.setParameterType(_sValue);
            return;
        }
        if ("DEFAULT".equals(_sName)) {
            m_oVariableParameter.setParameterDefault(_sValue);
            return;
        }
        if ("SPLIT".equals(_sName)) {
            if (_sValue != null && (_sValue = _sValue.trim()).length() == 1) {
                m_oVariableParameter.setEnumSplit(_sValue.charAt(0));
            }
            return;
        }
        if ("ENUMERATE".equals(_sName)) {
            m_oVariableParameter.addEnumValue(_sValue);
            return;
        }
        if ("CANCUSTOM".equals(_sName)) {
            m_oVariableParameter.setCanCustom("true".equalsIgnoreCase(_sValue));
            return;
        }
    }

	/**
	 * 设置父tagitem
	 * 
	 * @param _parentItem
	 */
    public void setParent(TagItem _parentItem) {
        m_parentItem = _parentItem;
    }

	/**
	 * 获取父tagitem
	 * 
	 * @return
	 */
    public TagItem getParent() {
        return m_parentItem;
    }

	/**
	 * 获取祖先tagitems列表 从父元素开始回溯,直到第一个父元素结束
	 * 
	 * @return
	 */
	public List<TagItem> findParentItems() {
        TagItem parent = m_parentItem;
		List<TagItem> parents = new ArrayList<TagItem>(3);
        while (parent != null) {
            parents.add(parent);
            parent = parent.getParent();
        }

        return parents;
    }

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 16, 2011
	 */
	public String getContent() {
		return content;
	}

}