package com.trs.dev4.jdk16.cms.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cms.ICachedBaseManager;
import com.trs.dev4.jdk16.dao.Condition;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.ISerializableEntity;
import com.trs.dev4.jdk16.utils.NumberUtil;

/**
 * 使用缓存的BaseManager
 * 
 * @author yangyu
 * @since Apr 27, 2012 9:24:50 AM
 */
public class CachedBaseManager<T extends ISerializableEntity> extends BaseManager<T> implements ICachedBaseManager<T>, ApplicationContextAware {

	protected ICacheServer cacheServer;
	
	private final static Logger logger = Logger.getLogger(CachedBaseManager.class);

	// 保存或者更新
	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.ISerializableEntity)
	 */
	@Override
	public void saveOrUpdate(T entity) {
		super.saveOrUpdate(entity);
		cacheObject(entity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#update(com.trs.dev4.jdk16.model.ISerializableEntity)
	 */
	@Override
	public void update(T masObj) {
		this.saveOrUpdate(masObj);
	}

	// id获取
	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#find(int)
	 */
	@Override
	public T find(int objectId) {
		return cacheGet(objectId);
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#get(int)
	 */
	@Override
	public T get(int objectId) {
		return cacheGet(objectId);
	}

	// 删除
	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#delete(com.trs.dev4.jdk16.model.ISerializableEntity)
	 */
	@Override
	public void delete(T entity) {
		super.delete(entity);
		deleteCache(entity);
	}

	// 分页获取
	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter, boolean)
	 */
	public PagedList<T> pagedObjects(SearchFilter searchFilter, boolean cached) {

		if (cacheServer == null) {
			return super.pagedObjects(searchFilter);
		}
		
		PagedList<Integer> idsPagedList = null;
		String key = this.buildKey(searchFilter);

		if (cached) {
			Object obj = cacheServer.get(key);
			if (obj == null) {
				idsPagedList = this.pagedObjectIds(searchFilter);
				cacheServer.set(key, this.getListExpiration(), idsPagedList);
			} else {
				idsPagedList = (PagedList<Integer>) obj;
			}
		} else {
			idsPagedList = this.pagedObjectIds(searchFilter);
			cacheServer.set(key, this.getListExpiration(), idsPagedList);
		}

		List<T> fixurePosts = new ArrayList<T>();
		for (int id : idsPagedList.getPageItems()) {
			fixurePosts.add(this.get(id));
		}
		return new PagedList<T>(fixurePosts, idsPagedList.getPageIndex(), idsPagedList.getPageSize(), idsPagedList.getTotalItemCount());
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#findFirst(com.trs.dev4.jdk16.dao.SearchFilter, boolean)
	 */
	public T findFirst(SearchFilter sf, boolean cached) {
		
		if (cacheServer == null) {
			return super.findFirst(sf);
		}

		Object obj = null;
		PagedList idList = null;
		
		if (cached) {
			String key = buildKey(sf) + "_first";

			obj = cacheServer.get(key);
			
			if (obj == null) {
				sf.setMaxResults(1);
				idList = super.pagedObjectIds(sf);	
				cacheServer.set(key, this.getListExpiration(), idList);
			} else {
				idList = (PagedList) obj;
			}

			if (idList.size() == 0) {
				return null;
			} else {
				return this.get((Integer) idList.get(0));
			}
			
		} else {
			return super.findFirst(sf);
		}
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#findUnique(com.trs.dev4.jdk16.dao.SearchFilter, boolean)
	 */
	public T findUnique(SearchFilter sf, boolean cached) {
		
		if (cacheServer == null) {
			return super.findUnique(sf);
		}
		Object obj = null;
		PagedList idList = null;
		
		if (cached) {
			String key = buildKey(sf) + "_unique";

			obj = cacheServer.get(key);

			if (obj == null) {
				sf.setMaxResults(1);
				idList = super.pagedObjectIds(sf);
				cacheServer.set(key, this.getListExpiration(), idList);
			} else {
				idList = (PagedList) obj;
			}

			if (idList.size() == 0) {
				return null;
			} else {
				return this.get((Integer) idList.get(0));
			}
			
		} else {
			return super.findUnique(sf);
		}
	}

	/**
	 * 将数据加入缓存中，如果object为null,初始化 数据到缓存中，调用onCacheObject方法，处理更新缓存后做什么事
	 * 
	 * @param object
	 */
	protected void cacheObject(T object) {
		
		if (cacheServer == null) {
			return;
		}

		String cacheKey = buildKey(object);
		cacheServer.set(cacheKey, getExpiration(), object);
		if (logger.isDebugEnabled()) {
			logger.debug("Entity saved(" + object + ") to memcache with(" + cacheKey + ").");
		}

	}

	/**
	 * 构造缓存键值的前缀，为“Object_”
	 * 
	 * @return 缓存键值的前缀
	 */
	public String buildKeyPrefix() {
		return super.getClass().getSimpleName() + "_";
	}

	/**
	 * 缓存数据过期时间
	 * 
	 * @return
	 */
	protected int getExpiration() {
		return this.getDefaultExpiration();
	}

	/**
	 * 缓存数据过期时间
	 * 
	 * @return
	 */
	protected int getListExpiration() {
		return this.getDefaultListExpiration();
	}

	/**
	 * 根据要缓存的对象，构建缓存的键值，格式为"Object_1"
	 * 
	 * @return
	 */
	protected String buildKey(T entity) {
		return this.buildKeyPrefix() + entity.getId();
	}

	/**
	 * <b>职责:</b> 根据SearchFilter查询条件 构造缓存的键值<br>
	 * 
	 * @param sf
	 *            参见{@link SearchFilter}
	 * @return 键值
	 */
	protected String buildKey(SearchFilter sf) {

		StringBuilder strBuf = new StringBuilder();
		strBuf.append("params[");

		int totalConditions = sf.getTotalConditions();
		for (int i = 0; i < totalConditions; i++) {
			Condition condition = sf.getCondition(i);
			strBuf.append("(").append(condition.getField()).append(' ');
			strBuf.append(condition.getOp()).append(' ');
			if (condition.needBindCollectionParam()) {
				Object value = condition.getValue();
				if (value.getClass().isArray()) {
					for (Object obj : (Object[]) value) {
						strBuf.append(obj).append(" ");
					}
				} else {
					strBuf.append(value);
				}
			} else if (condition.isBetweenCondition()) {
				strBuf.append(condition.getValue());
				strBuf.append(" and ").append(condition.getValue2());
			} else if (condition.needBindOneParam()) {
				strBuf.append(condition.getValue());
			}
			strBuf.append(")");
		}
		strBuf.append("]").append("orderby[").append(sf.getOrderBy()).append("]");
		strBuf.append("startPos[").append(sf.getStartPos()).append("]pageSize[").append(sf.getMaxResults()).append("]");

		return this.buildKeyPrefix() + strBuf.toString();
	}

	/**
	 * 本地缓存删除objectsIndex中的数据，cacheServer直接调用delete方法删除缓存数据
	 * 
	 * @param entity
	 * @since TRS@Dec 28, 2010
	 */
	void deleteCache(T entity) {
		
		if (cacheServer == null) {
			return;
		}
		
		cacheServer.delete(buildKey(entity));
		if (logger.isDebugEnabled()) {
			logger.debug("Entity deleted(" + entity + ") from memcache.");
		}
	}

	protected String buildUpdatedKey() {
		return this.getPrefix() + "updated";
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#getPrefix()
	 */
	@Override
	public String getPrefix() {
		return super.getPrefix() + "_";
	}

	/**
	 * 根据要缓存对象的ID，构建缓存的KEY值
	 * 
	 * @return 键值
	 */
	protected String buildKey(int id) {
		return this.buildKeyPrefix() + id;
	}

	/**
	 * 从缓存中获取对象，缓存中为空从数据库中获取值，并更新缓存到数据库
	 * 
	 * @param objectId
	 *            对象ID
	 * @return 对象
	 */
	protected T cacheGet(int objectId) {

		if (cacheServer == null) {
			return super.get(objectId);
		}
		
		String key = buildKey(objectId);

		T object = (T) cacheServer.get(key);
		if (object == null) {
			object = super.get(objectId);
			cacheServer.add(key, this.getExpiration(), object);
		}
		return object;
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#total(com.trs.dev4.jdk16.dao.SearchFilter, boolean)
	 */
	public int total(SearchFilter sf, boolean cached) {

		if (cacheServer == null) {
			return super.total(sf);
		}
		
		if (cached) {
			String key = buildKey(sf) + "_total";

			Object total = cacheServer.get(key);
			if (total == null) {
				total = super.total(sf);
				cacheServer.set(key, this.getTotalExpiration(), total);
			}
			return NumberUtil.parseInt(total, 0);
		} else {
			return super.total(sf);
		}

	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public PagedList<T> pagedObjects(SearchFilter sf) {
		return this.pagedObjects(sf, false);
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#pagedAll()
	 */
	@Override
	public PagedList<T> pagedAll() {
		return this.pagedObjects(SearchFilter.getDefault());
	}

	/*
	 * 
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#pagedAll(boolean)
	 */
	public PagedList<T> pagedAll(boolean cached) {
		return this.pagedObjects(SearchFilter.getDefault(), cached);
	}

	/**
	 * <b>职责:</b>获取系统配置中的对象总数缓存时间 <br>
	 * 
	 * @return 缓存时间
	 */
	protected int getTotalExpiration() {
		return this.getDefaultTotalExpiration();
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#buildCachedConfig()
	 */
	public String buildCachedConfig() {
		return this.getClass().getSimpleName() + "Expr";
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#getDefaultExpiration()
	 */
	@Override
	public int getDefaultExpiration() {
		return 600;
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#getDefaultListExpiration()
	 */
	@Override
	public int getDefaultListExpiration() {
		return 300;
	}

	/*
	 * non-Javadoc)
	 * 
	 * @see com.trs.forum.business.ICachedBaseManager#getDefaultTotalExpiration()
	 */
	@Override
	public int getDefaultTotalExpiration() {
		return 300;
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since yangyu @ May 23, 2012
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if (applicationContext.containsBean("cacheServer")) {
			this.cacheServer = (ICacheServer) applicationContext.getBean("cacheServer");
		}
	}
	
}
