/*
 * Created: TRS@Mar 5, 2011 4:55:03 PM
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.IPublishable;

/**
 * 
 *
 */
public class Week implements IPublishable {
	/**
	 * 
	 */
	private String title;

	/**
	 * 
	 * @param title
	 */
	public Week(String title){
		this.title = title;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IPublishable#getProperty(java.lang.String)
	 * @since TRS @ Mar 5, 2011
	 */
	@Override
	public String getProperty(String name) {
		return title;
	}

}
