/*
 * Created: TRS@Feb 13, 2012 9:11:30 PM
 */
package com.trs.dev4.jdk16.cacheserver;

/**
 * 职责: 注册和取消注册，{@link ObjectCachePolicy}<br>
 * 
 */
public interface IObjectCachePolicyRegister {
	/**
	 * 注册新的对象缓存策略，并返回已有的对象缓存策略。
	 * 
	 * @param objectCachePolicy
	 *            新的对象缓存策略
	 * @return 已有的对象缓存策略，如果没有则返回null。
	 * @since TRS @ Feb 9, 2012
	 */
	ObjectCachePolicy register(ObjectCachePolicy objectCachePolicy);

	/**
	 * 注销已有的对象缓存策略，并返回已有的对象
	 * 
	 * @param keyPrefix
	 *            注销的对象混村策略{@link ObjectCachePolicy#getKeyPrefix()}
	 * @return 与keyPrefix相关的对象缓存策略。
	 * @since TRS @ Feb 9, 2012
	 */
	ObjectCachePolicy unregister(String keyPrefix);
}
