package com.trs.dev4.jdk16.cacheserver.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;

import org.apache.log4j.Logger;
import org.hibernate.util.StringHelper;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;

/**
 * 缓存服务器的本地实现
 * 
 */
public class LocalCacheServer implements ICacheServer, ApplicationContextAware {
	/**
	 * 
	 */
	private static ApplicationContext applicationContext;
	/**
	 * 
	 */
	private final static Map<String, ICacheServer> instancedCacheServers = new ConcurrentHashMap<String, ICacheServer>();
	/**
	 * 
	 */
	protected static Logger logger = Logger.getLogger(LocalCacheServer.class);
	/**
	 * 
	 */
	private Cache ehCacheServer = null;
	/**
	 * 
	 */
	private static CacheManager cacheManager = null;
	/**
	 * 最长过期时间
	 */
	int maxExpire = 20 * 60;

	/**
	 * 当前应用的缓存前缀
	 */
	String appKey = "trs:";

	/**
	 * 设置最长过期时间
	 * 
	 * @param maxExpire
	 * @since liuyou @ 2010-5-23
	 */
	public void setMaxExpire(int maxExpire) {
		this.maxExpire = maxExpire;
	}

	/**
	 * 过期时间的处理，超长或者为负时设置为最长过期时间
	 * 
	 * @param expire
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	public int getExpire(int expire) {
		return (expire <= 0 || expire > maxExpire) ? maxExpire : expire;
	}

	/**
	 * 
	 * 
	 * @since TRS @ Feb 13, 2012
	 */
	protected void initializeCache() {
		injectCacheManagerFromSpringIoC();
		if (cacheManager == null) {
			cacheManager = CacheManager.create();
		}
		ehCacheServer = new Cache(new CacheConfiguration("localCache@" + this.hashCode(), 1000000));
		cacheManager.addCache(ehCacheServer);
		logger.info("LocalCache server started with cacheManager(" + cacheManager + ") and cache(" + ehCacheServer + ").");
	}

	/**
	 * 
	 * @since liushen @ Feb 15, 2012
	 */
	void injectCacheManagerFromSpringIoC() {
		if (applicationContext == null) {
			return;
		}
		if (applicationContext.containsBean("localCacheManager")) {
			cacheManager = (CacheManager) applicationContext.getBean("localCacheManager");
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void add(String key, int expr, Object value) {
		Element element = new Element(key, value);
		element.setTimeToLive(expr);
		ehCacheServer.put(element);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#delete(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void delete(String key) {
		ehCacheServer.remove(key);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public Object get(String key) {
		Element element = ehCacheServer.get(key);
		if (element == null) {
			return null;
		}
		return element.getObjectValue();
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		this.set(key, expr, value);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void set(String key, int expr, Object value) {
		this.add(key, expr, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void set(String key, Object value) {
		this.set(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void add(String key, Object value) {
		this.add(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void replace(String key, Object value) {
		this.replace(key, this.maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public Object get(String key, Object defaultVal) {
		Object value = this.get(key);
		return value == null ? defaultVal : value;
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		LocalCacheServer.applicationContext = applicationContext;
		initializeCache();
	}

	/**
	 * 
	 * @param applicationContext
	 * @since TRS @ Feb 14, 2012
	 */
	public static void autowireApplicationContext(ApplicationContext applicationContext) {
		LocalCacheServer.applicationContext = applicationContext;
	}

	/**
	 * 根据名称获取缓存服务器
	 * 
	 * @param cacheServerName
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	public static ICacheServer getInstance(String cacheServerName) {
		if (StringHelper.isEmpty(cacheServerName)) {
			return getDefaultInstance();
		}
		ICacheServer cacheServer = instancedCacheServers.get(cacheServerName);
		if (cacheServer == null) {
			cacheServer = new LocalCacheServer();
			((LocalCacheServer) cacheServer).setApplicationContext(applicationContext);
			instancedCacheServers.put(cacheServerName, cacheServer);
		}
		return cacheServer;
	}

	/**
	 * 根据名称获取缓存服务器
	 * 
	 * @param cacheServerName
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	public static ICacheServer getDefaultInstance() {
		return getInstance("_default_");
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#clearAll()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void clearAll() {
		ehCacheServer.removeAll();
	}
}
