package com.trs.dev4.jdk16.cacheserver.memcached;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import net.spy.memcached.AddrUtil;
import net.spy.memcached.ConnectionFactory;
import net.spy.memcached.MemcachedClient;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * memcached客户端的spyImpl实现
 *
 */
public class MemcachedClientSpyImpl implements IMemcachedClient {

	private final static Logger logger = Logger
			.getLogger(MemcachedClientSpyImpl.class);
	/**
	 *
	 */
	MemcachedClient memcachedClient;
	/**
	 *
	 */
	private String addresses;

	/**
	 *
	 */
	private ConnectionFactory factory;

	/**
	 * 采用KetamaBinaryConnectionFactory策略的连接工厂
	 * 
	 * @param addresses
	 *            memcached服务端的地址，用分号或者空格分隔多个地址
	 * @throws Exception
	 */
	public MemcachedClientSpyImpl() throws Exception {
		factory = new KetamaBinaryConnectionFactory();
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#delete(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void delete(String key) {
		memcachedClient.delete(key);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#get(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public Object get(String key) {
		return memcachedClient.get(key);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#set(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void set(String key, int expr, Object value) {
		memcachedClient.set(key, (expr), value);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#add(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void add(String key, int expr, Object value) {
		if (memcachedClient.get(key) != null)
			return;
		memcachedClient.add(key, (expr), value);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#replace(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		if (memcachedClient.get(key) == null)
			return;
		memcachedClient.replace(key, (expr), value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getStats()
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public Map<String, String> getStats(String server) {
		return new HashMap<String, String>();
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getStat(java.lang.String)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public Map<String, String> getStats(String server, String itemName) {
		return new HashMap<String, String>();
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#asynGet(java.lang.String)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public Object asynGet(String key) {
		Future<Object> f = memcachedClient.asyncGet(key);
		try {
			return f.get(5, TimeUnit.SECONDS);
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
			// Since we don't need this, go ahead and cancel the operation. This
			// is not strictly necessary, but it'll save some work on the
			// server.
			f.cancel(false);
			// Do other timeout related stuff
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (ExecutionException e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getAvaliableServers()
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public Collection<InetSocketAddress> getAvaliableServers() {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getServersDescription()
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public List<String> getServersDescription() {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#listAllKeys(java.lang.String)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public List<String> listAllKeys(String server) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public void connect(Map<String, String> configurations) {
		String confAddresses = configurations.get("addresses");
		// 如果配置和现在的地址一样，不用修改
		if (addresses.equalsIgnoreCase(confAddresses)) {
			return;
		}
		// 先停止
		this.close();
		// 然后重启
		try {
			memcachedClient = new MemcachedClient(factory, AddrUtil.getAddresses(addresses));
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			memcachedClient = null;
		}
	}
	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public void close() {
		if (memcachedClient != null) {
			memcachedClient.shutdown();
			memcachedClient = null;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getName()
	 * @since TRS @ Oct 9, 2011
	 */
	@Override
	public String getName() {
		return this.getClass().getName();
	}
}
