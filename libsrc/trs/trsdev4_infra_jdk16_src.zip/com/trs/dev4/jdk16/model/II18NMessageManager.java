/*
 * Created: TRS@Feb 11, 2012 5:27:23 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.Locale;


/**
 * 职责：管理{@link I18NMessage}，实现增删查改 <br>
 * 
 */
public interface II18NMessageManager extends IBaseManager<I18NMessage> {
	/**
	 * 查找消息
	 * 
	 * @param messageKey
	 *            消息主键
	 * @param language
	 *            语言
	 * @param country
	 *            国家
	 * @return
	 * @since TRS @ Feb 11, 2012
	 */
	I18NMessage find(String messageKey, String language, String country);

	/**
	 * 根据Locale获取消息
	 * 
	 * @param messageKey
	 *            消息主键
	 * @param locale
	 *            与主键匹配的语言
	 * @return
	 * @since TRS @ Feb 11, 2012
	 */
	I18NMessage find(String messageKey, Locale locale);

	/**
	 * 获取messageKey对应的所有消息
	 * 
	 * @param messageKey
	 * @return
	 * @since TRS @ Feb 11, 2012
	 */
	I18NMessage[] list(String messageKey);
}
