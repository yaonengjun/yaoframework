package com.trs.dev4.jdk16.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.AccessType;

import com.trs.dev4.jdk16.actionlog.IActionlogExtendable;
import com.trs.dev4.jdk16.utils.DateUtil;

/**
 * 领域对象的默认抽象基类, 仅限内部使用；对外则均以{@link IEntity}接口方式提供.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
@MappedSuperclass
public abstract class BaseEntity extends BeanMappedEntity implements IEntity, IActionlogExtendable {

	/**
	 * @since TRS @ Feb 14, 2012
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 数据表ID，无业务含义.
	 */
	@Id
	@GeneratedValue(generator = "idStrategy")
	@Column(name = "`ID`")
	protected int id = 0;
	/**
	 * 创建时间; 一经创建，此属性不能再被修改.
	 */
	@Column(name = "`CREATEDTIME`", updatable = false)
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	protected long createdTime;
	/**
	 * 创建人.
	 */
	@Column(name = "`CREATEDUSER`")
	protected String createdUser;
	/**
	 *
	 */
	@Column(name = "`CREATEDUSERID`")
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	protected int createdUserId;
	/**
	 * 最后修改时间.
	 */
	@Column(name = "`LASTMODIFIEDTIME`")
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	protected long lastModifiedTime;
	/**
	 * 最后修改人.
	 */
	@Column(name = "`LASTMODIFIEDUSER`")
	protected String lastModifiedUser;
	/**
	 * 最后修改人编号.
	 */
	@Column(name = "`LASTMODIFIEDUSERID`")
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	protected int lastModifiedUserId;

	/**
	 * @return the {@link #id}
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the {@link #id} to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 判断对象是新建对象还是已有对象
	 * 
	 * @return true表示新建对象，false表示已有对象
	 * @since fangxiang @ Nov 4, 2010
	 */
	public boolean isNew() {
		return id == 0;
	}

	/**
	 * 判断对象属于指定的用户
	 * 
	 * @param userId
	 *            用户编号
	 * @return true表示属于，false表示不属于
	 * @since fangxiang @ Nov 4, 2010
	 */
	public boolean isOwner(int userId) {
		return this.createdUserId == userId;
	}

	/**
	 * Get the {@link #createdTime}.
	 * 
	 * @return the {@link #createdTime}.
	 */
	@Override
	public long getCreatedTime() {
		return createdTime;
	}

	/**
	 * Get the {@link #createdTime} as java.util.Date.
	 * 
	 * @return
	 * @since liuyou @ 2010-4-26
	 */
	public Date getCreatedTimeAsDate() {
		return new Date(getCreatedTime());
	}

	/**
	 * Set the {@link #createdTime}.
	 * 
	 * @param createdTime
	 *            the createdTime to set
	 */
	public void setCreatedTime(long createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * Get the {@link #createdUser}.
	 * 
	 * @return the {@link #createdUser}.
	 */
	@Override
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * Set the {@link #createdUser}.
	 * 
	 * @param createdUser
	 *            the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * Get the {@link #lastModifiedTime}.
	 * 
	 * @return the {@link #lastModifiedTime}.
	 */
	@Override
	public long getLastModifiedTime() {
		return lastModifiedTime;
	}

	/**
	 * Get the {@link #lastModifiedTime} as java.util.Date.
	 * 
	 * @return
	 * @since liuyou @ 2010-4-26
	 */
	public Date getLastModifiedTimeAsDate() {
		return new Date(getLastModifiedTime());
	}

	/**
	 * Set the {@link #lastModifiedTime}.
	 * 
	 * @param lastModifiedTime
	 *            the lastModifiedTime to set
	 */
	public void setLastModifiedTime(long lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	/**
	 * Get the {@link #lastModifiedUser}.
	 * 
	 * @return the {@link #lastModifiedUser}.
	 */
	@Override
	public String getLastModifiedUser() {
		return lastModifiedUser;
	}

	/**
	 * Set the {@link #lastModifiedUser}.
	 * 
	 * @param lastModifiedUser
	 *            the lastModifiedUser to set
	 */
	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	/**
	 * Get the {@link #lastModifiedUserId}.
	 * 
	 * @return the {@link #lastModifiedUserId}.
	 */
	public int getLastModifiedUserId() {
		return lastModifiedUserId;
	}

	/**
	 * Set the {@link #lastModifiedUserId}.
	 * 
	 * @param lastModifiedUser
	 *            the lastModifiedUser to set
	 */
	public void setLastModifiedUserId(int lastModifiedUserId) {
		this.lastModifiedUserId = lastModifiedUserId;
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 16, 2010
	 */
	public int getCreatedUserId() {
		return createdUserId;
	}

	/**
	 * 
	 * @param createdUserId
	 * @since fangxiang @ Apr 16, 2010
	 */
	public void setCreatedUserId(int createdUserId) {
		this.createdUserId = createdUserId;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ May 7, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[").append(getClass().getSimpleName()).append("@").append(Integer.toHexString(hashCode()));
		builder.append(", id=").append(getId());
		if (hasModified()) {
			builder.append(", lastModified on ").append(
					DateUtil.formatMillis(getLastModifiedTime()));
			builder.append(", by (").append(lastModifiedUserId).append(")")
					.append(lastModifiedUser);
		} else {
			builder.append(", created on ").append(
					DateUtil.formatMillis(getCreatedTime()));
			builder.append(", by (").append(createdUserId).append(")")
					.append(createdUser);
		}
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @since liushen @ Jun 24, 2010
	 */
	@Override
	public boolean equals(Object obj) {
		if (false == (obj instanceof BaseEntity)) {
			return false;
		}
		if (false == getClass().equals(obj.getClass())) {
			return false;
		}
		BaseEntity another = (BaseEntity) obj;
		return this.getId() == another.getId();
	}

	/**
	 * 对象是否被修改过(根据创建时间和最后修改时间来判断).
	 * 
	 * @return 若最后修改时间更晚，则返回<code>true</code>，否则返回<code>false</code>.
	 * @since liushen @ May 7, 2010
	 */
	private boolean hasModified() {
		return lastModifiedTime > createdTime;
	}

	/**
	 * 对象的标志性描述内容，主要用于记日志等诊断场合(类似于toString())， 注意：不是业务角度的描述(业务用语不适合放在对象中硬编码)。
	 * 
	 * @since fangxiang @ Nov 24, 2010
	 */
	public String getDescription() {
		return this.getClass().getSimpleName().toLowerCase() + "_" + this.id;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogExtendable#getExtend1()
	 * @since fangxiang @ Nov 24, 2010
	 */
	@Override
	public String getExtend1() {
		return "";
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogExtendable#getExtend2()
	 * @since fangxiang @ Nov 24, 2010
	 */
	@Override
	public String getExtend2() {
		return "";
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogExtendable#getExtend3()
	 * @since fangxiang @ Nov 24, 2010
	 */
	@Override
	public String getExtend3() {
		return "";
	}
}