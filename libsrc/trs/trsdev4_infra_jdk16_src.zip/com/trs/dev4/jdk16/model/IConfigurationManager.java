/*
 *
 */
package com.trs.dev4.jdk16.model;

import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 负责处理系统范畴的配置，从文件或数据库中读取配置参数，供其他Manager使用。 该接口原本应该继承{@link IBaseManager}
 * ；之所以不从它继承， 是因为要隐藏public的update(Configuration), 避免使用方绕过了配置规则, 直接去更新配置对象.
 */
public interface IConfigurationManager extends IBaseManager<Configuration> {

	/**
	 * 读取字符串类型的配置值.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回<code>null</code>.
	 */
	String getConfiguration(IConfigurable configurable, String name);

	/**
	 * 获取为某节点配置的配置项的值；如果没有专门为该节点配置，则返回为任意节点配置的值。
	 * 
	 * @param configurable
	 * @param name
	 * @param nodeKey
	 * @return
	 * @since liushen @ Jul 12, 2012
	 */
	String getConfigurationForNode(IConfigurable configurable, String name, String nodeKey);

	/**
	 * 读取字符串类型的配置值.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回<code>null</code>.
	 */
	String getConfiguration(IConfigurable configurable, String name,
			Object defValue);

	/**
	 * 配置项是否存在(也即是否配置过).
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回<code>true</code>，否则返回<code>false</code>.
	 * @since liushen @ May 30, 2010
	 */
	boolean existsOrConfigured(IConfigurable configurable, String name);

	/**
	 * 读取整数类型的配置值.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            属性名称
	 * @return 如果存在则返回设置的值，否则返回-1
	 */
	int getConfigurationAsInt(IConfigurable configurable, String name);

	/**
	 * 读取字符串类型的配置值.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回<code>null</code>.
	 */
	int getConfigurationAsInt(IConfigurable configurable, String name,
			int defValue);

	/**
	 * 读取长整型的配置值.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回-1
	 */
	long getConfigurationAsLong(IConfigurable configurable, String name);

	/**
	 * 读取Boolean类型的配置值.
	 * 
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回默认值
	 */
	boolean getConfigurationAsBoolean(IConfigurable configurable, String name,
			boolean defValue);

	/**
	 * 读取长整型的配置值.
	 * 
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @return 如果存在则返回设置的值，否则返回-1
	 */
	long getConfigurationAsLong(IConfigurable configurable, String name,
			long defValue);

	/**
	 * 声明需要初始化并且必须由人工输入的配置项; 如果该配置项已存在，则只更新其显示名称信息.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param cname
	 *            配置项的显示名
	 * @param comment
	 *            配置项的必要说明
	 * @since liushen @ Aug 27, 2010
	 */
	void addSetupKey(IConfigurable configurable, String name, String cname,
			String comment);

	/**
	 * 声明需要初始化并且必须由人工输入或确认的配置项; 如果该配置项已存在，则只更新其显示名称信息.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param cname
	 *            配置项的显示名
	 * @param comment
	 *            配置项的必要说明
	 * @param value
	 *            配置值；如没有配置值则为<code>null</code>.
	 * @since liushen @ Aug 26, 2010
	 */
	void addSetupKey(IConfigurable configurable, String name, String cname,
			String comment, String value);

	/**
	 * 声明需要初始化并且必须由人工输入或确认的配置项; 如果该配置项已存在，则只更新其显示名称信息.
	 * 
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param cname
	 *            配置项的显示名
	 * @param comment
	 *            配置项的必要说明
	 * @param nodeKey
	 *            适用节点的标识；如为空则表示该配置项适用所有节点
	 * @param value
	 *            配置值；如没有配置值则为<code>null</code>.
	 * @since liushen @ Jul 16, 2012
	 */
	void addSetupKey(IConfigurable configurable, String name, String cname, String comment, String nodeKey, String value);

	/**
	 * @deprecated liushen@May 30, 2010: 缺少必需的comment；请使用
	 *             {@link #addConfigKey(IConfigurable, String, String, String)}
	 */
	@Deprecated
	void addConfigKey(IConfigurable configurable, String name, String cname);

	/**
	 * @deprecated liushen@Aug 27, 2010: 缺少必需的comment；请使用
	 *             {@link #addConfigKey(IConfigurable, String, String, String, String)}
	 */
	@Deprecated
	void addConfigKey(IConfigurable configurable, String name, String cname,
			String defValue);

	/**
	 * 声明配置项：即增加配置项，不设置配置值；一般用于在启动时写入可选的配置项。 如果该配置项不存在则新增, 如果已经存在, 则更新其显示名称.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param cname
	 *            配置项的显示名
	 * @param comment
	 *            配置项的必要说明
	 * @param defValue
	 *            配置项的默认值; 如无法给出则指定为<code>null</code>.
	 * @since liushen @ Aug 27, 2010
	 */
	void addConfigKey(IConfigurable configurable, String name, String cname,
			String comment, String defValue);

	/**
	 * 删除配置项；仅用于需要清除废弃的配置项的场合。
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @since liushen @ Jul 9, 2010
	 */
	void deleteKey(IConfigurable configurable, String name);

	/**
	 * 更新配置项的值, 如果该配置项不存在则创建.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param value
	 *            要更新的值
	 * @creator liushen @ Feb 15, 2010
	 */
	void updateConfigValue(IConfigurable configurable, String name, Object value);

	/**
	 * 更新配置项的元数据属性, 如果该配置项不存在则跳过，不做任何处理.
	 *
	 * @param configurable
	 *            被配置的对象
	 * @param name
	 *            配置项的标识名
	 * @param forbidModify
	 *            是否禁止从管理台界面上修改; 为<code>null</code>表示不修改此元数据
	 * @param needEncrypt
	 *            配置值是否需要加密; 为<code>null</code>表示不修改此元数据
	 * @since liushen @ Nov 2, 2010
	 */
	void updateConfigMetadata(IConfigurable configurable, String name,
			Boolean forbidModify, Boolean needEncrypt);

	/**
	 * 将给定的配置项标记为节点相关的；该配置项需要已经存在，其他属性则从任意节点或其他节点获取。
	 * 
	 * @param configurable
	 * @param name
	 * @param node
	 * @since liushen @ Jul 12, 2012
	 */
	void markConfigNode(IConfigurable configurable, String name, String node);

	/**
	 * 更新配置项的值, 如果该配置项不存在则创建.
	 *
	 * @param configurable
	 * @param configWithNewValue
	 * @creator liushen @ Feb 16, 2010
	 */
	void updateConfigValue(IConfigurable configurable,
			Configuration configWithNewValue);

	/**
	 *
	 * @param configurable
	 * @return 配置对象构成的List
	 * @creator liushen @ Feb 15, 2010
	 */
	List<Configuration> list(IConfigurable configurable);

	/**
	 * 从List中解出该模块对应的配置项.
	 *
	 * @param configurable
	 *            被配置的模块
	 * @param configs
	 *            配置对象构成的List
	 * @return 该模块对应的配置项的集合, List形式
	 * @creator liushen @ Feb 16, 2010
	 */
	Map<String, Configuration> extractModuleConfig(IConfigurable configurable,
			List<Configuration> configs);

	/**
	 * 从Map中解出该模块对应的配置项.
	 *
	 * @param configurable
	 *            被配置的模块
	 * @param cfgMap
	 *            配置的Map: 键为配置的前缀+名称，值为配置对象本身.
	 * @return 该模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @since liushen @ Aug 4, 2010
	 */
	Map<String, Configuration> extractModuleConfig(IConfigurable configurable,
			Map<String, Configuration> cfgMap);

	/**
	 * 从Map中解出该模块对应的配置项.
	 *
	 * @param prefix
	 *            被配置的模块的前缀
	 * @param cfgMap
	 *            配置的Map: 键为配置的前缀+名称，值为配置对象本身.
	 * @return 该模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @since liushen @ Aug 11, 2010
	 */
	Map<String, Configuration> extractModuleConfig(String prefix,
			Map<String, Configuration> cfgMap);

	/**
	 * 给模块的配置项的Map增加该模块的前缀，用于统一的系统配置页面.
	 *
	 * @param prefix
	 *            被配置的模块的前缀
	 * @param cfgMap
	 *            模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @return 配置的Map: 键为配置的前缀+名称，值为配置对象本身.
	 * @since liushen @ Aug 11, 2010
	 */
	Map<String, Configuration> addPrefixToModuleConfig(String prefix,
			Map<String, Configuration> cfgMap);

	/**
	 * 将配置List转换为配置的Map.
	 *
	 * @param configs
	 *            配置对象构成的List
	 * @return 配置的Map: 键为配置的前缀+名称，值为配置对象本身.
	 * @since liushen @ Aug 3, 2010
	 */
	Map<String, Configuration> toMapWithPrefixs(List<Configuration> configs);

	/**
	 *
	 * @param prefix
	 *            模块前缀
	 * @return 模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @creator liushen @ Feb 18, 2010
	 */
	public Map<String, Configuration> getModuleConfigs(String prefix);

	/**
	 * 从模块的配置Map中获取给定name(不含prefix)的配置值.
	 *
	 * @param configs
	 *            模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @param nameWithoutPrefix
	 *            配置项的名称, 不含前缀
	 * @return 配置值
	 * @since liushen @ Aug 4, 2010
	 */
	String getValueFromModuleConfigMap(Map<String, Configuration> configs,
			String nameWithoutPrefix);

	/**
	 * 判断给定的模块配置的Map中是否包含给定name(不含prefix)的配置.
	 *
	 * @param configs
	 *            模块的配置项的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @param nameWithoutPrefix
	 *            配置项的名称, 不含前缀
	 * @return 包含返回<code>true</code>, 否则返回<code>false</code>.
	 * @since liushen @ Aug 4, 2010
	 */
	boolean containsModuleConfigName(Map<String, Configuration> configs,
			String nameWithoutPrefix);

	/**
	 * 列出所有已知的<code>{@link IConfigurable}</code>.
	 *
	 * @return 所有已知的<code>{@link IConfigurable}</code>组成的List.
	 * @creator liushen @ Feb 15, 2010
	 */
	List<IConfigurable> listKnownConfigurable();

	/**
	 */
	Configuration find(int id);

	/**
	 * @param sf
	 * @creator liushen @ Feb 15, 2010
	 */
	PagedList<Configuration> pagedObjects(SearchFilter sf);

	/**
	 * 启动配置管理器，同时传入该节点标识.
	 * 
	 * @param nodeKey
	 *            本节点的标识
	 * @since liushen @ Jul 16, 2012
	 */
	void start(String nodeKey);

	/**
	 *
	 * @creator liushen @ Feb 15, 2010
	 */
	void stop();

	/**
	 * 列出所有需要初始化的配置.
	 *
	 * @return 配置对象构成的List
	 * @creator liushen @ Feb 16, 2010
	 */
	List<Configuration> listNeedSetup();

	/**
	 * 列出已经配置了的初始化配置项，用于补充初始化时做显示提示等.
	 *
	 * @return 配置对象构成的List
	 * @creator liushen @ Feb 16, 2010
	 */
	List<Configuration> listExistedSetupConfig();

	/**
	 * 列出已经存在的所有配置项.
	 *
	 * @return 配置对象构成的List
	 * @since liushen @ Aug 15, 2010
	 */
	List<Configuration> listExistedConfig();

	/**
	 * 列出尚未配置的的初始化配置项，用于补充初始化等.
	 *
	 * @return 配置对象构成的List
	 * @creator liushen @ Feb 16, 2010
	 */
	List<Configuration> listMissingSetupConfig();

	/**
	 * @param prefix
	 * @param moduleConfigs
	 * @creator liushen @ Feb 19, 2010
	 */
	void updateModuleConfigs(String prefix,
			Map<String, Configuration> moduleConfigs);

	/**
	 * @param prefix
	 * @return 配置对象构成的List
	 * @creator liushen @ Feb 19, 2010
	 */
	public List<Configuration> listModuleConfigs(String prefix);

	/**
	 * @param prefix
	 * @param moduleConfigs
	 * @creator liushen @ Feb 19, 2010
	 */
	public void updateModuleConfigs(String prefix,
			List<Configuration> moduleConfigs);

	/**
	 * @param groupedConfiguration
	 * @creator liushen @ Feb 19, 2010
	 */
	void updateModuleConfigs(GroupedConfiguration groupedConfiguration);

	/**
	 * 根据前缀获得对应的IConfigurable实现
	 * 
	 * @param prefix
	 * @return
	 * @since TRS @ Oct 22, 2010
	 */
	IConfigurable getConfigurable(String prefix);

	/**
	 * 批量更新配置信息
	 * 
	 * @param configurations
	 * @since TRS @ Oct 22, 2010
	 */
	void update(List<Configuration> configurations);

	/**
	 * 注册配置器
	 * 
	 * @param configurable
	 * @since TRS @ Jan 8, 2011
	 */
	void registerConfigurable(IConfigurable configurable);

	/**
	 * 将bean注册为配置项的选项阅读器
	 * 
	 * @param bean
	 * @since TRS @ Jan 30, 2012
	 */
	void registerConfigurationOptionReader(IConfigurationOptionReader bean);

	/**
	 * 获取指定配置项的选项列表
	 * 
	 * @param configuration
	 *            配置项
	 * @param sf
	 *            查询列表
	 * @return 配置项选项列表，如果没有则返回空集合（而不是null）.
	 * @since TRS @ Jan 30, 2012
	 */
	List<ConfigurationOption> readOptions(Configuration configuration, SearchFilter sf);

	/**
	 * 根据指定的阅读器名字获取阅读器实例，可以通过{@link Configuration#getOptionsReader()}获取
	 * 
	 * @param optionReaderName
	 *            阅读器名称
	 * @return 阅读器实例，如果没有找到则返回null。
	 * @since TRS @ Jan 30, 2012
	 */
	IConfigurationOptionReader getConfigurationOptionReader(String optionReaderName);

	/**
	 * 返回与名称匹配的第一个配置项，兼容论坛的代码。如果有多个则返回第一个；ParameterName 等价于 Name;
	 * 
	 * @param paramName
	 *            配置项的名称，不包含prefix
	 * @return 符合名称的第一个配置项
	 * @since TRS @ Jan 31, 2012
	 */
	public Configuration getByParameterName(String paramName);

	/**
	 * 更新配置项值
	 * 
	 * @param configurable
	 *            配置项前缀
	 * @param name
	 *            属性名
	 * @param newValue
	 *            新值
	 * @retrun 返回旧的值
	 * @since TRS @ Feb 14, 2012
	 */
	public String saveOrUpdate(IConfigurable configurable, String name, String newValue);
}
