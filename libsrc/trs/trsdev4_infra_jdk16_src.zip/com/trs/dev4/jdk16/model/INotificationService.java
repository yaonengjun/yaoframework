/*
 * Created: TRS@Feb 13, 2012 9:42:34 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: 定义通知的接受和发送接口<br>
 * 
 */
public interface INotificationService {
	/**
	 * 发送通知
	 * 
	 * @param notification
	 * @since TRS @ Feb 13, 2012
	 */
	public void notify(INotification notification);
}
