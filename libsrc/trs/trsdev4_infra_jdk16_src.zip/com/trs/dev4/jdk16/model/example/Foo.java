/*
 * Created: liushen@Oct 24, 2009 1:15:02 PM
 */
package com.trs.dev4.jdk16.model.example;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.PolymorphismType;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 用来示例的领域对象.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "FOO")
@MappedSuperclass
@org.hibernate.annotations.Entity(polymorphism = PolymorphismType.EXPLICIT)
// @GenericGenerator(name = "idStrategy", strategy =
// "org.hibernate.id.IdentityGenerator") --> Oracle下报错：Dialect does not support
// identity key generation
@GenericGenerator(name = "idStrategy", strategy = "native")
// @GenericGenerator(name = "idStrategy", strategy = "native", parameters = {
// @Parameter(name = "sequence", value = "fooSequence") })
public class Foo extends BaseEntity {

	/**
	 * 
	 */
	@Column(name = "`NAME`")
	protected String name;

	/**
	 * 不需要持久化的字段，用来做示例.
	 */
	@Transient
	protected String temp;

	/**
	 * 用来做示例测试的int型字段.
	 */
	@Column(name = "`BITRATE`")
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	private int bitrate;

	/**
	 * 用来做示例测试的long型字段.
	 */
	@Column(name = "`SIZE`")
	@AccessType("com.trs.idm.util.hb.SafeDirectPropertyAccessor")
	private long size;

	// 指定列名、长度等
	@Column(name = "`DETAIL`", length = 512)
	private String detail;

	// 大字段示例
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "`SUBTITLE`", length = 10485760)
	private String subtitle;

	// 不想保存到数据库中的
	@Transient
	private String strCreatedTime;

	// 枚举类型的示例
	@Column(name = "`RESULT`")
	@Enumerated(value = EnumType.STRING)
	private Result result;

	/**
	 * 
	 */
	public Foo() {
	}

	/**
	 * @param name
	 * @param bitrate
	 * @param size
	 */
	public Foo(String name, int bitrate, long size) {
		this.name = name;
		this.bitrate = bitrate;
		this.size = size;
	}

	/**
	 * Get the {@link #name}.
	 * 
	 * @return the {@link #name}.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the {@link #name}.
	 * 
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the {@link #temp}
	 */
	public String getTemp() {
		return temp;
	}

	/**
	 * @param temp
	 *            the {@link #temp} to set
	 */
	public void setTemp(String temp) {
		this.temp = temp;
	}

	/**
	 * @return the {@link #bitrate}
	 */
	public int getBitrate() {
		return bitrate;
	}

	/**
	 * @param bitrate
	 *            the {@link #bitrate} to set
	 */
	public void setBitrate(int bitrate) {
		this.bitrate = bitrate;
	}

	/**
	 * @return the {@link #size}
	 */
	public long getSize() {
		return size;
	}

	/**
	 * @param size
	 *            the {@link #size} to set
	 */
	public void setSize(long size) {
		this.size = size;
	}

	/**
	 * @return the {@link #detail}
	 */
	public String getDetail() {
		return detail;
	}

	/**
	 * @param detail
	 *            the {@link #detail} to set
	 */
	public void setDetail(String detail) {
		this.detail = detail;
	}

	/**
	 * @return the {@link #subtitle}
	 */
	public String getSubtitle() {
		return subtitle;
	}

	/**
	 * @param subtitle
	 *            the {@link #subtitle} to set
	 */
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	/**
	 * @return the {@link #strCreatedTime}
	 */
	public String getStrCreatedTime() {
		return strCreatedTime;
	}

	/**
	 * @param strCreatedTime
	 *            the {@link #strCreatedTime} to set
	 */
	public void setStrCreatedTime(String strCreatedTime) {
		this.strCreatedTime = strCreatedTime;
	}

	/**
	 * @return the {@link #result}
	 */
	public Result getResult() {
		return result;
	}

	/**
	 * @param result
	 *            the {@link #result} to set
	 */
	public void setResult(Result result) {
		this.result = result;
	}

	public static enum Result {
	
		/**
		 * 成功
		 */
		S,
	
		/**
		 * 失败；失败和错误的区别：失败不一定有错误，不一定需要关注；比如用户登录时输错了用户名密码造成登录失败，这是一个普通的事件.
		 */
		F,
	
		/**
		 * 警告(即虽然可以不算出错，但可能也需要关注)
		 */
		W,
	
		/**
		 * 错误
		 */
		E,
	
		/**
		 * 严重错误(Fatal Error)
		 */
		FE;
	
		public String getText() {
			switch (this) {
			case S:
				return "成功";
	
			case F:
				return "失败";
	
			case W:
				return "警告";
	
			case E:
				return "错误";
	
			case FE:
				return "严重";
	
			default:
				return "无效值";
			}
		}
	
		/**
		 * @see java.lang.Enum#toString()
		 * @since liushen @ Jan 20, 2011
		 */
		@Override
		public String toString() {
			return getText();
		}
	}

}
