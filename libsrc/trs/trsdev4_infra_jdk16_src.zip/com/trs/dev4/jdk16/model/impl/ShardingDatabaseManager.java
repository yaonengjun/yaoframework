/*
 * Created: TRS@Feb 13, 2012 9:40:36 PM
 */
package com.trs.dev4.jdk16.model.impl;

import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.IShardingDatabaseManager;
import com.trs.dev4.jdk16.model.ShardingDatabase;

/**
 * 职责: <br>
 *
 */
public class ShardingDatabaseManager extends BaseManager<ShardingDatabase> implements IShardingDatabaseManager {

}
