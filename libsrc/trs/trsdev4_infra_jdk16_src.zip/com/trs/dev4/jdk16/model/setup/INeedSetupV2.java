/*
 * Created: liushen@Jul 16, 2012 11:52:46 AM
 */
package com.trs.dev4.jdk16.model.setup;

import java.util.Map;

import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;

/**
 * 对需要安装初始化的模块的抽象，支持原因描述、支持多节点。 <br>
 * 
 */
public interface INeedSetupV2 extends IConfigurable {

	/**
	 * 断言该模块不需要初始化.
	 * 
	 * @throws WebSetupException
	 *             需要初始化时抛出
	 */
	void assertSetupped() throws WebSetupException;

	/**
	 * 声明所有需要初始化的配置项.
	 * 
	 * @param envReader
	 *            用于获取环境信息，如安装位置、节点标识等；某些模块的智能初始化准备需要该信息.
	 */
	void prepareSetupKeys(EnvReader envReader);

	/**
	 * 根据所给配置进行初始化，用于系统安装后首次启动的初始化过程以及补充初始化过程中.
	 * 
	 * @param configs
	 *            该模块的配置项构成的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 */
	void setup(Map<String, Configuration> configs);

}
