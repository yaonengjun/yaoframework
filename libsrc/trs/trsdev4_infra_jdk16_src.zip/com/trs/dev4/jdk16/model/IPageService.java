/*
 * Created: TRS@Feb 13, 2012 9:49:02 PM
 */
package com.trs.dev4.jdk16.model;

import com.trs.dev4.jdk16.session.RequestContext;

/**
 * 职责: 定义页面相关的服务<br>
 * 
 */
public interface IPageService {
	/**
	 * 获取页面缓存
	 * 
	 * @param requestContext
	 * @param url
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	public String findPageCache(RequestContext requestContext, String pageKey);

	/**
	 * 更新页面缓存
	 * 
	 * @param requestContext
	 * @param pageKey
	 * @param pageContent
	 * @since TRS @ Feb 13, 2012
	 */
	public void updatePageCache(RequestContext requestContext, String pageKey, String pageContent);
	
	/**
	 * 转换阅读友好的URL
	 * 
	 * @param relativePath
	 * @return
	 * @since TRS @ Feb 14, 2012
	 */
	public String convertReadableUrl(RequestContext requestContext, String relativePath);

	/**
	 * 转换成动态的URL
	 * 
	 * @param relativePath
	 * @return
	 * @since TRS @ Feb 14, 2012
	 */
	public String convertDynamicUrl(RequestContext requestContext, String relativePath);
}
