/*
 * Created: liushen@Aug 5, 2010 7:20:48 AM
 */
package com.trs.dev4.jdk16.model;

import java.util.List;

import com.trs.dev4.jdk16.utils.AssertUtil;

/**
 * 业务实体的一些通用工具方法. <br>
 * 
 */
public class EntityUtil {

	/**
	 * 获取多个实体的id.
	 * 
	 * @param entities
	 *            实体集合
	 * @return 实体id组成的数组
	 * @since liushen @ Aug 5, 2010
	 */
	public static int[] getIdArray(List<? extends IEntity> entities) {
		AssertUtil.notNull(entities, "the entities list is null!");
		int[] idArray = new int[entities.size()];
		for (int i = 0; i < entities.size(); i++) {
			idArray[i] = entities.get(i).getId();
		}
		return idArray;
	}

}
