/*
 * Created: TRS@Feb 13, 2012 9:43:05 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: 定义通知<br>
 * 
 */
public interface INotification {

}
