/*
 * Created: fangxiang@Nov 22, 2010 8:56:57 AM
 */
package com.trs.dev4.jdk16.model;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.TYPE, ElementType.METHOD, ElementType.FIELD })
public @interface AnnotationProperty {
	/**
	 * 
	 * @return 名称
	 * @since fangxiang @ Nov 22, 2010
	 */
	String name() default "";

	/**
	 * 
	 * @return 默认取值
	 * @since fangxiang @ Nov 22, 2010
	 */
	String defValue() default "";
}
