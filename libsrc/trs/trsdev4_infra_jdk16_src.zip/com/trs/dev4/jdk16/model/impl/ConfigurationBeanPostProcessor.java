/*
 * Created: fangxiang@Jan 22, 2011 11:50:00 PM
 */
package com.trs.dev4.jdk16.model.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IConfigurationOptionReader;

/**
 * 职责:Spring环境下的{@link IConfigurable}和{@link IConfigurationOptionReader}自动注册到
 * {@link IConfigurationManager}。{@link IConfigurable}实现配置项的读取、设置和变更通知，
 * {@link IConfigurationOptionReader}实现配置项的动态选项读取。<br>
 * 
 * 
 */
public class ConfigurationBeanPostProcessor implements BeanPostProcessor {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(ConfigurationBeanPostProcessor.class);

	@Resource(name = "configurationManager")
	private IConfigurationManager configurationManager;

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object,
	 *      java.lang.String)
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		return bean;
	}

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object, java.lang.String)
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		if (IConfigurable.class.isAssignableFrom(bean.getClass())) {
			logger.debug("Found IConfigurable(" + bean + ") with beanName("
					+ beanName + ").");
			configurationManager.registerConfigurable((IConfigurable) bean);
		}
		if (IConfigurationOptionReader.class.isAssignableFrom(bean.getClass())) {
			logger.debug("Found IConfigurable(" + bean + ") with beanName(" + beanName + ").");
			configurationManager.registerConfigurationOptionReader((IConfigurationOptionReader) bean);
		}
		return bean;
	}

}
