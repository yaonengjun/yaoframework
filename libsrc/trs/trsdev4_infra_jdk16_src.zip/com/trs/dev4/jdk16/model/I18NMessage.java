/*
 * Created: TRS@Feb 11, 2012 5:26:38 PM
 */
package com.trs.dev4.jdk16.model;

import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


/**
 * 职责: 多语言消息<br>
 * 
 */
@Entity(name = "I18NMessage")
@Table(name = "I18NMESSAGES")
@SequenceGenerator(name = "SEQ_I18NMESSAGE", sequenceName = "SEQ_I18NMESSAGE")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_I18NMESSAGE") })
public class I18NMessage extends BaseEntity {

	/**
	 * @since TRS @ Feb 11, 2012
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private String messageKey;
	/**
	 * 模板内容
	 */
	private String templateContext;
	/**
	 * 语言
	 */
	private String language;
	/**
	 * 国家
	 */
	private String country;

	/**
	 * @return the {@link #templateContext}
	 */
	public String getTemplateContext() {
		return templateContext;
	}

	/**
	 * @param templateContext
	 *            the {@link #templateContext} to set
	 */
	public void setTemplateContext(String templateContext) {
		this.templateContext = templateContext;
	}

	/**
	 * @return the {@link #language}
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language
	 *            the {@link #language} to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the {@link #country}
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the {@link #country} to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the {@link #messageKey}
	 */
	public String getMessageKey() {
		return messageKey;
	}

	/**
	 * @param messageKey
	 *            the {@link #messageKey} to set
	 */
	public void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}
}
