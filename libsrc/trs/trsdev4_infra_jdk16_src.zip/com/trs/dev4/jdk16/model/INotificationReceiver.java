/*
 * Created: TRS@Feb 13, 2012 9:44:02 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: <br>
 *
 */
public interface INotificationReceiver {
	/**
	 * 接受并处理通知
	 * 
	 * @param receivedNotification
	 * @since TRS @ Feb 13, 2012
	 */
	public void receive(INotification receivedNotification);
}
