/*
 * Created: TRS@Feb 14, 2012 1:02:28 PM
 */
package com.trs.dev4.jdk16.model;

import net.sf.cglib.beans.BeanMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 支持用getProperty和setProperty的操作对象属性<br>
 * 
 */
public class BeanMappedEntity {
	/**
	 * 
	 */
	private BeanMap beanMap;

	private static final Logger logger = LoggerFactory.getLogger(BeanMappedEntity.class);

	/**
	 * 
	 * @param propertyName
	 * @return
	 */
	public Object getProperty(String propertyName) {
		if (beanMap == null) {
			initBeanMap();
		}
		return beanMap.get(propertyName);
	}

	/**
	 * 
	 * @param propertyName
	 * @param value
	 */
	public void setProperty(String propertyName, Object value) {
		if (beanMap == null) {
			initBeanMap();
		}
		//
		Class<?> propertyClass = beanMap.getPropertyType(propertyName);
		logger.debug("BeanMappedBaseObject setProperty[propertyName=" + propertyName + ",value=" + value + "] , propertyClass =" + propertyClass);
		if (Integer.class.equals(propertyClass) || Long.class.equals(propertyClass) || int.class.equals(propertyClass)) {
			beanMap.put(propertyName, new Integer(StringHelper.parseInt(String.valueOf(value))));
		} else if (String.class.equals(propertyClass)) {
			beanMap.put(propertyName, value);
		} else if (boolean.class.equals(propertyClass)) {
			beanMap.put(propertyName, new Integer(StringHelper.parseInt(String.valueOf(value))) == 1);
		} else {
			beanMap.put(propertyName, value);
		}
		//
		// beanMap.put(propertyName,value);
	}

	/**
	 * 
	 */
	private void initBeanMap() {
		beanMap = BeanMap.create(this);
	}
}
