/*
 * Created: cl@2008-12-3 下午03:49:02
 */
package com.trs.dev4.jdk16.model.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.collections.map.UnmodifiableMap;
import org.apache.log4j.Logger;
import org.hibernate.util.StringHelper;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.BussinessException;
import com.trs.dev4.jdk16.exception.ConfigException;
import com.trs.dev4.jdk16.exception.ValidateAssertionException;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.ConfigurationOption;
import com.trs.dev4.jdk16.model.GroupedConfiguration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IConfigurationOptionReader;
import com.trs.dev4.jdk16.model.IModuleLifecycle;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.thread.DaemonThreadControllor;
import com.trs.dev4.jdk16.thread.DaemonThreadFactory;
import com.trs.dev4.jdk16.thread.IThreadWorkload;
import com.trs.dev4.jdk16.utils.AssertUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.ObjectUtil;

/**
 * {@link IConfigurationManager}的实现.
 * 
 * 通过定时程序自动读取配置项，实现配置项的本地缓存。
 * 
 * 管理{@link IConfigurable}的实现类，当属性发生变更时通过此接口的refreshConfigs()方法通知关注的类；
 * 
 * 管理{@link IConfigurationOptionReader}的实现类，当需要动态获取配置项的选项列表时，调用此接口的read方法获取选项列表；
 * 
 * 由{@link ConfigurationManagerTest}提供单元测试；
 * 
 * @author TRS信息技术有限公司
 */
@ManagedResource(objectName = "dev4:name=configurationManager")
public class ConfigurationManager extends BaseManager<Configuration> implements IConfigurationManager, IModuleLifecycle {

	/**
	 * JSTL的<c:foreach>等标签不支持Map的键中含<code>.</code>等特殊字符，故采用<code>_</code>.
	 * 
	 * @since liushen @ Aug 3, 2010
	 */
	public static final String SPEARATOR_FOR_MVC = "_";

	/**
	 *
	 */
	private final static Logger LOG = Logger.getLogger(ConfigurationManager.class);
	/**
	 * 后台守护进程，负责定时加载配置选项
	 */
	private DaemonThreadControllor reloadThread;

	/**
	 * 存储配置的索引(但只能存放和节点无关的配置项)；key为prefix，value为该模块的所有配置项(子Map)。
	 */
	private Map<String, Map<String, Configuration>> configurationIndexes = new HashMap<String, Map<String, Configuration>>();

	/**
	 * 配置器，主键是IConfigurable.getPrefix()
	 */
	private Map<String, IConfigurable> configurables = new HashMap<String, IConfigurable>();
	/**
	 * 配置项的选项阅读器，主键是
	 * {@link IConfigurationOptionReader#getConfigurationOptionReaderName()}，通过
	 * {@link IConfigurationManager#registerConfigurationOptionReader(IConfigurationOptionReader)}
	 * 添加
	 */
	private Map<String, IConfigurationOptionReader> optionReaders = new ConcurrentHashMap<String, IConfigurationOptionReader>();

	/**
	 * 本节点的标识，传入。
	 */
	private String nodeKey;

	/**
	 * @return the {@link #configurables}
	 * @since 2012.01.30,改成不可变的Map，防止通过此接口对缓存的内容做修改;
	 */
	@SuppressWarnings("unchecked")
	public Map<String, IConfigurable> getConfigurables() {
		return UnmodifiableMap.decorate(configurables);
	}

	/**
	 * @param configurables
	 *            the {@link #configurables} to set
	 */
	public void setConfigurables(Map<String, IConfigurable> configurables) {
		this.configurables = configurables;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#start(java.lang.String)
	 */
	@Override
	public void start(final String nodeKey) {
		this.nodeKey = nodeKey;
		loadConfigs(nodeKey);
		// 启动伺服进程
		DaemonThreadFactory.getInstance().startThread("ConfigurationManager-reloadThread", 300, new IThreadWorkload() {
			@Override
			public void onExecute() {
				loadConfigs(nodeKey);
			}
		});
	}

	/**
	 * 加载所有配置项
	 * 
	 */
	protected void loadConfigs() {
		loadConfigs(nodeKey);
	}

	private void loadConfigs(String nodeKey) {
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		sf.addEqCondition("node", Configuration.NODE_ALL);
		List<Configuration> configsForAllNode = getAccessor().listObjects(sf);

		boolean nodeSpecified = StringHelper.isNotEmpty(nodeKey);
		List<Configuration> configsJustForThisNode = Collections.emptyList();
		if (nodeSpecified) {
			SearchFilter sfJustForThisNode = SearchFilter.getNoPagedFilter();
			sfJustForThisNode.addEqCondition("node", nodeKey);
			configsJustForThisNode = getAccessor().listObjects(sfJustForThisNode);
		}
		synchronized (this) {
			configurationIndexes.clear();
			for (Configuration configuration : configsForAllNode) {
				loadConfiguration(configuration);
			}
			if (nodeSpecified) {
				for (Configuration configuration : configsJustForThisNode) {
					loadConfiguration(configuration);
				}
			}
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("Loaded (" + configsForAllNode.size() + ") all-Node configurations and " + configsJustForThisNode.size() + ") this node(" + nodeKey
					+ ") configurations.");
		}
	}

	/**
	 * 加载配置信息，并通知所属模块应用其所有配置项的新值。
	 * 
	 * @see #loadConfiguration(Configuration, boolean)
	 */
	private void loadConfiguration(Configuration configuration) {
		loadConfiguration(configuration, true);
	}

	/**
	 * 加载配置信息。
	 * 
	 * @param configuration
	 *            配置对象
	 * @param notify
	 *            是否通知其所属的configurable刷新各配置项的值
	 */
	private void loadConfiguration(Configuration configuration, boolean notify) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Name=" + configuration.getName() + ",Value=" + configuration.getValue());
		}
		//

		Map<String, Configuration> moduleConfigurations = configurationIndexes.get(configuration.getPrefix());
		if (moduleConfigurations == null) {
			moduleConfigurations = new Hashtable<String, Configuration>();
			configurationIndexes.put(configuration.getPrefix(), moduleConfigurations);
		}
		moduleConfigurations.put(configuration.getName(), configuration);
		// 通知IConfigurable刷新，如果最后更新时间不相同的话
		if (false == notify) {
			return;
		}
		Configuration oldConfiguration = moduleConfigurations.get(configuration.getName());
		if (oldConfiguration != null && oldConfiguration.getLastModifiedTime() != configuration.getLastModifiedTime()) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Configuration(" + configuration.getName() + ")'s value(" + oldConfiguration.getValue() + ") updated to (" + configuration.getValue()
						+ ").");
			}
			IConfigurable configurable = this.configurables.get(configuration.getPrefix());
			if (configurable != null) {
				configurable.refreshConfigs();
				if (LOG.isDebugEnabled()) {
					LOG.debug("Notified Configurable(" + configurable + ") to refreshConfigs by (Name:" + configuration.getName() + "+,Value:"
							+ configuration.getValue() + ").");
				}
			} else {
				LOG.error("Can't found configurable with Prefix(" + configuration.getPrefix() + ")");
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#stop()
	 */
	@Override
	public void stop() {
		configurationIndexes.clear();
		// 停止自动加载线程
		if (reloadThread != null) {
			reloadThread.stop(1000);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#update(com.trs.dev4.jdk16.model.IEntity)
	 * @since liushen @ Apr 20, 2010
	 */
	@Override
	public void update(Configuration configuration) {
		update(configuration, true);
	}

	/**
	 * @param configuration
	 * @param notify
	 *            是否通知模块更新
	 * @since liushen @ Jan 18, 2011
	 */
	private void update(Configuration configuration, boolean notify) {
		AssertUtil.notNull(configuration, "configuration is null");
		if (configuration.isForbidModify()) {
			throw new BussinessException(configuration + " update forbid.");
		}
		// 保存配置
		configuration.setLastModifiedTime(System.currentTimeMillis());
		getAccessor().update(configuration);
		// 重新加载所有的配置信息
		loadConfiguration(configuration, notify);
		// liushen @ Jan 18, 2011: 抽取notify参数满足MAS分组更新以及初始化的需要
		if (notify) {
			IConfigurable configurable = this.configurables.get(configuration.getPrefix());
			if (configurable != null) {
				LOG.info("notify Configurable(" + configurable + ") to refreshConfigs.");
				configurable.refreshConfigs();
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationAsInt(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String)
	 */
	@Override
	public int getConfigurationAsInt(IConfigurable configurable, String name) {
		String strValue = getConfiguration(configurable, name);
		return NumberUtil.parseInt(strValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationAsLong(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String)
	 */
	@Override
	public long getConfigurationAsLong(IConfigurable configurable, String name) {
		String strValue = getConfiguration(configurable, name);
		return NumberUtil.parseLong(strValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addSetupKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 * @since liushen @ Aug 27, 2010
	 */
	@Override
	public void addSetupKey(IConfigurable configurable, String name, String cname, String comment) {
		addSetupKey(configurable, name, cname, comment, null);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addSetupKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String)
	 * @since liushen @ Aug 26, 2010
	 */
	@Override
	public void addSetupKey(IConfigurable configurable, String name, String cname, String comment, String value) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration != null) {
			updateDisplayName(configuration, cname, comment);
			return;
		}
		configuration = buildConfiguration(configurable, name, cname);
		configuration.setNeedSetup(true);
		configuration.setComment(comment);
		if (value != null) {
			configuration.setValue(value);
		}
		insert(configuration);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addSetupKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String)
	 * @since liushen @ Jul 12, 2012
	 */
	@Override
	public void addSetupKey(IConfigurable configurable, String name, String cname, String comment, String nodeKey, String value) {
		// TODO: liushen@Jul 12, 2012:
		Configuration configuration = getConfigurationJustForTheNodeOnly(configurable, cname, nodeKey);
		if (configuration != null) {
			updateDisplayName(configuration, cname, comment);
			return;
		}
		configuration = buildConfiguration(configurable, name, cname);
		configuration.setNeedSetup(true);
		configuration.setComment(comment);
		configuration.setNode(nodeKey);
		if (value != null) {
			configuration.setValue(value);
		}
		insert(configuration);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addConfigKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String)
	 * @since liushen @ Aug 27, 2010
	 */
	@Override
	public void addConfigKey(IConfigurable configurable, String name, String cname, String comment, String defValue) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration != null) {
			updateDisplayName(configuration, cname, comment);
			return;
		}
		configuration = buildConfiguration(configurable, name, cname);
		configuration.setComment(comment);
		configuration.setDefaultValue(defValue);
		if (defValue != null) {
			configuration.setValue(defValue);
		}
		insert(configuration);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addConfigKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String)
	 * @creator liushen @ Feb 15, 2010
	 * @deprecated liushen@May 30, 2010: 见接口中的说明
	 */
	@Deprecated
	@Override
	public void addConfigKey(IConfigurable configurable, String name, String cname) {
		addConfigKey(configurable, name, cname, null);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addConfigKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 * @since liushen @ May 30, 2010
	 * @deprecated liushen@Aug 27, 2010: 见接口中的说明
	 */
	@Deprecated
	@Override
	public void addConfigKey(IConfigurable configurable, String name, String cname, String defValue) {
		addConfigKey(configurable, name, cname, null, defValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#deleteKey(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String)
	 * @since liushen @ Jul 9, 2010
	 */
	@Override
	public void deleteKey(IConfigurable configurable, String name) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration == null) {
			return;
		}
		String prefix = configuration.getPrefix();
		getAccessor().delete(configuration);
		LOG.info("delete key: " + prefix + ", " + name + ".");

		loadConfigs();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateConfigValue(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.Object)
	 * @creator liushen @ Feb 15, 2010
	 */
	@Override
	public void updateConfigValue(IConfigurable configurable, String name, Object value) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration != null) {
			configuration.setValueFromObject(value);
			getAccessor().update(configuration);
		} else {
			configuration = buildConfiguration(configurable, name, value);
			getAccessor().insert(configuration);
		}
		// 重新加载所有的配置信息
		loadConfiguration(configuration);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateConfigMetadata(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String, java.lang.Boolean,
	 *      java.lang.Boolean)
	 * @since liushen @ Nov 2, 2010
	 */
	@Override
	public void updateConfigMetadata(IConfigurable configurable, String name, Boolean forbidModify, Boolean needEncrypt) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration == null) {
			return;
		}
		if (forbidModify != null) {
			configuration.setForbidModify(forbidModify);
		}
		if (needEncrypt != null) {
			configuration.setNeedEncrypt(needEncrypt);
		}
		//
		getAccessor().update(configuration);
		loadConfiguration(configuration, false);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateConfigValue(com.trs.dev4.jdk16.model.IConfigurable,
	 *      com.trs.dev4.jdk16.model.Configuration)
	 * @creator liushen @ Feb 16, 2010
	 */
	@Override
	public void updateConfigValue(IConfigurable configurable, Configuration configWithNewValue) {
		if (configWithNewValue == null) {
			return;
		}

		updateConfigValue(configurable, configWithNewValue.getName(), configWithNewValue.getValue());
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateModuleConfigs(java.lang.String,
	 *      java.util.List)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public void updateModuleConfigs(String prefix, List<Configuration> moduleConfigs) {
		Map<String, Configuration> map = convertToMap(moduleConfigs, prefix);
		updateModuleConfigs(prefix, map);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateModuleConfigs(java.util.Map)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public void updateModuleConfigs(String prefix, Map<String, Configuration> moduleConfigs) {
		IConfigurable configurable = lookupConfigurable(prefix);
		if (configurable == null) {
			throw new ConfigException("No such configurable! prefix: [" + prefix + "]");
		}

		ValidationErrors errors = configurable.validateConfigs(moduleConfigs);
		AssertUtil.notNull(errors, "ValidationErrors should not null!");
		if (errors.hasErrors()) {
			throw new ValidateAssertionException("校验未通过，不能保存[" + configurable + "]的配置: " + errors);
		}

		Collection<Configuration> configs = moduleConfigs.values();
		for (Configuration configuration : configs) {
			// 跳过不允许修改的配置项
			if (configuration.isForbidModify()) {
				continue;
			}
			update(configuration, false);
		}
		LOG.info("notify Configurable(" + configurable + ") to refreshConfigs.");
		configurable.refreshConfigs();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#updateModuleConfigs(com.trs.dev4.jdk16.model.GroupedConfiguration)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public void updateModuleConfigs(GroupedConfiguration groupedConfiguration) {
		updateModuleConfigs(groupedConfiguration.getPrefix(), groupedConfiguration.getListConfigs());
	}

	/**
	 * @param configuration
	 * @since xuyan @ 2011-6-20
	 */
	private void insert(Configuration configuration) {
		getAccessor().insert(configuration);
		loadConfiguration(configuration);
	}

	/**
	 * 查找注册的Configurable
	 * 
	 * @param prefix
	 * @return
	 */
	private IConfigurable lookupConfigurable(String prefix) {
		if (prefix == null) {
			return null;
		}
		return configurables.get(prefix);
	}

	/**
	 * 
	 * @param configuration
	 * @param displayName
	 * @param comment
	 */
	private void updateDisplayName(Configuration configuration, String displayName, String comment) {
		if (ObjectUtil.equals(configuration.getCname(), displayName) && ObjectUtil.equals(configuration.getComment(), comment)) {
			return;
		}
		configuration.setCname(displayName);
		configuration.setComment(comment);
		getAccessor().update(configuration);
	}

	/**
	 * 
	 * @param configurable
	 * @param name
	 * @param cname
	 * @return
	 */
	private Configuration buildConfiguration(IConfigurable configurable, String name, String cname) {
		Configuration configuration = new Configuration();
		configuration.setPrefix(configurable.getPrefix());
		configuration.setName(name);
		if (cname != null) {
			configuration.setCname(cname);
		}
		return configuration;
	}

	private Configuration buildConfiguration(IConfigurable configurable, String name, Object value) {
		Configuration configuration = buildConfiguration(configurable, name, null);
		configuration.setValueFromObject(value);
		return configuration;
	}

	/**
	 * 
	 * @param configurable
	 * @param name
	 * @return
	 */
	private Configuration _getConfiguration(IConfigurable configurable, String name) {
		registerConfigurableIfNotyet(configurable);
		String prefix = configurable.getPrefix();
		Map<String, Configuration> moduleConfigurations = configurationIndexes.get(prefix);
		if (moduleConfigurations == null) {
			return null;
		}
		return moduleConfigurations.get(name);
	}

	private void registerConfigurableIfNotyet(IConfigurable configurable) {
		if (null == this.lookupConfigurable(configurable.getPrefix())) {// 如果没有找到则自动注册
			registerConfigurable(configurable);
		}
	}

	/**
	 * 优先返回和节点相符的配置对象；如果未提供节点信息或者找不到该节点的配置对象，再返回节点无关的配置对象。
	 * 
	 * @param configurable
	 * @param name
	 * @param nodeKey
	 * @return
	 * @since liushen @ Jul 12, 2012
	 */
	Configuration smartGetConfigurationForNode(IConfigurable configurable, String name, String nodeKey) {
		registerConfigurableIfNotyet(configurable);
		if (StringHelper.isEmpty(nodeKey)) {
			return _getConfiguration(configurable, name);
		}
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("prefix", configurable.getPrefix());
		sf.addEqCondition("name", name);
		sf.addEqCondition("node", nodeKey);
		Configuration configuration = findFirst(sf);
		if (configuration != null) {
			return configuration;
		}
		return _getConfiguration(configurable, name);
	}

	/**
	 * 只返回和节点相符的配置对象；如果未提供节点信息或者找不到该节点的配置对象，则返回<code>null</code>。
	 * 
	 * @param configurable
	 * @param name
	 * @param nodeKey
	 * @return
	 * @since liushen @ Jul 12, 2012
	 */
	Configuration getConfigurationJustForTheNodeOnly(IConfigurable configurable, String name, String nodeKey) {
		registerConfigurableIfNotyet(configurable);
		if (StringHelper.isEmpty(nodeKey)) {
			return null;
		}
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("prefix", configurable.getPrefix());
		sf.addEqCondition("name", name);
		sf.addEqCondition("node", nodeKey);
		return findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfiguration(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String)
	 */
	@Override
	public String getConfiguration(IConfigurable configurable, String name) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration == null) {
			return null;
		}
		return configuration.getValue();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#existsOrConfigured(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String)
	 * @since liushen @ May 30, 2010
	 */
	@Override
	public boolean existsOrConfigured(IConfigurable configurable, String name) {
		Configuration configuration = _getConfiguration(configurable, name);
		if (configuration == null) { // 如果从缓存中找不到的话，一定要重新查一下数据库
			SearchFilter sf = SearchFilter.getNoPagedFilter();
			sf.addEqCondition("PREFIX", configurable.getPrefix());
			sf.addEqCondition("NAME", name);
			return super.findFirst(sf) != null;
		}
		return true;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#list(com.trs.dev4.jdk16.model.IConfigurable)
	 * @creator liushen @ Feb 15, 2010
	 */
	@Override
	public List<Configuration> list(IConfigurable configurable) {
		String prefix = configurable.getPrefix();
		return listModuleConfigs(prefix);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#extractModuleConfig(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.util.List)
	 * @creator liushen @ Feb 16, 2010
	 */
	@Override
	public Map<String, Configuration> extractModuleConfig(IConfigurable configurable, List<Configuration> configs) {
		if (configs == null || configurable == null) {
			return null;
		}

		String prefix = configurable.getPrefix();
		List<Configuration> moduleConfigs = new ArrayList<Configuration>();
		for (Configuration configuration : configs) {
			if (ObjectUtil.equals(configuration.getPrefix(), prefix)) {
				moduleConfigs.add(configuration);
			}
		}
		return convertToMap(moduleConfigs, prefix);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#addPrefixToModuleConfig(java.lang.String,
	 *      java.util.Map)
	 * @since liushen @ Aug 11, 2010
	 */
	@Override
	public Map<String, Configuration> addPrefixToModuleConfig(String prefix, Map<String, Configuration> cfgMap) {
		AssertUtil.notNull(prefix, "prefix is null.");
		AssertUtil.notNull(cfgMap, "cfgMap is null.");

		Map<String, Configuration> resultMap = new HashMap<String, Configuration>();
		for (String key : cfgMap.keySet()) {
			Configuration configuration = cfgMap.get(key);
			resultMap.put(prefix + SPEARATOR_FOR_MVC + key, configuration);
		}
		return resultMap;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#extractModuleConfig(java.lang.String,
	 *      java.util.Map)
	 * @since liushen @ Aug 11, 2010
	 */
	@Override
	public Map<String, Configuration> extractModuleConfig(String prefix, Map<String, Configuration> cfgMap) {
		AssertUtil.notNull(prefix, "prefix is null.");
		AssertUtil.notNull(cfgMap, "cfgMap is null.");

		Map<String, Configuration> resultMap = new HashMap<String, Configuration>();
		for (String keyFqn : cfgMap.keySet()) {
			if (keyFqn.startsWith(prefix + SPEARATOR_FOR_MVC)) {
				Configuration configuration = cfgMap.get(keyFqn);
				resultMap.put(configuration.getName(), configuration);
			}
		}
		return resultMap;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#extractModuleConfig(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.util.Map)
	 * @since liushen @ Aug 4, 2010
	 */
	@Override
	public Map<String, Configuration> extractModuleConfig(IConfigurable configurable, Map<String, Configuration> cfgMap) {
		AssertUtil.notNull(configurable, "configurable is null.");
		String prefix = configurable.getPrefix();
		AssertUtil.notNull(prefix, "the prefix of " + configurable.getClass().getName() + " is null.");
		return extractModuleConfig(prefix, cfgMap);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#toMapWithPrefixs(java.util.List)
	 * @since liushen @ Aug 3, 2010
	 */
	@Override
	public Map<String, Configuration> toMapWithPrefixs(List<Configuration> configs) {
		Map<String, Configuration> resultMap = new HashMap<String, Configuration>();
		for (Configuration configuration : configs) {
			resultMap.put(configuration.getPrefix() + SPEARATOR_FOR_MVC + configuration.getName(), configuration);
		}
		return resultMap;
	}

	/**
	 * @param configs
	 * @param prefix
	 * @return
	 * @creator liushen @ Feb 19, 2010
	 */
	private Map<String, Configuration> convertToMap(List<Configuration> configs, String prefix) {
		if (CollectionUtil.isEmpty(configs)) {
			return null;
		}
		GroupedConfiguration groupedCfg = new GroupedConfiguration(configs);
		return groupedCfg.getMapConfigs();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listModuleConfigs(java.lang.String)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public List<Configuration> listModuleConfigs(String prefix) {
		Map<String, Configuration> map = getModuleConfigs(prefix);
		if (map == null) {
			throw new NullPointerException("the prefix: [" + prefix + "]'s config map is null, maybe it's wrong typed.");
		}
		return new ArrayList<Configuration>(map.values());
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getModuleConfigs(java.lang.String)
	 * @creator liushen @ Feb 18, 2010
	 */
	@Override
	public Map<String, Configuration> getModuleConfigs(String prefix) {
		return configurationIndexes.get(prefix);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getValueFromModuleConfigMap(java.util.Map)
	 * @since liushen @ Aug 4, 2010
	 */
	@Override
	public String getValueFromModuleConfigMap(Map<String, Configuration> configs, String nameWithoutPrefix) {
		Configuration configuration = configs.get(nameWithoutPrefix);
		if (configuration == null) {
			return null;
		}
		return configuration.getValue();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#containsModuleConfigName(java.util.Map,
	 *      java.lang.String)
	 * @since liushen @ Aug 4, 2010
	 */
	@Override
	public boolean containsModuleConfigName(Map<String, Configuration> configs, String nameWithoutPrefix) {
		Configuration configuration = configs.get(nameWithoutPrefix);
		return configuration != null;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listKnownConfigurable()
	 * @creator liushen @ Feb 15, 2010
	 */
	@Override
	public List<IConfigurable> listKnownConfigurable() {
		return Arrays.asList(configurables.values().toArray(new IConfigurable[0]));
	}

	/**
	 * 注册
	 * 
	 * @param configurable
	 */
	@Override
	public void registerConfigurable(IConfigurable configurable) {
		configurables.put(configurable.getPrefix(), configurable);
		LOG.info("IConfigurable (" + configurable + ") registered to configurationManager(" + this + ") with prefix(" + configurable.getPrefix() + "). ");
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listNeedSetup()
	 * @creator liushen @ Feb 16, 2010
	 */
	@Override
	public List<Configuration> listNeedSetup() {
		SearchFilter sf = buildBaseSetupCondition();
		return getAccessor().listObjects(sf);
	}

	/**
	 * 
	 * @return
	 */
	private SearchFilter buildBaseSetupCondition() {
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		sf.addEqCondition("needSetup", true);
		return sf;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listExistedConfig()
	 * @since liushen @ Aug 15, 2010
	 */
	@Override
	public List<Configuration> listExistedConfig() {
		return getAccessor().listObjects();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listExistedSetupConfig()
	 * @creator liushen @ Feb 16, 2010
	 */
	@Override
	public List<Configuration> listExistedSetupConfig() {
		SearchFilter sf = buildBaseSetupCondition();
		sf.addNotNullCondition("value");
		return getAccessor().listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#listMissingSetupConfig()
	 * @creator liushen @ Feb 16, 2010
	 */
	@Override
	public List<Configuration> listMissingSetupConfig() {
		SearchFilter sf = buildBaseSetupCondition();
		sf.addIsNullCondition("value");
		// sf.addEqCondition("value", "");
		return getAccessor().listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#find(int)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public Configuration find(int id) {
		return getAccessor().getObject(id);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @creator liushen @ Feb 19, 2010
	 */
	@Override
	public PagedList<Configuration> pagedObjects(SearchFilter sf) {
		return getAccessor().pagedObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurable(java.lang.String)
	 * @since Administrator @ Oct 22, 2010
	 */
	@Override
	public IConfigurable getConfigurable(String prefix) {
		if (StringHelper.isEmpty(prefix))
			return null;
		return this.configurables.get(prefix);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#update(java.util.List)
	 */
	@Override
	public void update(List<Configuration> configurations) {
		for (Configuration configuration : configurations) {
			String prefix = configuration.getPrefix();
			IConfigurable configurable = this.getConfigurable(prefix);
			if (configurable != null) {
				this.updateConfigValue(configurable, configuration);
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#markConfigNode(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String)
	 * @since liushen @ Jul 12, 2012
	 */
	@Override
	public void markConfigNode(IConfigurable configurable, String name, String nodeKey) {
		Configuration configuration = smartGetConfigurationForNode(configurable, name, nodeKey);
		if (configuration == null) {
			LOG.warn("mark node to [" + nodeKey + "], but not found the configuration, prefix=" + configurable.getPrefix() + ", name=" + name);
			return;
		}
		configuration.setNode(nodeKey);
		update(configuration);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationForNode(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String)
	 * @since liushen @ Jul 12, 2012
	 */
	@Override
	public String getConfigurationForNode(IConfigurable configurable, String name, String nodeKey) {
		Configuration configuration = smartGetConfigurationForNode(configurable, name, nodeKey);
		if (configuration == null) {
			return null;
		}
		return configuration.getValue();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfiguration(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.Object)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public String getConfiguration(IConfigurable configurable, String name, Object defValue) {
		String configurationValue = this.getConfiguration(configurable, name);
		return configurationValue == null ? defValue.toString() : configurationValue;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfiguration(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, int)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public int getConfigurationAsInt(IConfigurable configurable, String name, int defValue) {
		String configurationValue = this.getConfiguration(configurable, name);
		return configurationValue == null ? defValue : NumberUtil.parseInt(configurationValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationAsLong(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, long)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public long getConfigurationAsLong(IConfigurable configurable, String name, long defValue) {
		String configurationValue = this.getConfiguration(configurable, name);
		return configurationValue == null ? defValue : NumberUtil.parseLong(configurationValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public String getModuleName() {
		return "ConfigurationManager";
	}

	/**
	 * 供JMX使用，获取配置名
	 * 
	 * @return
	 * @since fangxiang @ Jan 23, 2011
	 */
	@ManagedOperation
	public List<String> listConfigurableNames() {
		List<String> configurableNames = new ArrayList<String>();
		for (IConfigurable configurable : configurables.values()) {
			configurableNames.add(configurable.getClass().getName());
		}
		return configurableNames;
	}

	/**
	 * 供JMX使用，列出所有的配置值
	 * 
	 * @return
	 * @since fangxiang @ Jan 23, 2011
	 */
	@ManagedOperation
	public Map<String, String> listConfigurations() {
		Map<String, String> configurations = new HashMap<String, String>();
		for (String configurablePrefix : configurationIndexes.keySet()) {
			Map<String, Configuration> moduleConfiguations = configurationIndexes.get(configurablePrefix);
			if (moduleConfiguations == null) {
				continue;
			}
			for (String configurationName : moduleConfiguations.keySet()) {
				configurations.put(configurablePrefix + "_" + configurationName, moduleConfiguations.get(configurationName).getValue());
			}
		}
		return configurations;
	}

	/**
	 * 供JMX使用，根据前缀获取配置值
	 * 
	 * @return
	 * @since fangxiang @ Jan 23, 2011
	 */
	@ManagedOperation
	public Map<String, String> listConfigurations(String prefix) {
		Map<String, String> configurations = new HashMap<String, String>();
		Map<String, Configuration> moduleConfiguations = configurationIndexes.get(prefix);
		if (moduleConfiguations == null) {
			return configurations;
		}
		for (String configurationName : moduleConfiguations.keySet()) {
			configurations.put(prefix + "_" + configurationName, moduleConfiguations.get(configurationName).getValue());
		}
		return configurations;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public void restart() {
		this.loadConfigs();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationAsBoolean(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, boolean)
	 * @since fangxiang @ Jan 29, 2011
	 */
	@Override
	public boolean getConfigurationAsBoolean(IConfigurable configurable, String name, boolean defValue) {
		String strValue = getConfiguration(configurable, name);
		return StringHelper.isEmpty(strValue) ? defValue : Boolean.valueOf(strValue);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#registerConfigurationOptionReader(com.trs.dev4.jdk16.model.IConfigurationOptionReader)
	 * @since TRS @ Jan 30, 2012
	 */
	@Override
	public void registerConfigurationOptionReader(IConfigurationOptionReader bean) {
		if (bean == null) {
			LOG.error("Can't register IConfigurationOptionReader with null.", new NullPointerException("configurationOptionReader.register.is-null"));
			return;
		}
		if (!StringHelper.isEmpty(bean.getConfigurationOptionReaderName())) {
			IConfigurationOptionReader oldOptionReader = optionReaders.put(bean.getConfigurationOptionReaderName(), bean);
			if (oldOptionReader != null) {
				LOG.info("Replace IConfigurationOptionReader(" + bean.getConfigurationOptionReaderName() + ") with bean(" + bean + ") by old("
						+ oldOptionReader + ").");
			}
		} else {
			LOG.error("Can't register IConfigurationOptionReader with bean(" + bean + "),because of OptionReaderName is null.", new NullPointerException(
					"configurationOptionReader.name.is-null"));
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#readOptions(com.trs.dev4.jdk16.model.Configuration,
	 *      com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since TRS @ Jan 30, 2012
	 */
	@Override
	public List<ConfigurationOption> readOptions(Configuration configuration, SearchFilter sf) {
		List<ConfigurationOption> configurationOptions = new ArrayList<ConfigurationOption>();
		if (configuration == null)
			return configurationOptions;
		// 2012.01.31:同时支持options和optionReader，如果没有设置optionReader则直接尝试从options里面分解获取；
		if (StringHelper.isEmpty(configuration.getOptionReader())) {
			if (StringHelper.isEmpty(configuration.getOptions())) {
				return configurationOptions;
			}
			String[] splittedOptions = StringHelper.split(";", configuration.getOptions());
			for (String splittedOption : splittedOptions) {
				configurationOptions.add(new ConfigurationOption(splittedOption));
			}
			return configurationOptions;
		}
		// 获取阅读器并从里面读取出配置项的选项列表
		IConfigurationOptionReader optionReader = optionReaders.get(configuration.getOptionReader());
		if (optionReader != null) {
			configurationOptions = optionReader.read((sf == null) ? sf : SearchFilter.getDefault());
		} else {
			LOG.error("Can't found IConfigurationOptionReader with configuration(" + configuration + ")", new NullPointerException(
					"configurationOptionReader.get.is-null"));
		}
		return configurationOptions;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getConfigurationOptionReader(java.lang.String)
	 * @since TRS @ Jan 30, 2012
	 */
	@Override
	public IConfigurationOptionReader getConfigurationOptionReader(String optionReaderName) {
		if (StringHelper.isEmpty(optionReaderName)) {
			LOG.error("Can't get IConfigurationOptionReader with name(" + optionReaderName + ")", new NullPointerException(
					"configurationOptionReader.get.is-null"));
			return null;
		}
		// 获取阅读器并从里面读取出配置项的选项列表
		return optionReaders.get(optionReaderName);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#getByParameterName(java.lang.String)
	 * @since TRS @ Jan 31, 2012
	 */
	@Override
	public Configuration getByParameterName(String paramName) {
		return super.findFirst("name", paramName);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurationManager#saveOrUpdate(com.trs.dev4.jdk16.model.IConfigurable,
	 *      java.lang.String, java.lang.String)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public String saveOrUpdate(IConfigurable configurable, String name, String newValue) {
		if (configurable == null || StringHelper.isEmpty(name) || newValue == null) {
			LOG.info("Can't update configuration value with configurable(" + configurable + "),name(" + name + "),value(" + newValue + ").");
			return null;
		}
		//
		Configuration configuration = this._getConfiguration(configurable, name);
		if (configuration == null) {
			configuration = this.buildConfiguration(configurable, name, name + ".label_cn");
			configuration.setValue(newValue);
			configuration.setComment(name + ".comment");
			this.saveOrUpdate(configuration);
			this.loadConfiguration(configuration);
		} else {
			String oldValue = configuration.getValue();
			configuration.setValue(newValue);
			this.update(configuration);
			this.loadConfiguration(configuration);
			return oldValue;
		}
		return null;
	}

	/**
	 * @return the {@link #nodeKey}
	 */
	public String getNodeKey() {
		return nodeKey;
	}
}
