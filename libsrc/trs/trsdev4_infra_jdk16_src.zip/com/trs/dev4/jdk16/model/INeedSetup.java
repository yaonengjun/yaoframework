/*
 * Created: liushen@Aug 26, 2010 4:44:16 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.Map;

import com.trs.dev4.jdk16.model.setup.INeedSetupV2;

/**
 * 对需要安装初始化的模块的抽象.<br>
 * 
 * @deprecated liushen@Jul 16, 2012: 用 {@link INeedSetupV2} 代替。
 */
@Deprecated
public interface INeedSetup extends IConfigurable {

	/**
	 * 该模块是否需要初始化.
	 * 
	 * @return 需要初始化返回<code>true</code>；否则返回<code>false</code>.
	 * @since liushen @ Aug 18, 2010
	 */
	boolean needSetup();

	/**
	 * 声明所有需要初始化的配置项.
	 * 
	 * @param installHomeDir
	 *            系统安装目录；某些模块的智能初始化准备需要该信息. 当系统不是通过安装程序安装时，该信息为<code>null</code>
	 *            .
	 * @creator liushen @ Feb 17, 2010
	 */
	void prepareSetupKeys(String installHomeDir);

	/**
	 * 根据所给配置进行初始化，用于系统安装后首次启动的初始化过程以及补充初始化过程中.
	 * 
	 * @param configs
	 *            该模块的配置项构成的Map: 键为名称(注意：不含前缀)，值为配置对象本身.
	 * @creator liushen @ Feb 17, 2010
	 */
	void setup(Map<String, Configuration> configs);

}
