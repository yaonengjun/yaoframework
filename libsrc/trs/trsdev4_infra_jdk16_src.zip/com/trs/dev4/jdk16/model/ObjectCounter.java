/*
 * Created: fangxiang@Jan 9, 2011 7:35:25 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 统计使用对象
 */
public class ObjectCounter {
	/**
	 * 从数据库获取的对象数目
	 */
	private long objectsGot = 0;
	/**
	 * 从缓存中获取的对象数目
	 */
	private long objectsCached = 0;
	/**
	 * 检索到的对象数目
	 */
	private long objectsCachedWithSearched = 0;
	/**
	 * 检索获得的对象数目
	 */
	private long objectsSearched = 0;
	/**
	 * 对象的查询数目
	 */
	private long searchTimes = 0;
	/**
	 * 保存的对象数目
	 */
	private long objectsSaved = 0;
	/**
	 * 删除掉的对象数目
	 */
	private long objectsDeleted = 0;
	/**
	 * 
	 */
	private String objectClass;

	/**
	 * 
	 * @param objectClass
	 */
	public ObjectCounter(String objectClass) {
		this.objectClass = objectClass;
	}
	/**
	 * 
	 * @param count
	 */
	public void countDelete(int count) {
		this.objectsDeleted += count;
	}

	/**
	 * 
	 * 
	 */
	public void countDelete() {
		this.countDelete(1);
	}

	/**
	 * 
	 * 
	 */
	public void countGet() {
		this.objectsGot += 1;
	}

	/**
	 * 
	 * 
	 */
	public void countCache() {
		this.objectsCached += 1;
	}

	/**
	 * 
	 * @param searchedCount
	 */
	public void countSearch(int searchedCount, int cachedCount) {
		this.searchTimes += 1;
		this.objectsSearched += searchedCount;
		this.objectsCachedWithSearched += cachedCount;
	}

	/**
	 * 
	 * 
	 */
	public void countSave() {
		this.objectsSaved += 1;
	}

	/**
	 * 
	 * @param savedCount
	 * @return
	 */
	public void countSave(int savedCount) {
		this.objectsSaved += savedCount;
	}

	/**
	 * 
	 * @param cachedObject
	 */
	public void countCache(int cachedObject) {
		this.objectsCached += cachedObject;
	}

	/**
	 * @return the {@link #objectsGot}
	 */
	public long getObjectsGot() {
		return objectsGot;
	}

	/**
	 * @return the {@link #objectsCached}
	 */
	public long getObjectsCached() {
		return objectsCached;
	}

	/**
	 * @return the {@link #objectsCachedWithSearched}
	 */
	public long getObjectsCachedWithSearched() {
		return objectsCachedWithSearched;
	}

	/**
	 * @return the {@link #objectsSearched}
	 */
	public long getObjectsSearched() {
		return objectsSearched;
	}

	/**
	 * @return the {@link #searchTimes}
	 */
	public long getSearchTimes() {
		return searchTimes;
	}

	/**
	 * @return the {@link #objectsSaved}
	 */
	public long getObjectsSaved() {
		return objectsSaved;
	}

	/**
	 * @return the {@link #objectsDeleted}
	 */
	public long getObjectsDeleted() {
		return objectsDeleted;
	}

	/**
	 * @return the {@link #objectClass}
	 */
	public String getObjectClass() {
		return objectClass;
	}
}
