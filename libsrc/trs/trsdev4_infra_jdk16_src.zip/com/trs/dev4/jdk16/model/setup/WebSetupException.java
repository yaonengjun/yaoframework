/*
 * Created: liushen@Jul 16, 2012 11:57:06 AM
 */
package com.trs.dev4.jdk16.model.setup;

import com.trs.dev4.jdk16.exception.RootException;

/**
 * 指示需要重新进行安装初始化. <br>
 * 
 */
public class WebSetupException extends RootException {

	/**
	 * @since liushen @ Jul 16, 2012
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param msg
	 * @param cause
	 */
	public WebSetupException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public WebSetupException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public WebSetupException(Throwable cause) {
		super(cause);
	}

}
