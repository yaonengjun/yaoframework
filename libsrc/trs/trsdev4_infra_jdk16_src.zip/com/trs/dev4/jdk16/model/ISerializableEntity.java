/*
 * Created: liushen@Oct 24, 2009 1:04:12 PM
 */
package com.trs.dev4.jdk16.model;

import java.io.Serializable;

/**
 * 媒资领域对象的标示性接口.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface ISerializableEntity extends Serializable {

	// Serializable getId(); 目前已有的实现结构，无法返回Serializable，否则编译通不过
	/**
	 * 
	 * @return
	 * @since liushen @ Oct 24, 2009
	 */
	int getId();
}
