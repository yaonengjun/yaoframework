/*
 * Created: liushen@May 7, 2010 5:00:26 PM
 */
package com.trs.dev4.jdk16.model.example;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * 归档对象示例，主表的副本, ID需要指定. <br>
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "ARCHIVEDFOO")
@GenericGenerator(name = "idStrategy", strategy = "assigned")
public class ArchivedFoo extends Foo {

	// /**
	// * 数据表ID，无业务含义.
	// */
	// @SuppressWarnings("unused")
	// @GeneratedValue(generator = "idStrategy")
	// @Id
	// @Column(name = "`ID`")
	// private int id;

}
