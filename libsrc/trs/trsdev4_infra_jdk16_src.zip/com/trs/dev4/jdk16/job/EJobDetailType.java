/*
 * Created: zhangshi@2011-6-23 下午02:06:28
 */
package com.trs.dev4.jdk16.job;

/**
 * 职责: <br>
 * 调度任务的类型
 * 
 */
public enum EJobDetailType {

	QUARTZ("quartz调度"), JDK("jdk调度"), SPRING("spring调度");
	
	String desc;
	
	EJobDetailType(String desc){
		this.desc = desc;
	}

	/**
	 * @see java.lang.Enum#toString()
	 * @since zhangshi @ 2011-7-1
	 */
	@Override
	public String toString() {
		return desc;
	}

}
