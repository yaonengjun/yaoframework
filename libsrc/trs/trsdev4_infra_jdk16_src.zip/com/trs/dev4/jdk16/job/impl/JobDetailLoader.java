/*
 * Created: TRS@Mar 17, 2011 4:01:38 PM
 */
package com.trs.dev4.jdk16.job.impl;

import javax.annotation.Resource;

import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobService;
import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 职责: <br>
 *
 */
public class JobDetailLoader implements IJobExecutor {
	/**
	 * 
	 * @return
	 * @since TRS @ Mar 17, 2011
	 */
	@Resource(name = "jobService")
	private IJobService jobService;

	/**
	 * @see com.trs.dev4.jdk16.job.IJobExecutor#execute(com.trs.dev4.jdk16.job.JobDetail)
	 * @since TRS @ Mar 17, 2011
	 */
	@Override
	public void execute(JobDetail jobDetail) {
		jobService.scheduleJobs();
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobExecutor#getName()
	 * @since TRS @ Mar 17, 2011
	 */
	@Override
	public String getName() {
		return "jobDetailLoader";
	}

	/**
	 * @param jobService
	 *            the {@link #jobService} to set
	 */
	public void setJobService(IJobService jobService) {
		this.jobService = jobService;
	}

}
