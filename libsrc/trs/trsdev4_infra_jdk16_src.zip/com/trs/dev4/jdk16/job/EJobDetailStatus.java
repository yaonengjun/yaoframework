/*
 * Created: TRS@Mar 14, 2011 11:19:36 PM
 */
package com.trs.dev4.jdk16.job;

/**
 * 职责: <br>
 * 计划调度JobDetail的状态。<br>
 * 只有当状态为启用时，任务才会被执行。
 * 
 */
public enum EJobDetailStatus {

	PAUSE("暂停"), RUN("启用");

	String desc;

	/**
	 * 
	 */
	EJobDetailStatus(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the {@link #desc}
	 */
	public String getDesc() {
		return desc;
	}
}
