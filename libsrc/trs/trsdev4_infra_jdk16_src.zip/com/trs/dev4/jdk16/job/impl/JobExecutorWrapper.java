/*
 * Created: TRS@Jan 29, 2011 10:22:23 PM
 */
package com.trs.dev4.jdk16.job.impl;

import com.trs.dev4.jdk16.job.JobDetail;
import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobListener;

/**
 * 用于封装IJobExecutor
 * 
 */
public class JobExecutorWrapper implements Runnable {
	/**
	 * 任务执行器
	 */
	private IJobExecutor jobExecutor;
	/**
	 * 任务详细信息
	 */
	private JobDetail jobDetail;
	/**
	 * 监听器
	 */
	private IJobListener jobListener;

	/**
	 * 
	 * @param jobExecutor
	 */
	public JobExecutorWrapper(IJobExecutor jobExecutor, JobDetail jobDetail,
			IJobListener jobListener) {
		this.jobExecutor = jobExecutor;
		this.jobDetail = jobDetail;
		this.jobListener = jobListener;
	}
	/**
	 * @see java.lang.Runnable#run()
	 * @since TRS @ Jan 29, 2011
	 */
	@Override
	public void run() {
		// 前置Trigger
		this.jobListener.beforeExecute(jobExecutor, jobDetail);
		//
		jobExecutor.execute(jobDetail);
		// 后置Trigger
		this.jobListener.afterExecuted(jobExecutor, jobDetail);
	}
}
