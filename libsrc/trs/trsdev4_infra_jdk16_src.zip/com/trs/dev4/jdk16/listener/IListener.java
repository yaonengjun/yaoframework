/**
 * Created: liushen@Dec 24, 2009 8:47:01 AM
 */
package com.trs.dev4.jdk16.listener;

/**
 *监听器接口. <br>
 * 
 */
public interface IListener {

}
