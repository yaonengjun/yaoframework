/**
 * Created: liushen@Dec 24, 2009 9:26:32 AM
 */
package com.trs.dev4.jdk16.listener;

import java.util.List;

/**
 * 管理和调度监听器的接口.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface IListenerController {

	/**
	 * 
	 * @param listener
	 * @creator liushen @ Dec 24, 2009
	 */
	void registerListener(IListener listener);

	/**
	 * 
	 * @param listener
	 * @creator liushen @ Dec 24, 2009
	 */
	void unregisterListener(IListener listener);

	/**
	 * 
	 * @param eventName
	 * @param type
	 * @param value
	 * @creator liushen @ Dec 24, 2009
	 */
	void dispatchEvent(String eventName, Class<?>[] type, Object[] value);

	/**
	 * 
	 * @param eventName
	 * @creator liushen @ Dec 24, 2009
	 */
	void dispatchEvent(String eventName);

	/**
	 * 返回友好的显示名称.
	 * 
	 * @creator liushen @ Dec 25, 2009
	 */
	String getDisplayName();

	/**
	 * 返回所管理的监听器类型的名称.
	 * 
	 * @return
	 * @creator liushen @ Dec 25, 2009
	 */
	String getListenerTypeName();

	/**
	 * 
	 * @return
	 * @creator liushen @ Dec 25, 2009
	 */
	List<IListener> listListeners();

}
