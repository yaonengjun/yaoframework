/*
 * Created: fangxiang@Dec 7, 2010 4:23:52 PM
 */
package com.trs.dev4.jdk16.session.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 *
 */
public class CachedSessionHandler<T extends ISessionUser> extends
		LocalSessionHandler<T> {

	/**
	 * @since fangxiang @ Jan 29, 2011
	 */
	private static final String ASID_PREFIX = "ASID_";
	/**
	 * @since fangxiang @ Jan 29, 2011
	 */
	private static final String LOGIN_PREFIX = "L_";
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(CachedSessionHandler.class);
	/**
	 * 
	 */
	@Resource(name = "cacheServer")
	protected ICacheServer cacheServer = null;

	/**
	 * @see com.trs.dev4.jdk16.session.impl.LocalSessionHandler#applicationSessionUpdated(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 * @since fangxiang @ Jan 12, 2011
	 */
	@Override
	protected void applicationSessionUpdated(ApplicationSession as) {
		super.applicationSessionUpdated(as);
		if (as != null && as.isLogined()) {
			updateCache(as);
		} else {
			logger.debug("ApplicationSession(" + as
					+ ") is anonymous session,don't update to memcache.");
			// 匿名的不用同步，在登录的时候再复制即可；
		}
	}

	/**
	 * @param as
	 * @since fangxiang @ Jan 29, 2011
	 */
	private void updateCache(ApplicationSession as) {
		if (cacheServer != null) {
			cacheServer.set(LOGIN_PREFIX + as.getUserName(),
					(int) this.getLoginedTTL() * 1000, as.getId());
			logger.debug("ApplicationSession(" + as
					+ ") update to memcache.");
			if (memcachedShared()) {
				cacheServer.set(ASID_PREFIX + as.getId(),
						(int) this.getLoginedTTL() * 1000, as);
			}
		} else {
			logger.debug("MemcachedClient is null.");
		}
	}

	/**
	 * @return
	 * @since fangxiang @ Jan 29, 2011
	 */
	protected boolean memcachedShared() {
		return false;
	}


	/**
	 * @see com.trs.dev4.jdk16.session.impl.LocalSessionHandler#isLogined(java.lang.String)
	 * @since fangxiang @ Jan 12, 2011
	 */
	@Override
	public boolean isLogined(String userName) {
		if (cacheServer != null) {
			String cachedApplicationSessionId = (String) cacheServer
					.get(LOGIN_PREFIX + userName);
			logger.debug("ApplicationSessionId(" + cachedApplicationSessionId
					+ ") got from memcache by (" + userName + ").");
			return !(StringHelper.isEmpty(cachedApplicationSessionId));
		} else {
			logger.debug("MemcacedClient is null.");
			return true;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.LocalSessionHandler#applicationSessionDeleted(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 * @since fangxiang @ Jan 12, 2011
	 */
	@Override
	protected void applicationSessionDeleted(ApplicationSession as) {
		super.applicationSessionDeleted(as);
		if (as != null && as.isLogined()) {
			deleteCache(as);
		} else {
			logger.debug("ApplicationSession(" + as
					+ ") is anonymous session,don't need delete from memcache.");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.LocalSessionHandler#timeout(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 */
	@Override
	protected void timeout(ApplicationSession as) {
		super.timeout(as);
		if (as != null && as.isLogined()) {
			deleteCache(as);
		} else {
			logger.debug("ApplicationSession(" + as
					+ ") is anonymous session,don't need delete from memcache.");
		}
	}

	/**
	 * @param as
	 * @since fangxiang @ Jan 29, 2011
	 */
	private void deleteCache(ApplicationSession as) {
		if (cacheServer != null) {
			cacheServer.delete(LOGIN_PREFIX + as.getUserName());
			logger.debug("ApplicationSession(" + as
					+ ") delete from memcache with L_" + as.getUserName()
					+ ".");
			if (memcachedShared()) {
				cacheServer.delete(ASID_PREFIX + as.getId());
			}
		} else {
			logger.debug("MemcachedClient is null.");
		}
	}

	/**
	 * @return the {@link #cacheServer}
	 */
	public ICacheServer getCacheServer() {
		return cacheServer;
	}

	/**
	 * @param cacheServer
	 *            the {@link #cacheServer} to set
	 */
	public void setCacheServer(ICacheServer cacheServer) {
		this.cacheServer = cacheServer;
	}

}
