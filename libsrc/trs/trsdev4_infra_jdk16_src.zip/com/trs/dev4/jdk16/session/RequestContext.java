/*
 * Created: liushen@Dec 10, 2009 4:49:11 PM
 */
package com.trs.dev4.jdk16.session;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.trs.dev4.jdk16.servlet24.CookieHelper;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 服务请求调用信息.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class RequestContext {

	/**
	 * 登录用户名，匿名则返回<code>null</code>.
	 */
	private String userName;

	/**
	 * 登录用户的ID.
	 */
	private int userId;

	/**
	 * 客户端实际IP.
	 */
	private String clientIP;

	/**
	 * 请求完整IP列表, 在存在X-Forward-For请求头时, 记录所有proxy的IP.
	 */
	private String proxyIPs;

	// TODO: liushen@Mar 19, 2010: 拆分为不同的子类：WebContext/ConsoleContext/CmdContext
	private String uri;

	private String uriAfterContextPath;

	private String queryStr;

	private String httpMethod;

	private String userAgent;
	
	private String serverSessionId;

	private String clientSessionId;

	// 系统名称，用于解决日志记录中默认填入trsuc的问题
	private String sysFlag;

	// 代码调用链
	private String callerStackBrief;
	/**
	 * 
	 */
	private HttpServletRequest httpRequest;

	/**
	 * 构造函数仅包及子类可见.
	 */
	protected RequestContext() {
	}

	/**
	 * 该请求所在会话是否登录.
	 */
	public boolean isLogined() {
		return userName != null;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Mar 19, 2010
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("RequestContext [");
		if (uri != null) {
			sb.append("uri=").append(uri);
			if (queryStr != null) {
				sb.append("?").append(queryStr);
			}
		}
		if (clientIP != null) {
			sb.append(", ").append("clientIP=").append(clientIP);
		}
		if (userName != null) {
			sb.append(", ").append("loginUserName=").append(userName);
		}
		if (userAgent != null) {
			sb.append(", ").append("userAgent=").append(userAgent);
		}
		if (proxyIPs != null) {
			sb.append(", ").append("proxyIPs=").append(proxyIPs);
		}
		sb.append("]");
		return sb.toString();
	}

	/**
	 * Get the {@link #clientIP}.
	 * 
	 * @return the {@link #clientIP}.
	 */
	public String getClientIP() {
		return clientIP;
	}

	/**
	 * Get the {@link #proxyIPs}.
	 * 
	 * @return the {@link #proxyIPs}.
	 */
	public String getProxyIPs() {
		return proxyIPs;
	}

	/**
	 * Get the {@link #userName}.
	 * 
	 * @return the {@link #userName}.
	 */
	public String getUserName() {
		return userName;
	}
	
	/**
	 * 参见 {@link HttpServletRequest#getRequestURI()}： Returns the part of this
	 * request's URL from the protocol name up to the query string in the first
	 * line of the HTTP request. The web container does not decode this String.
	 * For example: First line of HTTP request Returned Value POST
	 * /some/path.html HTTP/1.1 /some/path.html GET http://foo.bar/a.html
	 * HTTP/1.0 /a.html HEAD /xyz?a=b HTTP/1.1 /xyz
	 */
	public String getUri() {
        return uri;
    }

	/**
	 * @return the {@link #uriAfterContextPath}
	 */
	public String getUriAfterContextPath() {
		return uriAfterContextPath;
	}

	/**
	 * @return the {@link #httpMethod}
	 */
	public String getHttpMethod() {
		return httpMethod;
	}

	/**
	 * @return
	 * @since liushen @ Jan 30, 2012
	 */
	public String getUriWithQueryString() {
		if (StringHelper.isEmpty(queryStr)) {
			return uri;
		} else {
			return uri + "?" + queryStr;
		}
	}

	/**
	 * @return the {@link #queryStr}
	 */
	public String getQueryString() {
		return queryStr;
	}

	/**
	 * Get the {@link #userId}.
	 * 
	 * @return the {@link #userId}
	 * @since zhangshi @ 2011-7-1
	 */
	public int getUserId() {
		return userId;
	}

	public String getSysFlag() {
		if (StringHelper.isEmpty(sysFlag))
			return "";

		return sysFlag;
	}

	public String getCallerStackBrief() {
		return callerStackBrief;
	}

	/**
	 * 系统自己请求的上下文信息.
	 * 
	 * @since liushen @ Feb 22, 2010
	 * @deprecated liushen@Feb 2, 2012: 改调
	 *             {@link #getLocalRequestContext(String)} (或子类覆盖)
	 */
	@Deprecated
	public static RequestContext getLocalRequestContext() {
		return getLocalRequestContext("TRS.SYSTEM");
	}

	/**
	 * 系统自己请求的上下文信息, 并以指定用户名作为操作人.
	 * 
	 * @param userName
	 *            操作人
	 * @since liushen @ Jun 2, 2011
	 */
	public static RequestContext getLocalRequestContext(String userName) {
		RequestContext requestContext = new RequestContext();
		requestContext.setUserName(userName);
		requestContext.setClientIP("localhost");
		return requestContext;
	}

	/**
	 * 获取Web请求的上下文对象.
	 * 
	 * @param request
	 *            HTTP请求
	 * @since liushen @ Mar 19, 2010
	 */
	public static RequestContext getWebRequestContext(HttpServletRequest request) {
		RequestContext requestContext = new RequestContext();
		requestContext.setClientIP(RequestUtil.getClientIP(request));
		requestContext.setProxyIPs(request.getHeader("X-Forwarded-For"));
		requestContext.uri = request.getRequestURI();
		requestContext.queryStr = request.getQueryString();
		requestContext.uriAfterContextPath = RequestUtil.getRelativePath(request);
		requestContext.httpMethod = request.getMethod();
		requestContext.userAgent = request.getHeader("user-agent");
		requestContext.httpRequest = request;
		HttpSession session = request.getSession(false);
		if (session != null) {
			requestContext.serverSessionId = session.getId();
		}
		requestContext.clientSessionId = new CookieHelper(request, null).getValue("JSESSIONID");
		return requestContext;
	}

	/**
	 * 该请求上下文是否来自Web(即HTTP方式的请求；通常是浏览器或Flash)。
	 * 
	 * @since liushen @ Jan 13, 2011
	 */
	public boolean isWebRequest() {
		return httpRequest != null;
	}

	/**
	 * Get the {@link #userAgent}.
	 * 
	 * @return the {@link #userAgent}.
	 */
	public String getUserAgent() {
		return userAgent;
	}

	/**
	 * Set the {@link #userName}.
	 * 
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Set the {@link #userId}.
	 * 
	 * @param userId
	 *            the userId to set
	 * @since zhangshi @ 2011-7-1
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * Set the {@link #proxyIPs}.
	 * 
	 * @param proxyIPs
	 *            the proxyIPs to set
	 */
	public void setProxyIPs(String proxyIPs) {
		this.proxyIPs = proxyIPs;
	}

	/**
	 * Set the {@link #clientIP}.
	 * 
	 * @param clientIP
	 *            the clientIP to set
	 */
	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}

	public void setSysFlag(String sysFlag) {
		this.sysFlag = sysFlag;
	}

	public void setCallerStackBrief(String callerStackBrief) {
		this.callerStackBrief = callerStackBrief;
	}

	/**
	 * 服务端实际分配的会话ID；如不存在则为<code>null</code>.
	 */
	public String getServerSessionId() {
		return serverSessionId;
	}

	/**
	 * 客户端Cookie发送的会话ID；如不存在则为<code>null</code>.
	 */
	public String getClientSessionId() {
		return StringHelper.avoidNull(clientSessionId);
	}

	/**
	 * @return
	 * @since congli @ 2011-8-25
	 */
	public boolean isNewSessionAsFresh() {
		return clientSessionId == null;
	}

	/**
	 * @return
	 * @since congli @ 2011-8-25
	 */
	public boolean isNewSessionAsOutofDate() {
		return clientSessionId != null
				&& (false == clientSessionId.equals(serverSessionId));
	}
	
	/**
	 * 根据headerName 获得 request中的header
	 * 
	 * @param headerName
	 * @return
	 * @since TRS @ 2012-1-19
	 */
	public String getHeader(String headerName) {
		if (null == httpRequest) {
			return null;
		}
		return httpRequest.getHeader(headerName);
	}

	/**
	 * 根据parameterName 获得request中的 参数值
	 * 
	 * @param parameterName
	 * @return
	 * @since TRS @ 2012-1-19
	 */
	public String getParameter(String parameterName) {
		if (null == httpRequest) {
			return null;
		}
		return httpRequest.getParameter(parameterName);
	}

	/**
	 * 根据attributeName 的值 获得request对应的Object
	 * 
	 * @param attributeName
	 * @return
	 * @since TRS @ 2012-1-19
	 */
	public Object getAttribute(String attributeName) {
		if (null == httpRequest) {
			return null;
		}
		return httpRequest.getAttribute(attributeName);
	}

	/**
	 * 根据cookieName 获得 当前cookie内的值
	 * 
	 * @param cookieName
	 * @return
	 * @since TRS @ 2012-1-19
	 */
	public String getCookie(String cookieName) {
		if (null == httpRequest) {
			return null;
		}
		CookieHelper cookieHelper = new CookieHelper(httpRequest, null);
		return cookieHelper.getValue(cookieName);
	}

	// ============= 以下方法仅供子类调用 =============
	/**
	 * @param uri
	 *            the {@link #uri} to set
	 */
	protected void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * @param queryStr
	 *            the {@link #queryStr} to set
	 */
	protected void setQueryStr(String queryStr) {
		this.queryStr = queryStr;
	}

	/**
	 * @param userAgent
	 *            the {@link #userAgent} to set
	 */
	protected void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	/**
	 * @param serverSessionId
	 *            the {@link #serverSessionId} to set
	 */
	protected void setServerSessionId(String serverSessionId) {
		this.serverSessionId = serverSessionId;
	}

	/**
	 * @param clientSessionId
	 *            the {@link #clientSessionId} to set
	 */
	protected void setClientSessionId(String clientSessionId) {
		this.clientSessionId = clientSessionId;
	}

	/**
	 * @param httpRequest
	 *            the {@link #httpRequest} to set
	 */
	protected void setHttpRequest(HttpServletRequest httpRequest) {
		this.httpRequest = httpRequest;
	}

	/**
	 * @param uriAfterContextPath
	 *            the {@link #uriAfterContextPath} to set
	 */
	protected void setUriAfterContextPath(String uriAfterContextPath) {
		this.uriAfterContextPath = uriAfterContextPath;
	}

	/**
	 * @param httpMethod
	 *            the {@link #httpMethod} to set
	 */
	protected void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}
	
	/**
	 * 获取指定request的指定参数的String值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @param maxLength
	 *            最大长度
	 * @return 指定参数的值并作trim处理
	 */
	public String getParameterAndTrim(String param, String defaultValue, int maxLength) {
		return RequestUtil.getParameterAndTrim(this.httpRequest, param, defaultValue, maxLength);

	}

	/**
	 * 获取指定request的指定参数的整数值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 */
	public int getParameterAsInt(String param, int defaultValue) {
		return RequestUtil.getParameterAsInt(this.httpRequest, param, defaultValue);
	}

	/**
	 * 获取指定request的指定参数的整数值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @return 参数值的整数数组形式. 如果该参数不存在返回int[0]；解析整数时发生了异常, 则设定为默认值.
	 */
	public int[] getParameterAsInArray(String param, int defaultValue) {
		return RequestUtil.getParameterAsIntArray(this.httpRequest, param, defaultValue);
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 10, 2012
	 */
	public HttpServletRequest getRequest() {
		return this.httpRequest;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @since TRS @ Feb 10, 2012
	 */
	public MultipartFile getMultipartFile(String fileName) {
		if (this.httpRequest == null) {
			return null;
		}
		if (!(this.httpRequest instanceof MultipartHttpServletRequest)) {
			return null;
		}
		return ((MultipartHttpServletRequest) this.httpRequest).getFile(fileName);
	}
}
