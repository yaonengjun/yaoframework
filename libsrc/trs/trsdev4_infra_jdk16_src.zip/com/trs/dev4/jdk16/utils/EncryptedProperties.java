/**
 *
 */
package com.trs.dev4.jdk16.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.log4j.Logger;

/**
 * 用于读取和写入加密的属性文件，加密格式为“属性名”+"="+“{加密算法}”+“加密字符串”。 <BR>
 * 手工修改属性时，只要按照普通的属性文件设置即可，当调用save的方法写入时会自动加密。<BR>
 * [08.12.12]初始创建此文件
 * 
 * @author TRS信息技术有限公司
 * @since Administrator@Dec 9, 2008
 */
@SuppressWarnings("unchecked")
public class EncryptedProperties extends SortedProperties {
	/**
	 *
	 */
	private final static Logger LOG = Logger.getLogger(EncryptedProperties.class);
	/**
	 * 密钥数据
	 */
	private final static String keyData = "T3+GJY9SI8Q=";
	/**
	 * 加密
	 */
	private Cipher encryptCipher;
	/**
	 * 解密
	 */
	private Cipher decryptCipher;
	/**
	 *
	 */
	private boolean initialized = false;
	/**
	 * 算法名称
	 */
	private final static String encryptAlgorithm = "DES";
	/**
	 * 加密属性值的前缀
	 */
	private final static  String encryptPrefix = "{DES}";
	/**
	 * 加密后的属性值列表
	 */
	protected Properties encryptedProperties = new Properties();
	/**
	 *
	 */
	protected String[] encryptedNames;
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/**
	 *
	 */
	private Map modifiedProperties = new Hashtable();

	/**
	 * 构造函数，不加密
	 */
	public EncryptedProperties() {
		super();
		init();
	}

	/**
	 * 构造函数，指定需加密的属性项列表
	 * 
	 * @param encryptedNames
	 *            需加密的属性项列表
	 */
	public EncryptedProperties(String[] encryptedNames){
		super();
		this.encryptedNames = encryptedNames;
		init();
	}

	/**
	 * 初始化与加密/解密相关的对象
	 */
	private void init(){
		try {
			DESKeySpec dks = new DESKeySpec( Base64Util.decodeBytes(keyData) );
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance( encryptAlgorithm );
			/**
			 * 密钥算法
			 */
			SecretKey keyDES = keyFactory.generateSecret(dks);
			encryptCipher = Cipher.getInstance(encryptAlgorithm);
			encryptCipher.init(Cipher.ENCRYPT_MODE, keyDES);
			decryptCipher = Cipher.getInstance(encryptAlgorithm);
			decryptCipher.init(Cipher.DECRYPT_MODE, keyDES);
		}catch(NoSuchAlgorithmException ex){
			LOG.error(ex.getMessage(),ex);
		}catch(NoSuchPaddingException ex){
			LOG.error(ex.getMessage(),ex);
		} catch (InvalidKeyException ex) {
			LOG.error(ex.getMessage(),ex);
		} catch (InvalidKeySpecException ex) {
			LOG.error(ex.getMessage(),ex);
		}
	}

	/**
	 * @param defaults
	 */
	public EncryptedProperties(Properties defaults) {
		super(defaults);
		init();
	}

	/**
	 * @see java.util.Properties#getProperty(java.lang.String, java.lang.String)
	 */
	@Override
	public String getProperty(String key, String defaultValue) {
		return super.getProperty(key, defaultValue);
	}

	/**
	 * @see java.util.Properties#getProperty(java.lang.String)
	 */
	@Override
	public String getProperty(String key) {
		return super.getProperty(key);
	}

	/**
	 * @see java.util.Properties#list(java.io.PrintStream)
	 */
	@Override
	public void list(PrintStream out) {
		super.list(out);
	}

	/**
	 * @see java.util.Properties#list(java.io.PrintWriter)
	 */
	@Override
	public void list(PrintWriter out) {
		super.list(out);
	}

	/**
	 * @see java.util.Properties#load(java.io.InputStream)
	 */
	@Override
	public synchronized void load(InputStream inStream) throws IOException {
		// 获取原始的文件
		Properties originalProperties = new Properties();
		originalProperties.load(inStream);
		// 依次遍历文件的属性列表并设置到当前的对象内
		modifiedProperties.clear();
		encryptedProperties.clear();
		Enumeration e = originalProperties.propertyNames();
		for ( ; e.hasMoreElements() ; ){
			String propertyName = (String)e.nextElement();
			String propertyValue = originalProperties.getProperty(propertyName);
			put(propertyName, propertyValue);
		}
	}

	/**
	 * 判断属性值是否已经加密
	 * 
	 * @param propertyValue
	 *            待判断的属性值
	 * @return 如果已经加密则返回true，否则返回false
	 */
	public boolean isEncrypted(String propertyValue){
		if ( LOG.isDebugEnabled() ){
			LOG.debug("propertyValue:"+propertyValue);
		}
		if ( propertyValue == null || propertyValue.length() < 5 )
			return false;
		return encryptPrefix.equals(propertyValue.substring(0,encryptPrefix.length()));
	}

	/**
	 * 判断属性是否为加密属性项
	 * 
	 * @param propertyName
	 *            待判断的属性名
	 * @return 如果是需要加密的属性项则返回true，否则返回false
	 */
	public boolean isEncryptedProperty(String propertyName){
		if ( encryptedNames !=  null ){
			for ( int i = 0 ; i < encryptedNames.length ; i++ ){
				if ( encryptedNames[i].equals(propertyName) ){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 *
	 * @param propertyName
	 * @return
	 */
	public String getEncryptedProperty(String propertyName){
		return encryptedProperties.getProperty(propertyName);
	}

	/**
	 *
	 * @param property
	 * @return
	 */
	private String decrypt(String propertyValue) {
		if ( !isEncrypted(propertyValue) ){
			return propertyValue;
		}
		if ( propertyValue != null ){
			propertyValue = propertyValue.substring(5);
			if ( LOG.isDebugEnabled() ){
				LOG.debug("propertyValue:"+propertyValue);
			}
			//
			try {
				byte[] cipherBytes = decryptCipher.doFinal(Base64Util.decodeBytes(propertyValue));
				return new String(cipherBytes);
			} catch (javax.crypto.BadPaddingException ex) {
				LOG.error(ex.getMessage(),ex);
			} catch (javax.crypto.IllegalBlockSizeException ex) {
				LOG.error(ex.getMessage(),ex);
			}
		}
		return propertyValue;
	}

	/**
	 * @see java.util.Properties#propertyNames()
	 */
	@Override
	public Enumeration propertyNames() {
		return super.propertyNames();
	}

	/**
	 * @see java.util.Properties#setProperty(java.lang.String, java.lang.String)
	 */
	@Override
	public synchronized Object setProperty(String key, String value) {
		if ( LOG.isDebugEnabled() ){
			LOG.debug("Property(Key,Value):"+key+","+value);
		}
		return put(key,value);
	}

	/**
	 *
	 * @param value
	 * @return
	 */
	private String encrypt(String propertyValue) {
		if ( LOG.isDebugEnabled() ){
			LOG.debug("propertyValue:"+propertyValue);
		}
		if ( propertyValue != null ){
			try{
				byte[] cipherByte = encryptCipher.doFinal(propertyValue.getBytes());
				return "{DES}"+Base64Util.encode(cipherByte);
			}catch(javax.crypto.BadPaddingException ex){
				LOG.error(ex.getMessage(),ex);
			}catch(javax.crypto.IllegalBlockSizeException ex){
				LOG.error(ex.getMessage(),ex);
			}
		}
		return propertyValue;
	}

	/**
	 *
	 * @return
	 */
	protected Properties getEncryptedProperties(){
		return this.encryptedProperties;
	}

	/**
	 * @see java.util.Hashtable#putAll(java.util.Map)
	 */
	@Override
	public synchronized void putAll(Map t) {
		if ( t instanceof Properties ){
			for (  Enumeration e = ((Properties)t).propertyNames() ; e.hasMoreElements() ; ){
				String propertyName = (String)e.nextElement();
				String propertyValue = ((Properties)t).getProperty(propertyName);
				put(propertyName, propertyValue);
			}
		}else{
			for ( Iterator i =  t.keySet().iterator() ; i.hasNext() ; ){
				String propertyName = (String)i.next();
				String propertyValue = (String)t.get(propertyName);
				put(propertyName, propertyValue);
			}

		}
	}

	/**
	 *
	 * @param propertyName
	 * @param propertyValue
	 * @param initialized
	 * @return
	 */
	Object put(String propertyName,String propertyValue){
		if (isEncrypted(propertyValue)) { // 是加密数据
			encryptedProperties.setProperty(propertyName, propertyValue);
			String decryptedValue = decrypt(propertyValue);
			if (!isEncryptedProperty(propertyName)) { // 不属于加密字段的话，则需要解密写入
				modifiedProperties.put(propertyName, decryptedValue);
			} else if (initialized == true
					&& !decryptedValue.equals(this.get(propertyName))) { // 只要是初始化结束，所有的修改都记录为更新
				modifiedProperties.put(propertyName, propertyValue);
			}
			return super.setProperty(propertyName, decryptedValue);
		} else { // 不是加密数据
			String encryptedValue = encrypt(propertyValue);
			encryptedProperties.setProperty(propertyName, encryptedValue);
			if (isEncryptedProperty(propertyName)) { // 属于加密字段的话，则需要加密写入
				modifiedProperties.put(propertyName, encryptedValue);
			} else if (initialized == true
					&& !propertyValue.equals(this.get(propertyName))) { // 只要是初始化结束，所有的修改都记录为更新
				modifiedProperties.put(propertyName, propertyValue);
			}
			return super.setProperty(propertyName, propertyValue);
		}
	}

	/**
	 *
	 * @return
	 */
	public synchronized Map getModifiedProperties(){
		return Collections.unmodifiableMap(modifiedProperties);
	}

	/**
	 * Returns the {@link #initialized}.
	 * @return the initialized.
	 */
	public boolean isInitialized() {
		return initialized;
	}

	/**
	 * Set {@link #initialized}.
	 * @param initialized The initialized to set.
	 */
	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}
}
