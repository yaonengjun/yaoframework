/*
 * Created: liushen@Jun 2, 2011 8:58:58 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.mozilla.intl.chardet.nsDetector;
import org.mozilla.intl.chardet.nsICharsetDetectionObserver;
import org.mozilla.intl.chardet.nsPSMDetector;

import com.trs.dev4.jdk16.exception.WrappedException;

import de.schlichtherle.io.FileInputStream;

/**
 * 封装jchardet，用来检测字节流的字符编码: <br>
 */
public class EncodingDetector {

	private static final Logger LOG = Logger.getLogger(EncodingDetector.class);

	/**
	 * 获取文件最可能的编码.
	 * 
	 * @since liushen @ Jun 2, 2011
	 */
	public static String getMostProbableCharset(File file) {
		String encoding = "UNABLE_DETECT";
		FileUtil.assertFileNotEmpty(file);
		InputStream is;
		try {
			is = new FileInputStream(file);
		} catch (Exception e) {
			throw new WrappedException(e);
		}
		String[] probableSet = detectAll(is);
		if (ArrayUtil.isEmpty(probableSet)) {
			return encoding;
		}
		return probableSet[0];
	}

	/**
	 * 检测该字节流所有可能的编码.
	 * 
	 * @since liushen @ Jun 2, 2011
	 */
	public static String[] detectAll(InputStream is) {
		String[] probableSet;
		try {
			probableSet = new EncodingDetector().detectAllCharset(is);
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("probable encoding: " + ArrayUtil.toString(probableSet));
		}
		return probableSet;
	}

	private boolean found = false;
	private String result;
	private int lang;

	public String[] detectChineseCharset(InputStream in) throws IOException {
		lang = nsPSMDetector.CHINESE;
		String[] prob;
		// Initalize the nsDetector() ;
		nsDetector det = new nsDetector(lang);
		// Set an observer...
		// The Notify() will be called when a matching charset is found.

		det.Init(new nsICharsetDetectionObserver() {

			public void Notify(String charset) {
				found = true;
				result = charset;
			}
		});
		BufferedInputStream imp = new BufferedInputStream(in);
		byte[] buf = new byte[1024];
		int len;
		boolean isAscii = true;
		while ((len = imp.read(buf, 0, buf.length)) != -1) {
			// Check if the stream is only ascii.
			if (isAscii)
				isAscii = det.isAscii(buf, len);
			// DoIt if non-ascii and not done yet.
			if (!isAscii) {
				if (det.DoIt(buf, len, false))
					break;
			}
		}
		imp.close();
		in.close();
		det.DataEnd();
		if (isAscii) {
			found = true;
			prob = new String[] { "ASCII" };
		} else if (found) {
			prob = new String[] { result };
		} else {
			prob = det.getProbableCharsets();
		}
		return prob;
	}

	public String[] detectAllCharset(InputStream in) throws IOException {
		try {
			lang = nsPSMDetector.ALL;
			return detectChineseCharset(in);
		} catch (IOException e) {
			throw e;
		}
	}

}
