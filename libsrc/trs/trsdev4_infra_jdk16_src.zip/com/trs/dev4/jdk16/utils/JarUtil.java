/*
 * Created: liushen@May 16, 2010 10:40:38 AM
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.io.IOException;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * Jar文件特定操作的工具类，比如提取manifest元信息. <br>
 * 
 */
public class JarUtil {

	/**
	 * 获取Jar的manifest文件中<code>Implementation-Version</code>头的取值.
	 * 
	 * @param file
	 *            jar文件(或zip文件)
	 * @since liushen @ Apr 2, 2011
	 * @see #getManifestAttributeValue(File, String)
	 */
	public static String getImplementationVersion(File file) {
		return getManifestAttributeValue(file, "Implementation-Version");
	}

	/**
	 * 获取Jar的manifest文件中，给定的一系列头的取值.
	 * 
	 * @param file
	 *            文件对象
	 * @param keys
	 *            要获取哪些头(头名称)
	 * @return 头名 = 取值，一行一个
	 * @since liushen @ Apr 2, 2011
	 * @see #getManifestAttributeValue(File, String)
	 */
	public static String getManifestValues(File file, String... keys) {
		StringBuilder sb = new StringBuilder();
		for (String key : keys) {
			sb.append(key).append(" = ")
					.append(getManifestAttributeValue(file, key));
			sb.append("\n");
		}
		return sb.toString();
	}

	/**
	 * 获取Jar的manifest文件中，给定头的取值.
	 * 
	 * @param file
	 *            文件对象
	 * @param key
	 *            要获取哪个头(头名称)
	 * @return 该头的取值；如果该头不存在则返回<code>null</code>; 如果不存在manifest，则返回字符串
	 *         <code>"No Manifest!"</code>
	 * @throws WrappedException
	 *             出现IO异常时
	 */
	public static String getManifestAttributeValue(File file, String key) {
		JarFile jarfile;
		try {
			jarfile = new JarFile(file);
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		Manifest manifest;
		try {
			manifest = jarfile.getManifest();
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		// liushen@Apr 2, 2011: JDK getManifest()有可能返回null
		if (manifest == null) {
			return "No Manifest!";
		}

		// Get the main attributes in the manifest
		Attributes attrs = manifest.getMainAttributes();

		// Enumerate each attribute
		// for (Iterator<Object> it = attrs.keySet().iterator(); it.hasNext();)
		// {
		// // Get attribute name
		// Attributes.Name attrName = (Attributes.Name) it.next();
		//
		// // Get attribute value
		// String attrValue = attrs.getValue(attrName);
		// System.out.println(attrName + ": " + attrValue);
		// }

		// attrs = manifest.getAttributes(key);

		// Map<String, Attributes> maps = manifest.getEntries();
		// System.out.println(maps);

		return attrs.getValue(key);
	}

}
