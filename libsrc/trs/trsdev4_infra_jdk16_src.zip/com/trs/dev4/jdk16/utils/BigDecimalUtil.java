/*
 * Created: zhangshi@2012-6-4 下午02:10:23
 */
package com.trs.dev4.jdk16.utils;

import java.math.BigDecimal;

/**
 * 职责: BigDecimal的工具类<br>
 * 
 */
public class BigDecimalUtil {

	/**
	 * 将int值转换成bigDecimal并返回
	 * 
	 * @param num
	 * @return
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal parse(int num) {
		return new BigDecimal(num);
	}

	/**
	 * 将String变量转换成BigDecimal
	 * 
	 * @param num
	 * @return
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal parse(String num) {
		if (StringHelper.isEmpty(num)) {
			return new BigDecimal(0);
		}

		BigDecimal numToReturn;
		try {
			numToReturn = new BigDecimal(num);
		} catch (Exception e) {
			return new BigDecimal(0);
		}
		return numToReturn;
	}

	/**
	 * 两个BigDecimal类型数值相加并返回
	 * 
	 * @param a
	 * @param b
	 * @return
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal add(BigDecimal a, BigDecimal b) {
		if (null == a && null == b) {
			return new BigDecimal(0);
		}

		if (null == a) {
			return b;
		}

		if (null == b) {
			return a;
		}

		return a.add(b);
	}

	/**
	 * 两个BigDecimal数值相见<br>
	 * 
	 * @param a
	 *            被减数
	 * @param b
	 *            减数
	 * @return a-b
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal minus(BigDecimal a, BigDecimal b) {
		if (null == a && null == b) {
			return new BigDecimal(0);
		}

		if (null == a) {
			return (new BigDecimal(0)).subtract(b);
		}

		if (null == b) {
			return a;
		}
		return a.subtract(b);
	}

	/**
	 * 计算两个BigDecimal相乘的结果，任意一方为null或0，均返回0
	 * 
	 * @param a
	 * @param b
	 * @return
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal multiply(BigDecimal a, BigDecimal b) {
		if (null == a || null == b) {
			return new BigDecimal(0);
		}
		if (equals(a, new BigDecimal(0)) || equals(b, new BigDecimal(0))) {
			return new BigDecimal(0);
		}
		return a.multiply(b);
	}

	/**
	 * 计算两个BigDecimal相除的结果，任意一方为null，均返回0<br>
	 * 
	 * @param a
	 *            除数
	 * @param b
	 *            被除数
	 * @param roundingMode
	 *            精确到小数点后几位，如果该数值小于零，则不做特殊声明<br>
	 *            例如： 如果该数值为4，那么2/3，计算出来的值为0.6667
	 * @return a/b
	 * @since zhangshi @ 2012-6-4
	 */
	public static BigDecimal divide(BigDecimal a, BigDecimal b, int roundingMode) {
		if (null == a || null == b) {
			return new BigDecimal(0);
		}
		if (equals(a, new BigDecimal(0)) || equals(b, new BigDecimal(0))) {
			return new BigDecimal(0);
		}
		if (roundingMode <= 0)
			return a.divide(b);

		return a.divide(b, roundingMode, BigDecimal.ROUND_HALF_UP);
	}

	/**
	 * 比较两个BigDecimal的大小<br>
	 * 
	 * 
	 * @param a
	 *            为null，则返回false
	 * @param b
	 *            a不为null，b为null时则返回true
	 * @return if a>b 返回true<br>
	 *         if a==b|| a<b 返回 false
	 * @since zhangshi @ 2012-6-4
	 */
	public static boolean bigger(BigDecimal a, BigDecimal b) {
		if (null == a) {
			return false;
		}
		if (null == b) {
			return true;
		}
		int result = a.compareTo(b);
		return result > 0;
	}

	/**
	 * 比较两个BigD是否相等。任意一方为null时，均返回false
	 * 
	 * @param a
	 * @param b
	 * @return
	 * @since zhangshi @ 2012-6-4
	 */
	public static boolean equals(BigDecimal a, BigDecimal b) {
		if (null == b || null == a) {
			return false;
		}

		int result = a.compareTo(b);
		return result == 0;
	}
}
