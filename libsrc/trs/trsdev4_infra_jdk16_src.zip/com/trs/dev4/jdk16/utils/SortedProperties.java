/*
 * Created: liushen@May 30, 2009 3:31:44 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * 根据Key排序的Properties.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
@SuppressWarnings("serial")
public class SortedProperties extends Properties {
	
	public SortedProperties() {
		super();
	}

	/**
	 * 根据给定的Properties, 构造对应的排序的Properties.
	 * 
	 * @param props
	 * @creator liushen @ May 30, 2009
	 */
	public SortedProperties(Properties props) {
		if (props == null) {
			return;
		}
		
		Set<Object> keys = props.keySet();
		for (Object key : keys) {
			put(key, props.get(key));
		}
	}
	
	/**
	 * Overrides, called by the store method.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public synchronized Enumeration keys() {
		Vector v = new Vector(keySet());
		Collections.sort(v);
		return v.elements();
	}

	/**
	 * 覆盖此方法, 以便让用该方法诊断输出时的结果也是排过序的.
	 * 
	 * @see java.util.Properties#list(java.io.PrintStream)
	 * @creator liushen @ May 30, 2009
	 */
	@Override
	public void list(PrintStream out) {
		try {
			super.store(out, "-- listing properties --");
		} catch (IOException e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 覆盖此方法, 以便让用该方法诊断输出时的结果也是排过序的.
	 * 
	 * @see java.util.Hashtable#toString()
	 * @creator liushen @ May 30, 2009
	 */
	@Override
	public String toString() {
		int max = size() - 1;
		if (max == -1)
			return "{}";

		StringBuilder sb = new StringBuilder();
		sb.append('{');
		int i = 0;
		synchronized (this) {
			for (@SuppressWarnings("rawtypes")
			Enumeration e = keys(); e.hasMoreElements();) {
				String key = (String) e.nextElement();
				sb.append(key).append('=').append(get(key));

				if (i == max) {
					return sb.append('}').toString();
				}
				i++;
				sb.append(", ");
			}
		}
		
		return sb.toString();
	}

}
