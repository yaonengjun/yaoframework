/*
 * Created: liushen@Dec 17, 2010 8:20:04 PM
 */
package com.trs.dev4.jdk16.utils;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 *
 */
public class MomentTest {

	private static final long LONG_MS_20101201 = 1291132800000L;

	/**
	 */
	@Test
	public void testConstructor() {
		valueIsCorrect(LONG_MS_20101201, 2010, 12, 1, 0, 0, 0, 0);
		valueIsWrong(LONG_MS_20101201, 2010, 1, 1, 0, 0, 0, 0);
		valueIsFail(2010, 0, 0, 0, 0, 0, 0);
		valueIsFail(2010, -1, 1, 0, 0, 0, 0);
		valueIsFail(2010, 12, 40, 0, 0, 0, 0);
	}

	void valueIsCorrect(long milliSeconds, int year, int monthOfYear, int dayOfMonth,
			int hourOfDay, int minuteOfHour, int secondOfMinute,
			int millisOfSecond) {
		Moment moment = new Moment(year, monthOfYear, dayOfMonth, hourOfDay,
				minuteOfHour, secondOfMinute, millisOfSecond);
		assertEquals(milliSeconds, moment.getTimeMillis());
	}

	void valueIsWrong(long milliSeconds, int year, int monthOfYear,
			int dayOfMonth, int hourOfDay, int minuteOfHour,
			int secondOfMinute, int millisOfSecond) {
		Moment moment = new Moment(year, monthOfYear, dayOfMonth, hourOfDay,
				minuteOfHour, secondOfMinute, millisOfSecond);
		assertFalse(milliSeconds == moment.getTimeMillis());
	}

	void valueIsFail(int year, int monthOfYear, int dayOfMonth, int hourOfDay,
			int minuteOfHour, int secondOfMinute, int millisOfSecond) {
		try {
			new Moment(year, monthOfYear, dayOfMonth, hourOfDay, minuteOfHour,
					secondOfMinute, millisOfSecond);
			fail();
		} catch (Exception e) {
		}
	}

	@Test
	public void basic() throws Exception {
		Moment moment = null;

		moment = new Moment(2008, 8, 8, 20, 9, 33, 17);
		assertEquals("08-8-8 20:9", moment.toShortForm());
		assertEquals("2008-8-8 20:09:33", moment.toMediumForm());
		assertEquals("2008-08-08 20:09:33.017", moment.toLongForm());
		assertEquals("2年3个月前", moment.toRelativeForm(LONG_MS_20101201));
		assertEquals("中国标准时间", moment.getTimeZone());
		assertEquals("8月8日 星期五", moment.toMonthDateWeekForm());
		assertEquals("2008-08-08 20:09:33.017 星期五", moment.toFullForm());
		
		moment = new Moment(2009, 12, 8, 20, 9, 33, 17);
		assertEquals("09-12-8 20:9", moment.toShortForm());
		assertEquals("2009-12-8 20:09:33", moment.toMediumForm());
		assertEquals("2009-12-08 20:09:33.017", moment.toLongForm());
		assertEquals("11个月前", moment.toRelativeForm(LONG_MS_20101201));

		moment = new Moment(2010, 12, 8, 20, 9, 33, 17);
		assertEquals("10-12-8 20:9", moment.toShortForm());
		assertEquals("2010-12-8 20:09:33", moment.toMediumForm());
		assertEquals("2010-12-08 20:09:33.017", moment.toLongForm());
		assertEquals("1周20小时后", moment.toRelativeForm(LONG_MS_20101201));

	}

}
