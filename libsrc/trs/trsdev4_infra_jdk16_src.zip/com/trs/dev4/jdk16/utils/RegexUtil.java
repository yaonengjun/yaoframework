/*
 * Created: changpeng@2009-4-7 下午06:45:03
 */
package com.trs.dev4.jdk16.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 字符串匹配处理.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class RegexUtil {
	/**
	 * 判断str1中是否包含str2中的某一个或某几个字符
	 * 
	 * @param str1
	 * @param str2
	 * @return 当包含时，返回true，否则返回false
	 */
	public static boolean hasCharOfStr2(String str1, String str2) {
		if (str1 == null || str2 == null || str1.trim().length() == 0
				|| str2.trim().length() == 0) {
			return false;
		}
		for (int i = 0; i < str2.length(); i++) {
			if (str1.contains(String.valueOf(str2.charAt(i)))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 判断字符串是否为IP形式,主要是ipv4，形如：192.9.200.200
	 * 
	 * @param ipTobeChecked
	 * @return
	 * @creator chuchanglin @ 2009-12-29
	 */
	public static boolean isIPStyle(String ipTobeChecked){
		String test = "([1-9]|[1-9]\\d|1\\d{2}|2[0-1]\\d|22[0-3])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
		Pattern pattern = Pattern.compile(test);
		Matcher matcher = pattern.matcher(ipTobeChecked);

		return matcher.matches();
	}

	/**
	 * 判断是否为时间类型，形如yyyy-MM-dd HH:mm:ss
	 * 
	 * @param time
	 * @return
	 * @creator chuchanglin @ 2009-12-29
	 */
	public static boolean isTimeStyle(String time) {
		String test = "([1-9]\\d{3})-(([0][1-9])|([1][0-2]))-(([0][1-9])|([1-2]\\d)|([3][0-1]))\\s+([0][1-9]|[1]\\d|[2][0-3]):([0-5]\\d):([0-5]\\d)";
		Pattern pattern = Pattern.compile(test);
		Matcher matcher = pattern.matcher(time);

		return matcher.matches();
	}

	/**
	 * 获取位于双引号间的所有子字符串.
	 * 
	 * @param str
	 * @return
	 * @creator liushen @ Jan 29, 2010
	 */
	public static List<Substring> getSubstringsByQuote(String str) {
		Matcher matcher = patternQuote.matcher(str);
		List<Substring> lst = new ArrayList<Substring>();
		while (matcher.find()) {
			lst.add(new Substring(str, matcher.start(), matcher.end()));
		}
		return lst;
	}

	private static final Pattern patternQuote = Pattern.compile("\"[^\"]+\"");

}
