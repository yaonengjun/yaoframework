/**
 * Created: liushen@Feb 15, 2010 9:11:36 AM
 */
package com.trs.dev4.jdk16.utils;

import java.util.Random;

/**
 * 随机数工具方法集合.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class RandomUtil {

	/**
	 * 随机字符串的种子.
	 */
	private final static char[] STRING_SEEDS = { 'a', 'b', 'c', 'd', 'e',
			'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
			's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4',
			'5', '6', '7', '8', '9' };

	/**
	 * @param length
	 * @return
	 * @creator liushen @ Feb 15, 2010
	 */
	public static String generateRandomString(int length) {
		StringBuilder sb = new StringBuilder();
		Random aRandom = new Random();
		for (int i = 0; i < length; i++) {
			// 生成随机数，取绝对值，防止生成负数，
			int random = Math.abs(aRandom.nextInt(STRING_SEEDS.length)); // 生成的数最大为36-1
			sb.append(STRING_SEEDS[random]);
		}
		return sb.toString();
	}

}
