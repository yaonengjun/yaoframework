/*
 * Created: liushen@May 31, 2009 9:29:45 AM
 */
package com.trs.dev4.jdk16.utils;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.util.List;
import java.util.Properties;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceAlreadyExistsException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * JMX工具类.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class JMXUtil {

	private static final MBeanServer s_BeanServer = ManagementFactory
			.getPlatformMBeanServer();

	/**
	 * 
	 * @param beanName
	 * @param attrName
	 * @return
	 */
	public static final Object getAttribute(String beanName, String attrName) {
		try {
			return accessAttribute0(beanName, attrName);
		} catch (Exception e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * @param beanName
	 * @param attrName
	 * @return
	 * @throws MalformedObjectNameException
	 * @throws NullPointerException
	 * @throws MBeanException
	 * @throws AttributeNotFoundException
	 * @throws InstanceNotFoundException
	 * @throws ReflectionException
	 * @creator liushen @ May 31, 2009
	 */
	private static Object accessAttribute0(String beanName, String attrName)
			throws MalformedObjectNameException, NullPointerException,
			MBeanException, AttributeNotFoundException,
			InstanceNotFoundException, ReflectionException {
		ObjectName on = new ObjectName(beanName);
		return s_BeanServer.getAttribute(on, attrName);
	}

	/**
	 * 
	 * @param beanName
	 * @param attrName
	 * @return
	 */
	public static final long getAttrAsLong(String beanName, String attrName) {
		Object obj = getAttribute(beanName, attrName);
		if (obj instanceof Number) {
			return ((Number) obj).longValue();
		} else {
			return -1;
		}
	}

	/**
	 * 
	 * @param beanName
	 * @param attrName
	 * @return
	 */
	public static final double getAttrAsDouble(String beanName, String attrName) {
		Object obj = getAttribute(beanName, attrName);
		if (obj instanceof Number) {
			return ((Number) obj).doubleValue();
		} else {
			return -100.0;
		}
	}

	/**
	 * 通过OperatingSystemMXBean获取有用的系统信息.
	 * 
	 * @creator liushen @ Jun 5, 2009
	 */
	public static final Properties getOperatingSystemMXBeanInfo() {
		Properties info = new SortedProperties();

		OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();

		// Java 1.6
		addGetterIfAvaliable(os, "SystemLoadAverage", info);

		// com.sun.management.UnixOperatingSystemMXBean
		addGetterIfAvaliable(os, "OpenFileDescriptorCount", info);
		addGetterIfAvaliable(os, "MaxFileDescriptorCount", info);

		// com.sun.management.OperatingSystemMXBean
		addGetterIfAvaliable(os, "CommittedVirtualMemorySize", info);
		addGetterIfAvaliable(os, "TotalPhysicalMemorySize", info);
		addGetterIfAvaliable(os, "TotalSwapSpaceSize", info);
		addGetterIfAvaliable(os, "ProcessCpuTime", info);

		return info;
	}

	/**
	 * 获取JVM进程命令行中对虚拟机的参数.(不包括程序参数, 即主类后面的参数)
	 * 
	 * @since liushen @ Sep 3, 2009
	 */
	public static String getJVMInputArguments() {
		List<String> lstArguments = ManagementFactory.getRuntimeMXBean()
				.getInputArguments();
		StringBuilder sb = new StringBuilder();
		for (String arg : lstArguments) {
			sb.append(arg).append(" ");
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param mBeanName
	 * @param mBean
	 * @creator liushen @ Nov 8, 2009
	 */
	public static void registerMBean(String mBeanName, Object mBean) {
		try {
			s_BeanServer.registerMBean(mBean, new ObjectName(mBeanName));
		} catch (InstanceAlreadyExistsException e) {
			System.out.println("WARNING: The MBean: [" + mBeanName
					+ "] is already under the control of the MBean server");
		} catch (Exception e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * Try to run a getter function. This is useful because java 1.6 has a few
	 * extra useful functions on the <code>OperatingSystemMXBean</code>
	 * 
	 * @param obj
	 * @param getter
	 * @param info
	 * @creator liushen @ Jun 5, 2009
	 */
	private static void addGetterIfAvaliable(Object obj, String getter,
			Properties info) {
		String methodName = "get" + getter;
		try {
			Object v = ReflectUtil.invokePublicMethod(obj, methodName);
			if (v != null) {
				info.put(getter, v);
			}
		} catch (NoSuchMethodException e) {
			// don't worry this, because a few useful functions only in java 1.6
		} catch (Exception e) {
			throw new WrappedException("fail to invoke " + methodName
					+ "() on object " + obj + "!", e);
		}
	}

}
