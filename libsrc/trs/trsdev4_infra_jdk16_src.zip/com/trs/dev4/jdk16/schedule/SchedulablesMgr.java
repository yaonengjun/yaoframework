/*
 * Created: liushen@May 5, 2011 12:18:27 AM
 */
package com.trs.dev4.jdk16.schedule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.ClassUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;

/**
 * 计划调度管理. <br>
 * 
 */
public class SchedulablesMgr {

	private static final Logger LOG = Logger.getLogger(SchedulablesMgr.class);

	private Map<String, ScheduledExecutorService> schedulerMap = new HashMap<String, ScheduledExecutorService>();

	private List<ScheduleRunner> runners = new ArrayList<ScheduleRunner>();

	/**
	 * 
	 * @param schedulable
	 * @param fixedDelaySeconds
	 *            TODO RunCondition, subclass: FixedRate, FixedDelay, Cron
	 * @since liushen @ May 5, 2011
	 */
	public void start(ISchedulable schedulable, int fixedDelaySeconds) {
		String key = schedulable.getClass().getName();
		if (schedulerMap.containsKey(key)) {
			return;
		}

		int poolSize = 1;
		int initialDelay = 10;
		ScheduledExecutorService scheduler = SchedulerFactory.newScheduler(
				ClassUtil.getSimpleName(schedulable), poolSize);
		schedulerMap.put(key, scheduler);
		ScheduleRunner runner = new ScheduleRunner(schedulable, fixedDelaySeconds);
		runners.add(runner);
		scheduler.scheduleWithFixedDelay(runner,
				initialDelay, fixedDelaySeconds, TimeUnit.SECONDS);
	}

	/**
	 * 
	 * @param schedulable
	 * @since liushen @ May 5, 2011
	 */
	public void stop(ISchedulable schedulable) {
		String key = schedulable.getClass().getName();
		ScheduledExecutorService scheduler = schedulerMap.get(key);
		if (scheduler == null) {
			LOG.warn("no such ScheduledExecutorService: " + key);
			return;
		}
		scheduler.shutdown();
		List<Runnable> runnables = scheduler.shutdownNow();
		if (false == CollectionUtil.isEmpty(runnables)) {
			LOG.info("these tasks were awaiting execution: " + runnables);
		}
		LOG.info(key + " stopped.");
		runners.remove(new ScheduleRunner(schedulable, 0));
	}

	/**
	 * 
	 * 
	 * @since liushen @ May 6, 2011
	 */
	public void stopAll() {
		for (int i = 0; i < runners.size(); i++) {
			ScheduleRunner runner = runners.get(i);
			stop(runner.getSchedulable());
		}
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public List<ScheduleRunner> listRunners() {
		return runners;
	}

}