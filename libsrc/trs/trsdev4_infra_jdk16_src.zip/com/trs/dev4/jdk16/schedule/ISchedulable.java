/*
 * Created: liushen@May 5, 2011 12:14:55 AM
 */
package com.trs.dev4.jdk16.schedule;


/**
 * 对可调度的抽象. <br>
 * 
 */
public interface ISchedulable {

	/**
	 * 一次执行过程.
	 * 
	 * @since liushen @ May 5, 2011
	 */
	void runOnce();

	/**
	 * 返回对用户友好的显示名.
	 * 
	 * @since liushen @ May 6, 2011
	 */
	String getDisplayName();

	// /**
	// * 返回对用户友好的显示名，并且i18n/i10n.
	// * @since liushen @ May 6, 2011
	// */
	// String getDisplayName(Locale locale);

}
