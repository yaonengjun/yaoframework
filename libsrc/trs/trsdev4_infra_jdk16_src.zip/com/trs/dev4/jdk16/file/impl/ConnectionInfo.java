/*
 * Created: lichuanjiao@2010-9-8 下午03:37:22
 */
package com.trs.dev4.jdk16.file.impl;

import java.net.MalformedURLException;
import java.net.URL;

import com.trs.dev4.jdk16.exception.NoSuchResourceException;

/**
 * 职责: 封装连接信息的对象<br>
 * 
 */
public class ConnectionInfo {

	private String protocol;
	private String userName;
	private String password;
	private String host;
	private int port;
	private String file;
	private URL url;

	/**
	 * 通过url信息构造连接信息对象
	 * @param url 
	 */
	ConnectionInfo(String url) {
		try {
			this.url = new URL(url);
		} catch (MalformedURLException e) {
			throw new NoSuchResourceException(e);
		}
		this.protocol = this.url.getProtocol();
		this.userName = this.url.getUserInfo().split(":")[0];
		this.password = this.url.getUserInfo().split(":")[1];
		this.host = this.url.getHost();
		this.port = this.url.getPort();
		this.file = this.url.getFile();
	}

	/**
	 * @param userName
	 *            the {@link #userName} to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param password
	 *            the {@link #password} to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the {@link #protocol}
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * @return the {@link #userName}
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the {@link #password}
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the {@link #host}
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @return the {@link #port}
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @return the {@link #file}
	 */
	public String getFile() {
		return file;
	}

}
