/*
 * Created: lichuanjiao@2010-9-12 下午12:28:34
 */
package com.trs.dev4.jdk16.file.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.file.IFile;
import com.trs.dev4.jdk16.utils.FileUtil;

/**
 * 对本地文件的包装.<br>
 * 
 */
public class LocalFile extends BaseFile {

	private File file;

	LocalFile(File file) {
		this.file = file;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFile#length()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public long length() {
		return file.length();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canExecute()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public boolean canExecute() {
		return file.canExecute();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canRead()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public boolean canRead() {
		return file.canRead();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canWrite()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public boolean canWrite() {
		return file.canWrite();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getAbsolutePath()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public String getAbsolutePath() {
		return file.getAbsolutePath();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getName()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public String getName() {
		return file.getName();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getParent()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public String getParent() {
		return file.getParent();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isHidden()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public boolean isHidden() {
		return file.isHidden();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#lastModified()
	 * @since lichuanjiao @ 2010-9-12
	 */
	@Override
	public long lastModified() {
		return file.lastModified();
	}

	/**
	 * @param dirLocation
	 * @param exts
	 *            文件扩展名(不区分大小写); 如果不指定，则列出全部文件.
	 * @return
	 * @since liushen @ Apr 6, 2011
	 */
	public static List<IFile> listFiles(String dirLocation, String... exts) {
		List<File> files = FileUtil.listFilesInDir(new File(dirLocation), exts);
		List<IFile> wrappers = new ArrayList<IFile>(files.size());
		for (File file : files) {
			wrappers.add(new LocalFile(file));
		}
		return wrappers;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Apr 7, 2011
	 */
	public File getEnclosingFile() {
		return file;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isFolder()
	 * @since liushen @ Apr 15, 2011
	 */
	@Override
	public boolean isFolder() {
		return file.isDirectory();
	}

}
