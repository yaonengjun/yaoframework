/*
 * Created: liushen@Jun 8, 2010 9:44:32 AM
 */
package com.trs.dev4.jdk16.file;

/**
 * 各类本地目录、远程目录的统一接口，便于统一处理. <br>
 * 注：增删移等写入操作，由基于此接口的工具类统一提供，不应在该接口中直接提供！
 */
public interface IDirectory extends IFileResource {

	/**
	 * 列出该目录下的文件.
	 * 
	 * @return 字符串表示的文件全路径构成的数组
	 * @since liushen @ Jun 8, 2010
	 */
	String[] list();

	/**
	 * 按扩展名，列出该目录下的文件.
	 * 
	 * @param fileExt
	 *            扩展名
	 * @return 字符串表示的文件全路径构成的数组
	 * @since liushen @ Jun 8, 2010
	 */
	String[] list(String fileExt);

	// TODO: liushen@Jun 8, 2010: 抽取IPartition接口？
	/**
	 * 所在分区的空闲空间.
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	long getFreeSpace();

	/**
	 * 所在分区的总空间.
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	long getTotalSpace();

	/**
	 * 所在分区的可用空间.
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	long getUsableSpace();

}
