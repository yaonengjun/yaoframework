/*
 * Created: dujie@2011-10-12 下午04:13:41
 */
package com.trs.dev4.jdk16.verifycode.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.verifycode.IVerifyCodeProvider;
import com.trs.dev4.jdk16.verifycode.VerifyCodeConst;

/**
 * 职责: <br>
 * 数字类型验证码提供类实现
 */
public class NumberVerifyCodeProvider implements IVerifyCodeProvider {
	/**
	 * 随机数
	 */
	private final Random imgGenerator = new Random();

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeProvider#getRandomVerifyCode(int, java.lang.String)
	 * @since dujie @ 2011-10-12
	 */
	public Captcha getRandomVerifyCode(int length, String verifyCodeType) {
		Captcha captcha = new Captcha();
		String radomVerifyCode = this.generateVerifyCode(length, verifyCodeType);
		captcha.setAnswer(radomVerifyCode);
		captcha.setQuestion(radomVerifyCode);
		captcha.setChinese(false);
		return captcha;
	}

	/**
	 * 生成验证码
	 * 
	 * @param length 验证码长度.
	 * @param verifyCodeType 验证码类型.可以是数字、大写字母、小写字母，或是它们三种的任意组合,分别用不同的标识来表示. <br>
	 *            1 ： 数字(0~9) 2 : 小写字母 3 : 大写字母 4 : 数字 + 小写字母 5 : 数字 + 大写字母 6 : 小写字母 + 大写字母 7 : 数字 + 小写字母 + 大写字母 <br>
	 *            需要哪种类型验证码，输入对应的标识即可。
	 * @return 返回验证码
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private String generateVerifyCode(int length, String verifyCodeType) {
		String verifyCode = "";
		for (int i = 0; i < length; i++) {
			verifyCode += getSingalVerifyCode(verifyCodeType);
		}
		return verifyCode;
	}

	/**
	 * 获取单个验证码字符
	 * 
	 * @param verifyCodeType 验证码内容
	 * @return 单个验证码字符
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private char getSingalVerifyCode(String verifyCodeType) {

		Object contentObj = verifyCodeTypeMap.get(verifyCodeType);
		if (contentObj == null)
			contentObj = verifyCodeTypeMap.get(VerifyCodeConst.NUMBERS);
		char[] verifyCodeStrs = (char[]) contentObj;
		int car = verifyCodeStrs.length - 1;
		return verifyCodeStrs[imgGenerator.nextInt(car) + 1];
	}

	/**
	 * 验证码类型
	 */
	private final Map<String, char[]> verifyCodeTypeMap = new HashMap<String, char[]>();

	{
		verifyCodeTypeMap.put(VerifyCodeConst.NUMBERS, VerifyCodeConst.numbers);
		verifyCodeTypeMap.put(VerifyCodeConst.SMALLLETTERS, VerifyCodeConst.smallLetters);
		verifyCodeTypeMap.put(VerifyCodeConst.BIGLETTERS, VerifyCodeConst.bigLetters);
		verifyCodeTypeMap.put(VerifyCodeConst.NUMBERS_SAMLLLETTERS, VerifyCodeConst.numbers_smallLetters);
		verifyCodeTypeMap.put(VerifyCodeConst.NUMBERS_BIGLETTERS, VerifyCodeConst.numbers_bigLetters);
		verifyCodeTypeMap.put(VerifyCodeConst.SAMLLLETTERS_BIGLETTERS, VerifyCodeConst.smallLetters_bigLetters);
		verifyCodeTypeMap.put(VerifyCodeConst.NUMBERS_SAMLLLETTERS_BIGLETTERS, VerifyCodeConst.numbers_smallLetters_bigLetters);
	}
}
