package com.trs.dev4.jdk16.verifycode;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 * 生成混合类型验证码
 */
public class MixVerifyCodeServlet extends HttpServlet {

	/**
	 * 序列号
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 应用上下文
	 * 
	 * @since dujie @ 2011-10-14
	 */
	private WebApplicationContext webAppContext;

	/**
	 * 日志对象
	 */
	private static final Logger logger = Logger.getLogger(MixVerifyCodeServlet.class);

	/**
	 * 验证码的扭曲度
	 */
	private int torsionResistance;

	/**
	 * 噪音指数
	 */
	private int noiseLevel;

	/**
	 * 验证码长度
	 */
	private int length;

	/**
	 * 背景图片宽度
	 */
	private int pictureWidth;

	/**
	 * 背景图片高度
	 */
	private int pictureHeight;

	/**
	 * 验证类型（问答、中文、数字&英文字符验证码类型）
	 */
	private String verifyCodeType;

	/**
	 * 验证码字体大小
	 */
	private int fontSize;

	/**
	 * 应用名
	 * 
	 * @since dujie @ 2011-10-12
	 */
	private String appName;

	/**
	 * 验证码服务
	 * 
	 * @since dujie @ 2011-10-12
	 */
	private IVerifyCodeService verifyCodeService;

	/*
	 * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
	 */
	@Override
	public void init(ServletConfig config) throws ServletException {

		super.init(config);

		webAppContext = WebApplicationContextUtils.getWebApplicationContext(config.getServletContext());
		verifyCodeService = (IVerifyCodeService) webAppContext.getBean("verifyCodeService");

		buildConfiguration(config);
	}

	/**
	 * @param config 创建配置信息
	 * @since dujie @ 2011-10-31
	 */
	private void buildConfiguration(ServletConfig config) {
		// 获取验证码属性信息
		String torsionResistanceStrTag = getConfig(config, "torsionResistance", "low");
		this.torsionResistance = this.getTorsionResistance(torsionResistanceStrTag);

		String noiseLevelStrTag = getConfig(config, "noiseLevel", "low");
		this.noiseLevel = this.getNoiseLevel(noiseLevelStrTag);

		String fontSizeStr = getConfig(config, "fontSize", "16");
		this.fontSize = this.getFontSize(fontSizeStr);

		String lengthStr = getConfig(config, "length", "4");
		this.length = this.getLength(lengthStr);

		String pictureWidthStr = getConfig(config, "pictureWidth", "80");
		this.pictureWidth = this.getPictureWidth(pictureWidthStr);

		String pictureHeightStr = getConfig(config, "pictureHeight", "40");
		this.pictureHeight = this.getPictureHeight(pictureHeightStr);

		this.verifyCodeType = getConfig(config, "verifyCodeType", "1");

		String appNameStr = getConfig(config, "appName", "");
		this.appName = this.getAppName(appNameStr);

		if (logger.isDebugEnabled()) {
			logger.debug("MixVerifyCodeServlet initing finished! torsionResistance=[" + this.torsionResistance + "],noiseLevel=["
					+ this.noiseLevel
					+ "],length=[" + this.length + "],content=[" + this.verifyCodeType + "]");
		}
	}

	/**
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {

		try {
			appName = RequestUtil.getParameter(request, "appName", "");
			if (logger.isDebugEnabled()) {
				logger.debug("appName=[" + appName + "]");
			}
		} catch (Exception e1) {
			logger.error("doGet appName[" + appName + "] error!", e1);
		}

		buildConfiguration(null);

		// 生成随机验证码
		Captcha captcha = generateVerifyCode();
		// 返回验证码
		try {
			writeToResponse(request, response, captcha);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * @param config Servlet配置
	 * @param name 配置名称
	 * @param defaultValue 默认配置
	 * @return 验证码配置
	 * @since dujie @ 2011-10-14
	 */
	private String getConfig(ServletConfig config, String name, String defaultValue) {
		String sysConfig = getSysConfig(appName, name);
		if (StringHelper.isEmpty(sysConfig)) {
			if (config == null) {
				return defaultValue;
			} else {
				return config.getInitParameter(name);
			}
		}
		return sysConfig;
	}

	/**
	 * 获取系统配置功能 重载后可从自定义的系统配置中读取配置，不必每次都修改web.xml
	 * 
	 * @param name 配置名称
	 * @return 系统配置
	 * @since dujie @ 2011-10-14
	 */
	protected String getSysConfig(String appName, String name) {
		return null;
	}

	/**
	 * 将验证码写入到响应中
	 * 
	 * @param request HTTP请求
	 * @param response HTTP响应
	 * @param captcha 验证码
	 * @throws IOException IO异常
	 * @since dujie @ 2011-10-14
	 */
	private void writeToResponse(HttpServletRequest request, HttpServletResponse response, Captcha captcha) throws IOException {

		writeVerifyCodeToResponse(request, response, captcha);

		writePicToResponse(response, captcha);

	}

	/**
	 * 生成验证码
	 * 
	 * @return 验证码
	 * @since dujie @ 2011-10-14
	 */
	private Captcha generateVerifyCode() {

		Captcha captcha = this.verifyCodeService.buildCaptcha(length, verifyCodeType);
		if (logger.isDebugEnabled()) {
			logger.debug("verifyCode=[" + captcha.getQuestion() + "]");
		}
		return captcha;
	}

	/**
	 * 将验证码存入session,如果是IDS3.0,重写此方法放入IDS的SSOSESION里.
	 * 
	 * @param request HTTP请求
	 * @param response HTTP相应
	 * @param captcha
	 * @since dujie @ 2011-10-14
	 */
	protected void writeVerifyCodeToResponse(HttpServletRequest request, HttpServletResponse response, Captcha captcha) {
		response.setContentType("image/jpeg");
		request.getSession().setAttribute("verifyCode", captcha.getAnswer().toString());
	}

	/**
	 * 得到验证码图片，写入输出流
	 * 
	 * @param response HTTP响应
	 * @param captcha 验证码
	 * @throws IOException IO异常
	 * @since dujie @ 2011-10-14
	 */
	private void writePicToResponse(HttpServletResponse response, Captcha captcha) throws IOException {
		BufferedImage image = this.verifyCodeService
				.drawVerifyCodeToPicture(captcha.getQuestion(), captcha.isChinese(), this.noiseLevel, this.torsionResistance, fontSize,
				pictureWidth, pictureHeight);
		response.setContentType("image/jpeg");
		ImageIO.write(image, "JPEG", response.getOutputStream());
	}

	/**
	 * 获取应用名
	 * 
	 * @param appNameStr 应用名(bbs,blog,survey等)
	 * @return 应用名 默认为all所有
	 * @since dujie @ 2011-10-12
	 */
	private String getAppName(String appNameStr) {
		if (StringHelper.isEmpty(appNameStr)) {
			return "all";
		}
		return appNameStr;
	}

	/**
	 * 获取参数
	 * 
	 * @param torsionResistance 扭曲度标识，扭曲分为高、中、低三种。分别用high、mid、low来表示。
	 * @return 验证码扭曲度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private int getTorsionResistance(String torsionResistance) {
		if (torsionResistance == null || "".equals(torsionResistance))
			return VerifyCodeConst.MIX_TORSIONRESISTANCE_LOW;
		if ("high".equalsIgnoreCase(torsionResistance))
			return VerifyCodeConst.MIX_TORSIONRESISTANCE_HEIGHT;
		if ("mid".equalsIgnoreCase(torsionResistance))
			return VerifyCodeConst.MIX_TORSIONRESISTANCE_MIDDLE;
		if ("low".equalsIgnoreCase(torsionResistance))
			return VerifyCodeConst.MIX_TORSIONRESISTANCE_LOW;
		return VerifyCodeConst.MIX_TORSIONRESISTANCE_LOW;
	}

	/**
	 * 获取验证码的噪音级别
	 * 
	 * @param noiseLevel 验证码的噪音级别标识，噪音级别分为高、中、低三种。分别用high、mid、low来表示。
	 * @return 验证码的噪音级别
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private int getNoiseLevel(String noiseLevel) {
		if (noiseLevel == null || "".equals(noiseLevel))
			return VerifyCodeConst.MIX_NOISE_LEVEL_LOW;
		if ("high".equalsIgnoreCase(noiseLevel))
			return VerifyCodeConst.MIX_NOISE_LEVEL_HEIGHT;
		if ("mid".equalsIgnoreCase(noiseLevel))
			return VerifyCodeConst.MIX_NOISE_LEVEL_MIDDLE;
		if ("low".equalsIgnoreCase(noiseLevel))
			return VerifyCodeConst.MIX_NOISE_LEVEL_LOW;
		return VerifyCodeConst.MIX_NOISE_LEVEL_LOW;
	}

	/**
	 * 获取验证码长度
	 * 
	 * @param length 验证码长度，长度范围：4～9
	 * @return 验证码长度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private int getLength(String length) {
		if (length == null || "".equals(length))
			return 4;
		int lengthInt = new Integer(length).intValue();
		if (lengthInt > 3 && lengthInt < 10)
			return lengthInt;
		return 4;
	}

	/**
	 * 获取背景图片宽度
	 * 
	 * @param pictureWidth 背景图片宽度
	 * @return 背景图片宽度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-6-3
	 */
	private int getPictureWidth(String pictureWidth) {
		if (pictureWidth == null || "".equals(pictureWidth))
			return 195;
		int pictureWidthInt = new Integer(pictureWidth).intValue();
		if (pictureWidthInt > 195 || pictureWidthInt < 80)
			return 195;
		return pictureWidthInt;
	}

	/**
	 * 获取背景图片高度
	 * 
	 * @param pictureHeight 背景图片高度
	 * @return 背景图片高度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-6-3
	 */
	private int getPictureHeight(String pictureHeight) {
		if (pictureHeight == null || "".equals(pictureHeight))
			return 80;
		int pictureHeightInt = new Integer(pictureHeight).intValue();
		if (pictureHeightInt > 80 || pictureHeightInt < 40)
			return 80;
		return pictureHeightInt;
	}

	/**
	 * 获取验证码字体大小
	 * 
	 * @param fontSize 验证码字体大小
	 * @return 验证码字体大小
	 * @since v3.5
	 * @creator yanghongwu @ 2010-10-29
	 */
	private int getFontSize(String fontSize) {
		if (fontSize == null || "".equals(fontSize))
			return 27;
		return new Integer(fontSize).intValue();
	}
}
