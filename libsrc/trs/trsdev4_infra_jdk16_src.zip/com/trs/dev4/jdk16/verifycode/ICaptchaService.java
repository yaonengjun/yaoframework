package com.trs.dev4.jdk16.verifycode;

import java.util.List;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.example.Captcha;

/**
 * 职责: <br>
 * 问答式验证服务接口
 * 
 */
public interface ICaptchaService {

	/**
	 * 分页获取验证回答列表
	 * 
	 * @param searchFilter
	 *            对SQL查询条件的封装
	 * @return Captcha分页对象
	 * @since dujie @ 2011-10-12
	 */
	PagedList<Captcha> pagedCaptchas(SearchFilter searchFilter);

	/**
	 * 保存或更新验证问答对象
	 * 
	 * @param captcha
	 *            验证问答对象
	 * @since dujie @ 2011-10-12
	 */
	void saveOrUpdate(Captcha captcha);

	/**
	 * 限制输入长度
	 * 
	 * @param context
	 *            输入内容
	 * @param length
	 *            限制长度
	 * @return 被截取后的内容
	 * @since dujie @ 2011-10-12
	 */
	String validate(String context, int length);

	/**
	 * 获取验证问答对象
	 * 
	 * @param captchaId
	 *            验证问答对象Id
	 * @return 验证问答对象
	 * @since dujie @ 2011-10-12
	 */
	Captcha getCaptcha(int captchaId);

	/**
	 * 批量删除验证回答对象
	 * 
	 * @param ids
	 *            验证回答对象的id数组
	 * @param user
	 *            执行删除操作的用户
	 */
	void deleteCaptchas(int[] ids);

	/**
	 * 获取验证问答对象列表
	 * 
	 * @param searchFilter
	 *            查询参数
	 * @return 验证问答对象列表
	 * @since dujie @ 2011-10-12
	 */
	List<Captcha> listCaptchas(SearchFilter searchFilter);

	/**
	 * 返回随机的验证问答对象
	 * 
	 * @return 验证问答对象
	 * @since dujie @ 2011-10-12
	 */
	Captcha getRandomCaptcha();

}
