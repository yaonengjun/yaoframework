/*
 * Created: dujie@2011-10-12 下午01:58:20
 */
package com.trs.dev4.jdk16.verifycode;

import com.trs.dev4.jdk16.model.example.Captcha;

/**
 * 职责: <br>
 * 验证码提供接口
 * 
 */
public interface IVerifyCodeProvider {
	/**
	 * 获取随机的验证码
	 * 
	 * @param length
	 *            验证码长度
	 * @param verifyCodeType
	 *            验证码类别
	 * 
	 * @return 验证码
	 * @since dujie @ 2011-10-12
	 */
	public Captcha getRandomVerifyCode(int length, String verifyCodeType);
}
