package com.trs.dev4.jdk16.verifycode;

/**
 * 验证码基本常量定义
 * 
 * @since v3.5
 * @creator yanghongwu@2010-4-9
 */
public class VerifyCodeConst {

	// ----------------------噪音级别---------------------------------------

	public static final int MIX_NOISE_LEVEL_LOW = 400;

	public static final int MIX_NOISE_LEVEL_MIDDLE = 600;

	public static final int MIX_NOISE_LEVEL_HEIGHT = 1000;

	// -----------------------扭曲度-----------------------------------------

	public static final int MIX_TORSIONRESISTANCE_LOW = 10;

	public static final int MIX_TORSIONRESISTANCE_MIDDLE = 20;

	public static final int MIX_TORSIONRESISTANCE_HEIGHT = 30;

	/**
	 * 纯数字
	 */
	public static final String NUMBERS = "1";

	/**
	 * 小写字母
	 */
	public static final String SMALLLETTERS = "2";

	/**
	 * 大写字母
	 */
	public static final String BIGLETTERS = "3";

	/**
	 * 数字 + 小写字母
	 */
	public static final String NUMBERS_SAMLLLETTERS = "4";

	/**
	 * 数字 + 大写字母
	 */
	public static final String NUMBERS_BIGLETTERS = "5";

	/**
	 * 小写字母 + 大写字母
	 */
	public static final String SAMLLLETTERS_BIGLETTERS = "6";

	/**
	 * 数字 +小写字母 + 大写字母
	 */
	public static final String NUMBERS_SAMLLLETTERS_BIGLETTERS = "7";

	/**
	 * 中文
	 */
	public static final String CHINIESE = "8";
	/**
	 * 问答式
	 */
	public static final String QUESTION_ANSWER = "9";
	/**
	 * 纯数字
	 */
	public static char[] numbers = new char[] { '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9' };

	/**
	 * 小写字母
	 */
	public static char[] smallLetters = new char[] { 'a', 'b', 'c', 'd', 'e',
			'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
			's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	/**
	 * 大写字母
	 */
	public static char[] bigLetters = new char[] { 'A', 'B', 'C', 'D', 'E',
			'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
			'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

	/**
	 * 数字 + 小写字母
	 */
	public static char[] numbers_smallLetters = new char[] { '2', '3', '4',
			'5', '7', '8', 'a', 'c', 'd', 'e', 'f', 'h', 'i', 'j', 'k', 'm',
			'n', 'p', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	/**
	 * 数字 + 大写字母
	 */
	public static char[] numbers_bigLetters = new char[] { '1', '2', '3', '4',
			'5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
			'I', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
			'W', 'X', 'Y', 'Z' };

	/**
	 * 小写字母 + 大写字母
	 */
	public static char[] smallLetters_bigLetters = new char[] { 'a', 'b', 'c',
			'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
			'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C',
			'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
			'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

	/**
	 * 数字 + 小写字母 + 大写字母
	 */
	public static char[] numbers_smallLetters_bigLetters = new char[] { '2',
			'3', '4', '5', '7', '8', 'a', 'c', 'd', 'e', 'f', 'h', 'i', 'j',
			'k', 'm', 'n', 'p', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
			'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
			'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

}
