package com.trs.dev4.jdk16.verifycode.impl;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.font.TextAttribute;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;
import java.text.AttributedString;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.verifycode.IVerifyCodeGenerator;

/**
 * 混合类型验证码生成器 生成图片·提供验证码
 * 
 * @since v3.5
 * @creator yanghongwu@2010-4-9
 */
@Service
public class VerifyCodeGenerator implements IVerifyCodeGenerator {

	private static final Logger logger = Logger.getLogger(VerifyCodeGenerator.class);
	/**
	 * 验证码字体大小
	 */
	private int fontSize;

	/**
	 * 随机数
	 */
	private final Random imgGenerator = new Random();

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeGenerator#drawVerifyCodeToPicture(java.io.Serializable,
	 *      int, int, int, int, int)
	 * @since dujie @ 2011-10-12
	 */
	public BufferedImage drawVerifyCodeToPicture(Serializable verifyCode, boolean isChinese, int noiseLevel, int torsionResistance, int fontSize, int pictureWidth, int pictureHeight)
			throws IOException {

		this.fontSize = fontSize;
		String code = verifyCode.toString();
		if (logger.isDebugEnabled()) {
			logger.debug("Draw verifyCode[" + code + "] to pictrue.");
		}
		BufferedImage image = drawChar(code, isChinese, null, noiseLevel, torsionResistance, pictureWidth, pictureHeight);
		return image;
	}

	/**
	 * 指定字体，生成基于AWT的带有验证码的图片
	 * 
	 * @param verifyCode 验证码
	 * @param font 验证码使用的字体 使用的字体可以传入空值，传入空值时，表示不指定字体，随机从系统字体中选取
	 * @param noiseLevel 噪音级别
	 * @param torsionResistance 扭曲度
	 * @param pictureWidth 图片的宽度
	 * @param pictrueHeight 图片的高度
	 * @return BufferedImage实例对象
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private BufferedImage drawChar(String verifyCode, boolean isChinese, Font font, int noiseLevel, int torsionResistance, int pictureWidth, int pictrueHeight) {
		BufferedImage bi = new BufferedImage(getWidth(pictureWidth), getHeight(pictrueHeight), BufferedImage.TYPE_BYTE_INDEXED);
		Graphics2D graphics = bi.createGraphics();
		// 设置背景色
		graphics.setColor(Color.white);
		graphics.fillRect(0, 0, bi.getWidth(), bi.getHeight());
		graphics.setColor(Color.black);
		for (int i = 0; i < noiseLevel; i++) {
			graphics.setColor(getRandColor());
			graphics.drawRect(imgGenerator.nextInt(320), imgGenerator.nextInt(100), 1, 1);
		}
		AffineTransform fontAT = new AffineTransform();
		fontAT.shear(+3.0, -2.0);
		fontAT.rotate(Math.toRadians(imgGenerator.nextInt(10)));
		fontAT.scale(0.8, 2.0);
		AttributedString as = new AttributedString(verifyCode);
		for (int i = 0; i < verifyCode.length(); i++) {
			Font actualFont = font == null ? getRandomFontFromSelectedOnLinux(isChinese) : font;
			as.addAttribute(TextAttribute.FONT, actualFont, i, i + 1);
			as.addAttribute(TextAttribute.FOREGROUND, getRandColor(), i, i + 1);
			as.addAttribute(TextAttribute.TRANSFORM, fontAT, i, i + 1);
			as.addAttribute(TextAttribute.WIDTH, new Integer(imgGenerator.nextInt(1) * 10 + 20), i, i + 1);
			as.addAttribute(TextAttribute.STRIKETHROUGH, new Boolean(imgGenerator.nextInt(2) == 1), i, i + 1);
			as.addAttribute(TextAttribute.SUPERSCRIPT, imgGenerator.nextInt(2) == 1 ? TextAttribute.SUPERSCRIPT_SUB
 : TextAttribute.SUPERSCRIPT_SUPER, i, i + 1);
		}
		int w = bi.getWidth();
		int h = bi.getHeight();
		graphics.drawString(as.getIterator(), 10 + imgGenerator.nextInt(1) * 10, h / 2 + 15);
		shear(graphics, w, h, Color.white, torsionResistance);
		return bi;
	}

	/**
	 * 获取中文字体库
	 * 
	 * @return
	 * @since TRS信息技术股份有限公司 @ Jun 14, 2012
	 */
	private Font[] getChineseFont() {
		int fontStyle = Font.PLAIN;
		Font[] font = new Font[4];
		font[0] = new Font("AR PL SungtiL GB", fontStyle, fontSize);
		font[1] = new Font("DongWen--Song", fontStyle, fontSize);
		font[2] = new Font("AR PL New Sung", fontStyle, fontSize);
		font[3] = new Font("AR PL ShanHeiSun Uni", fontStyle, fontSize);
		return font;
	}

	/**
	 * 随机取linux系统中所有的字体
	 * 
	 * @return Font的实例对象
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private Font getRandomFontFromSelectedOnLinux(boolean isChinese) {
		Random random = new Random();
		Font[] font = (isChinese ? getChineseFont() : getAllSelectedFontsOnLinux());
		Font result = font[random.nextInt(font.length)];
		return result;
	}

	/**
	 * 随机产生定义的颜色
	 * 
	 * @return 随机产生定义的颜色
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private Color getRandColor() {
		Random random = new Random();
		Color color[] = new Color[10];
		color[0] = new Color(32, 158, 25);
		color[1] = new Color(218, 42, 19);
		color[2] = new Color(31, 75, 208);
		return color[random.nextInt(3)];
	}

	/**
	 * 设置扭曲度
	 * 
	 * @param g 图形对象
	 * @param w1 宽度
	 * @param h1 高度
	 * @param color 颜色
	 * @param torsionResistance 扭曲度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private void shear(Graphics g, int w1, int h1, Color color, int torsionResistance) {
		shearX(g, w1, h1, color);
		shearY(g, w1, h1, color, torsionResistance);
	}

	/**
	 * 设置X轴扭曲度
	 * 
	 * @param g 图形对象
	 * @param w1 宽度
	 * @param h1 高度
	 * @param color 颜色
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private void shearX(Graphics g, int w1, int h1, Color color) {
		int period = imgGenerator.nextInt(2);
		boolean borderGap = true;
		int frames = 10;
		int phase = imgGenerator.nextInt(2);

		for (int i = 0; i < h1; i++) {
			double d = (period >> 1) * Math.sin((double) i / (double) period + (6.2831853071795862D * phase) / frames);
			g.copyArea(0, i, w1, 1, (int) d, 0);
			if (borderGap) {
				g.setColor(color);
				g.drawLine((int) d, i, 0, i);
				g.drawLine((int) d + w1, i, w1, i);
			}
		}

	}

	/**
	 * 设置Y轴扭曲度
	 * 
	 * @param g 图形对象
	 * @param w1 宽度
	 * @param h1 高度
	 * @param color 颜色
	 * @param torsionResistance 扭曲度
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private void shearY(Graphics g, int w1, int h1, Color color, int torsionResistance) {
		int period = imgGenerator.nextInt(torsionResistance) + 20; // 50
		boolean borderGap = true;
		int frames = 20;
		int phase = 10;
		for (int i = 0; i < w1; i++) {
			double d = (period >> 1) * Math.sin((double) i / (double) period + (6.2831853071795862D * phase) / frames);
			g.copyArea(i, 0, 1, h1, 0, (int) d);
			if (borderGap) {
				g.setColor(color);
				g.drawLine(i, (int) d, i, 0);
				g.drawLine(i, (int) d + h1, i, h1);
			}

		}
	}

	/**
	 * 获取linux上的字体集合
	 * 
	 * @return 字体数组
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	private Font[] getAllSelectedFontsOnLinux() {
		int fontStyle = Font.PLAIN;
		Font[] font = new Font[31];
		font[0] = new Font("AR PL ShanHeiSun Uni", fontStyle, fontSize);
		font[1] = new Font("AR PL ZenKai Uni", fontStyle, fontSize);
		font[2] = new Font("Bitstream Charter Bold", fontStyle, fontSize);
		font[3] = new Font("Bitstream Charter Italic", fontStyle, fontSize);
		font[4] = new Font("Bitstream Vera Sans", fontStyle, fontSize);
		font[5] = new Font("Bitstream Vera Sans Bold1", fontStyle, fontSize);
		font[6] = new Font("Bitstream Vera Sans Bold Oblique", fontStyle, fontSize);
		font[7] = new Font("Bitstream Vera Sans Mono1", fontStyle, fontSize);
		font[8] = new Font("Bitstream Vera Sans Mono Bold", fontStyle, fontSize);
		font[9] = new Font("Bitstream Vera Sans Mono Bold Oblique", fontStyle, fontSize);
		font[10] = new Font("Bitstream Vera Sans Mono Oblique", fontStyle, fontSize);
		font[11] = new Font("Bitstream Vera Serif Bold", fontStyle, fontSize);
		font[12] = new Font("Century Schoolbook L Bold", fontStyle, fontSize);
		font[13] = new Font("Century Schoolbook L Italic", fontStyle, fontSize);
		font[14] = new Font("Century Schoolbook L Bold Italic", fontStyle, fontSize);
		font[15] = new Font("Courier 10 Pitch Bold", fontStyle, fontSize);
		font[16] = new Font("Courier Italic", fontStyle, fontSize);
		font[17] = new Font("Courier Bold Italic", fontStyle, fontSize);
		font[18] = new Font("DejaVu LGC Sans ExtraLight", fontStyle, fontSize);
		font[19] = new Font("DejaVu LGC Sans Mono", fontStyle, fontSize);
		font[20] = new Font("DejaVu LGC Serif Bold", fontStyle, fontSize);
		font[21] = new Font("DejaVu LGC Serif Condensed Bold Oblique", fontStyle, fontSize);
		font[22] = new Font("DialogInput.italic", fontStyle, fontSize);
		font[23] = new Font("Luxi Serif Bold", fontStyle, fontSize);
		font[24] = new Font("Monospaced.bold", fontStyle, fontSize);
		font[25] = new Font("Nimbus Mono L Regular", fontStyle, fontSize);
		font[26] = new Font("Nimbus Roman No9 L Bold", fontStyle, fontSize);
		font[27] = new Font("Nimbus Sans L Bold Italic", fontStyle, fontSize);
		font[28] = new Font("URW Bookman L Demi Bold Italic", fontStyle, fontSize);
		font[29] = new Font("URW Chancery L Medium Italic", fontStyle, fontSize);
		font[30] = new Font("URW Palladio L Bold Italic", Font.PLAIN, fontSize);

		return font;
	}

	/**
	 * 获取验证码图片的高度.<br>
	 * 根据扭曲度设置验证码图片的高度.
	 * 
	 * @param pictureHeight 验证码图片的高度
	 * @return 验证码图片的高度
	 * @since dujie @ 2011-10-13
	 */
	private int getHeight(int pictureHeight) {
		return (pictureHeight < 40 || pictureHeight > 80) ? 80 : pictureHeight;
	}

	/**
	 * 获取验证码图片的宽度.<br>
	 * 根据验证码的长度设置验证码图片的宽度.
	 * 
	 * @param pictureWidth 验证码图片的宽度
	 * @return 验证码图片的宽度
	 * @return
	 * @since dujie @ 2011-10-13
	 */
	private int getWidth(int pictureWidth) {
		return (pictureWidth < 80 || pictureWidth > 195) ? 195 : pictureWidth;
	}
}
