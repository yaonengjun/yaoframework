package com.trs.dev4.jdk16.verifycode;

import java.util.List;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IBaseManager;
import com.trs.dev4.jdk16.model.example.Captcha;

/**
 * 职责: <br>
 * 问答式验证码管理接口
 * 
 */
public interface ICaptchaManager extends IBaseManager<Captcha> {

	/**
	 * 保存或更新验证码
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 * @since dujie @ 2011-10-13
	 */
	void saveOrUpdate(Captcha captcha);

	/**
	 * 删除验证码
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#delete(com.trs.dev4.jdk16.model.IEntity)
	 * @since dujie @ 2011-10-13
	 */
	void delete(Captcha captcha);

	/**
	 * 获取的验证码对象
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#get(int)
	 * @since dujie @ 2011-10-13
	 */
	Captcha get(int captchaId);

	/**
	 * 获取验证问答对象列表
	 * 
	 * @param searchFilter
	 *            查询参数
	 * @return 验证问答对象列表
	 * @since dujie @ 2011-10-12
	 */
	List<Captcha> listCaptchas(SearchFilter searchFilter);

	/**
	 * 分页获取验证回答列表
	 * 
	 * @param searchFilter
	 *            对SQL查询条件的封装
	 * @return Captcha分页对象
	 * @since dujie @ 2011-10-12
	 */
	public PagedList<Captcha> pagedCaptchas(SearchFilter searchFilter);

}
