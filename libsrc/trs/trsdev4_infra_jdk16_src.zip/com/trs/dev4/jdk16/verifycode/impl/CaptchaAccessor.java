/*
 * Created: dujie@2011-10-13 下午05:51:19
 */
package com.trs.dev4.jdk16.verifycode.impl;

import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.hb3.AnnotationGenericBaseDAO;
import com.trs.dev4.jdk16.model.example.Captcha;

/**
 * 
 * 职责: <br>
 * 验证码访问Accessor实现
 * 
 */
@Service
public class CaptchaAccessor extends AnnotationGenericBaseDAO<Captcha> implements IAccessor<Captcha> {

	/**
	 * 默认构造方法
	 */
	public CaptchaAccessor() {
		super(Captcha.class);
	}

}
