/*
 * Created: Administrator@2011-6-30 下午05:58:48
 */
package com.trs.dev4.jdk16.xss;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * 职责:解决XSS的request <br>
 * 
 */
public class AntiXSSRequest extends HttpServletRequestWrapper {

	/**
	 * @param request
	 */
	public AntiXSSRequest(HttpServletRequest request) {
		super(request);
	}

	/**
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameter(java.lang.String)
	 * @since Administrator @ 2011-6-30
	 */
	@Override
	public String getParameter(String paramName) {
		return SafeHtmlUtil.getSafeHtml(super.getParameter(paramName));

	}

	/**
	 * 
	 * @see javax.servlet.http.HttpServletRequestWrapper#getQueryString()
	 * @since Administrator @ 2011-6-30
	 */
	@Override
	public String getQueryString() {
		return SafeHtmlUtil.getSafeHtml(super.getQueryString());
	}
	
	@Override
	public String getHeader(String string) {
		return SafeHtmlUtil.getSafeHtml(super.getHeader(string));
	}

	public String getParameterAsDefaultVal(String name) {
		return super.getParameter(name);
	}

}
