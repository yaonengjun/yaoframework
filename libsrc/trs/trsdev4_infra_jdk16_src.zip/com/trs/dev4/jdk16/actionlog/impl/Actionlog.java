package com.trs.dev4.jdk16.actionlog.impl;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.actionlog.IActionlog;
import com.trs.dev4.jdk16.actionlog.LogEnums.Level;
import com.trs.dev4.jdk16.actionlog.LogEnums.Result;
import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 
 * 日志领域对象
 * 
 */
@Entity
@Table(name = "`ACTIONLOGS`")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_ACTIONLOG") })
public class Actionlog extends BaseEntity implements IActionlog {

	private static final long serialVersionUID = -1435378662692038536L;

	/**
	 * 日志级别
	 */
	@Column(name = "`LOGLEVEL`")
	@Enumerated(value = EnumType.STRING)
	private Level logLevel;

	/**
	 * 被操作对象id
	 */
	@Column(name = "`OBJID`")
	private int objId;

	/**
	 * 被操作对象的可读标识
	 * 
	 * @since yaonengjun @ 2012-8-23
	 */
	@Column(name = "`OBJNAME`")
	private String objName;

	/**
	 * 被操作对象的描述
	 * 
	 * @since yaonengjun @ 2012-8-23
	 */
	@Column(name = "`OBJDESC`")
	private String objDesc;

	/**
	 * 对象类型
	 */
	@Column(name = "`OBJTYPE`")
	private String objType;
	/**
	 *
	 */
	@Column(name = "`REMOTEADDR`")
	private String remoteAddr;
	/**
	 * 操作描述
	 */
	@Column(name = "`OPERDESC`")
	private String operDesc;
	/**
	 * 操作类型
	 */
	@Column(name = "`OPERTYPE`")
	private String operType;
	/**
	 * 操作用户id
	 */
	@Column(name = "`OPERUSERID`")
	private int operUserId;
	/**
	 * 操作用户名
	 */
	@Column(name = "`OPERUSERNAME`")
	private String operUserName;
	/**
	 * 操作结果
	 */
	@Column(name = "`RESULT`")
	@Enumerated(value = EnumType.STRING)
	private Result result;
	/**
	 * 耗时
	 */
	@Column(name = "`SPENTTIME`")
	private long spentTime;
	/**
	 * 开始时间
	 */
	@Column(name = "`STARTTIME`")
	private long startTime;
	/**
	 * 是否被积分
	 */
	@Column(name = "ISSCORED")
	private boolean isScored = false;

	/**
	 * 系统标识
	 */
	@Column(name = "SYSFLAG")
	private String sysFlag;
	/**
	 * 错误消息
	 */
	@Column(name = "`ERRORMSG`", length = 2000)
	private String errorMsg;

	/**
	 * 操作主题
	 */
	@Column(name = "`OPERTITLE`")
	private String operTitle;

	/**
	 * 代理IP串.
	 */
	@Column(name = "`PROXYIPS`", length = 512)
	private String proxyIPs;

	/**
	 * 所用的浏览器或客户程序.
	 */
	@Column(name = "`USERAGENT`")
	private String userAgent;

	/**
	 * 主要调用信息，用于诊断.
	 */
	@Column(name = "`CALLERSTACKBRIEF`", length = 1024)
	private String callerStackBrief;

	/**
	 * 扩展字段1
	 */
	@Column(name = "EXTENDFIELD1", length = 2000)
	private String extendField1;
	/**
	 * 扩展字段2
	 */
	@Column(name = "EXTENDFIELD2")
	private String extendField2;
	/**
	 * 扩展字段3
	 */
	@Column(name = "EXTENDFIELD3")
	private String extendField3;
	/**
	 * 操作日志的源头编号（当前日志记录为批量操作中的一条）
	 */
	@Column(name = "ROOTLOGID")
	private int rootLogId;

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getLogLevel()
	 * @since luofei@2010-4-21
	 */
	@Override
	public Level getLogLevel() {
		return this.logLevel;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getObjId()
	 * @since luofei@2010-4-21
	 */
	@Override
	public int getObjId() {
		return this.objId;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getObjType()
	 * @since luofei@2010-4-21
	 */
	@Override
	public String getObjType() {
		return this.objType;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperArgs()
	 * @since luofei@2010-4-21
	 */
	@Override
	public Object[] getOperArgs() {
		if (this.extendField1 == null)
			return new Object[0];
		if (this.extendField2 == null)
			return new Object[] { this.extendField1 };
		if (this.extendField3 == null)
			return new Object[] { this.extendField1, this.extendField2 };
		return new Object[] { this.extendField1, this.extendField2,
				this.extendField3 };
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperDesc()
	 * @since luofei@2010-4-21
	 */
	@Override
	public String getOperDesc() {
		return this.operDesc;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperTitle()
	 * @since luofei@2010-4-21
	 */
	@Override
	public String getOperTitle() {
		return this.operTitle;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperType()
	 * @since luofei@2010-4-21
	 */
	@Override
	public String getOperType() {
		return this.operType;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperUserId()
	 * @since luofei@2010-4-21
	 */
	@Override
	public int getOperUserId() {
		return this.operUserId;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getOperUserName()
	 * @since luofei@2010-4-21
	 */
	@Override
	public String getOperUserName() {
		return this.operUserName;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getResult()
	 * @since luofei@2010-4-21
	 */
	@Override
	public Result getResult() {
		return this.result;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getSpentTime()
	 * @since luofei@2010-4-21
	 */
	@Override
	public long getSpentTime() {
		return this.spentTime;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#getStartTime()
	 * @since luofei@2010-4-21
	 */
	@Override
	public Date getStartTime() {
		return new Date(this.startTime);
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setLogLevel(com.trs.dev4.jdk16.actionlog.LogEnums.Level)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setLogLevel(Level level) {
		this.logLevel = level;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setObjId(int)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setObjId(int i) {
		this.objId = i;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setObjType(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setObjType(String s) {
		this.objType = s;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperArgs(java.lang.Object[])
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperArgs(Object... obj) {
		// this.extendField1 = obj.length > 0 ? String.valueOf(obj[0]) : "";
		// this.extendField2 = obj.length > 1 ? String.valueOf(obj[1]) : "";
		// this.extendField3 = obj.length > 2 ? String.valueOf(obj[2]) : "";
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperDesc(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperDesc(String s) {
		this.operDesc = s;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperTitle(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperTitle(String s) {
		this.operTitle = s;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperType(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperType(String s) {
		this.operType = s;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperUserId(int)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperUserId(int i) {
		this.operUserId = i;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setOperUserName(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setOperUserName(String s) {
		this.operUserName = s;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setResult(com.trs.dev4.jdk16.actionlog.LogEnums.Result)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setResult(Result result) {
		this.result = result;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setSpentTime(long)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setSpentTime(long l) {
		this.spentTime = l;

	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlog#setStartTime(long)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setStartTime(long l) {
		this.startTime = l;

	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-21
	 */
	public String getExtendField1() {
		return extendField1;
	}

	/**
	 * 
	 * @param extendField1
	 * @since luofei@2010-4-21
	 */
	public void setExtendField1(String extendField1) {
		this.extendField1 = extendField1;
	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-21
	 */
	public String getExtendField2() {
		return extendField2;
	}

	/**
	 * 
	 * @param extendField2
	 * @since luofei@2010-4-21
	 */
	public void setExtendField2(String extendField2) {
		this.extendField2 = extendField2;
	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-21
	 */
	public String getExtendField3() {
		return extendField3;
	}

	/**
	 * 
	 * @param extendField3
	 * @since luofei@2010-4-21
	 */
	public void setExtendField3(String extendField3) {
		this.extendField3 = extendField3;
	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-21
	 */
	public String getSysFlag() {
		return sysFlag;
	}

	/**
	 * 
	 * @param sysFlag
	 * @since luofei@2010-4-21
	 */
	public void setSysFlag(String sysFlag) {
		this.sysFlag = sysFlag;
	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-21
	 */
	public boolean isScored() {
		return isScored;
	}

	/**
	 * 
	 * @param isScored
	 * @since luofei@2010-4-21
	 */
	public void setScored(boolean isScored) {
		this.isScored = isScored;
	}

	/**
	 * 
	 * @return
	 * @since luofei@2010-4-22
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * 
	 * @param errorMessage
	 * @since luofei@2010-4-22
	 */
	public void setErrorMsg(String errorMessage) {
		this.errorMsg = errorMessage;
	}

	/**
	 * 设置操作日志的源头编号
	 * 
	 * @param rootLogId
	 * @since liuyou @ 2010-4-27
	 */
	public void setRootLogId(int rootLogId) {
		this.rootLogId = rootLogId;
	}

	/**
	 * 返回操作日志的源头编号
	 * 
	 * @return
	 * @since liuyou @ 2010-4-27
	 */
	public int getRootLogId() {
		return rootLogId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Actionlog [errorMsg=");
		builder.append(errorMsg).append(",");
		builder.append(super.toString());
		builder.append(", extendField1=");
		builder.append(extendField1);
		builder.append(", extendField2=");
		builder.append(extendField2);
		builder.append(", extendField3=");
		builder.append(extendField3);
		builder.append(", isScored=");
		builder.append(isScored);
		builder.append(", logLevel=");
		builder.append(logLevel);
		builder.append(", objId=");
		builder.append(objId);
		builder.append(", objType=");
		builder.append(objType);
		builder.append(", operDesc=");
		builder.append(operDesc);
		builder.append(", operTitle=");
		builder.append(operTitle);
		builder.append(", operType=");
		builder.append(operType);
		builder.append(", operUserId=");
		builder.append(operUserId);
		builder.append(", operUserName=");
		builder.append(operUserName);
		builder.append(", result=");
		builder.append(result);
		builder.append(", spentTime=");
		builder.append(spentTime);
		builder.append(", startTime=");
		builder.append(startTime);
		builder.append(", sysFlag=");
		builder.append(sysFlag);
		builder.append(", proxyIPs=");
		builder.append(proxyIPs);
		builder.append(", userAgent=");
		builder.append(userAgent);
		builder.append(", callerStackBrief=");
		builder.append(callerStackBrief);
		builder.append(", rootLogId=");
		builder.append(rootLogId);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * @return the {@link #remoteAddr}
	 */
	public String getRemoteAddr() {
		return remoteAddr;
	}

	/**
	 * @param remoteAddr
	 *            the {@link #remoteAddr} to set
	 */
	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}

	/**
	 * Get the {@link #proxyIPs}.
	 * 
	 * @return the {@link #proxyIPs}.
	 */
	public String getProxyIPs() {
		return proxyIPs == null ? "" : proxyIPs;
	}

	/**
	 * Set the {@link #proxyIPs}.
	 * 
	 * @param proxyIPs
	 *            the proxyIPs to set
	 */
	public void setProxyIPs(String proxyIPs) {
		this.proxyIPs = proxyIPs;
	}

	/**
	 * Get the {@link #callerStackBrief}.
	 * 
	 * @return the {@link #callerStackBrief}.
	 */
	public String getCallerStackBrief() {
		return callerStackBrief;
	}

	/**
	 * Set the {@link #callerStackBrief}.
	 * 
	 * @param mainCallerStack
	 *            the mainCallerStack to set
	 */
	public void setCallerStackBrief(String mainCallerStack) {
		this.callerStackBrief = mainCallerStack;
	}

	/**
	 * Get the {@link #userAgent}.
	 * 
	 * @return the {@link #userAgent}.
	 */
	public String getUserAgent() {
		return userAgent;
	}

	/**
	 * Set the {@link #userAgent}.
	 * 
	 * @param userAgent
	 *            the userAgent to set
	 */
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjDesc() {
		return objDesc;
	}

	public void setObjDesc(String objDesc) {
		this.objDesc = objDesc;
	}

}
