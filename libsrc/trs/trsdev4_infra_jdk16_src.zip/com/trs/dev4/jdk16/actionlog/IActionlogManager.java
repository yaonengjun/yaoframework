package com.trs.dev4.jdk16.actionlog;

import java.util.List;

import com.trs.dev4.jdk16.actionlog.impl.Actionlog;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IBaseManager;
import com.trs.dev4.jdk16.model.IEntity;

/**
 * 日志管理服务接口,不允许对日志进行删除,修改操作
 * 
 * 
 */
public interface IActionlogManager extends IBaseManager<Actionlog> {

	/**
	 * 日志归档
	 * 
	 */
	public void archive(SearchFilter filter);

	/**
	 * 应用名称
	 * 
	 * @param sysFlag
	 * @since liuyou @ 2010-4-21
	 */
	public void setSysFlag(String sysFlag);

	/**
	 * 创建日志对象
	 * 
	 * @param t
	 *            实体对象(objType返回如"actionlog.objtype.user")
	 * @param operType
	 *            操作类型,格式如"actionlog.oper.user_create",实际传入"user_create"即可。
	 * @param result
	 *            操作结果
	 * @param startTime
	 *            操作开始时间
	 * @param spentTime
	 *            操作时长
	 * @return
	 * @since liuyou @ 2010-4-21
	 * @deprecated
	 */
	@Deprecated
	public Actionlog createActionlog(IEntity t, String operType,
			LogEnums.Result result, long startTime, long spentTime);

	/**
	 * 创建日志对象
	 * 
	 * @param t
	 *            实体对象(objType返回如"actionlog.objtype.user")
	 * @param operType
	 *            操作类型,格式如"actionlog.oper.user_create",实际传入"user_create"即可。
	 * @param result
	 *            操作结果
	 * @param startTime
	 *            操作开始时间
	 * @param spentTime
	 *            操作时长
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	public Actionlog createActionlog(Object operator, Object object,
			String operType, LogEnums.Result result, long startTime,
			long spentTime, String applicationName);

	/**
	 * 计算并更新积分状态,如果被积分的记录,把积分标志置为true
	 * 
	 * @param filter
	 * @return
	 */
	List<Actionlog> getAndUpdateUnscored(SearchFilter filter);
}
