/*
 * Created: Administrator@Oct 27, 2010 2:46:40 PM
 */
package com.trs.dev4.jdk16.tunning;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * 记录数据库查询及操作的耗时。 <br>
 * 
 */
public class PerformanceTimer {
	/**
	 *
	 */
	private final static Logger logger = Logger.getLogger(PerformanceTimer.class);
	/**
	 * 起始时间
	 */
	private long beginTimeInMillis = System.currentTimeMillis();
	/**
	 * 分布开始时间
	 */
	private long stepBeginTimeInMillis = beginTimeInMillis;

	/**
	 *
	 */
	private List<Stepper> steppes = new ArrayList<Stepper>();
	/**
	 *
	 */
	private String title = "PerformanceTimer";

	/**
	 * @return the {@link #title}
	 */
	public String getTitle() {
		return title;
	}

	private long durationTheshold = 1000;
	/**
	 * @return the {@link #trackers}
	 */
	public List<Stepper> getSteppes() {
		return steppes;
	}


	/**
	 *
	 */
	public PerformanceTimer() {

	}

	/**
	 * 
	 * @param title
	 * @since fangxiang @ Nov 3, 2010
	 */
	public PerformanceTimer(String title) {
		this.title = title;
	}

	/**
	 *
	 */
	public PerformanceTimer(String title, long durationTheshold) {
		this.title = title;
		this.durationTheshold = durationTheshold;
	}

	/**
	 * 
	 * 
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stop(String name, String description) {
		long duration = getDuration();
		if (isSlow(duration)) {
			logger.debug("Action(" + name + ") consumed (" + duration + ") ms.");
		}
		steppes.add(new Stepper(name, description, duration));
	}

	/**
	 * 
	 * 
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stop(String name) {
		this.stop(name, "");
	}

	/**
	 * 
	 * 
	 * @since fangxiang @ Nov 3, 2010
	 */
	public void stop() {
		this.stop(title, "");
	}

	/**
	 * 
	 * @param name
	 * @param description
	 * @since fangxiang @ Nov 3, 2010
	 */
	public void step(String name, String description) {
		long duration = getDuration();
		if (isSlow(duration)) {
			logger.debug("Action(" + name + "-" + description + ") consumed ("
					+ duration + ") ms.");
		}
		steppes.add(new Stepper(name, description, duration));
	}

	/**
	 * 
	 * @param name
	 * @since fangxiang @ Nov 3, 2010
	 */
	public void step(String name) {
		this.step(name, "");
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	private boolean isSlow(long duration) {
		return (duration > durationTheshold);
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	public long getDuration() {
		long duration = (System.currentTimeMillis() - stepBeginTimeInMillis);
		stepBeginTimeInMillis = System.currentTimeMillis();
		return duration;
	}

}