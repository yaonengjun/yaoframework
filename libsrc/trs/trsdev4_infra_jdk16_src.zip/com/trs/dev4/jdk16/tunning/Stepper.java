/*
 * Created: fangxiang@Nov 3, 2010 11:38:45 AM
 */
package com.trs.dev4.jdk16.tunning;

/**
 * 职责: <br>
 * 
 */
public class Stepper {

	/**
	 *
	 */
	private String name;
	/**
	 *
	 */
	private String description;
	/**
	 *
	 */
	private long duration;

	/**
	 * 
	 * @param name
	 * @param description
	 * @param duration
	 */
	Stepper(String name, String description, long duration) {
		this.name = name;
		this.description = description;
		this.duration = duration;
	}

	/**
	 * @return the {@link #name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the {@link #description}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return the {@link #duration}
	 */
	public long getDuration() {
		return duration;
	}

}
