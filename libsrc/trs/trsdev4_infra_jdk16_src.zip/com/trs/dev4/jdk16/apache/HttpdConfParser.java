/*
 * Created: liushen@Nov 17, 2010 8:26:40 AM
 */
package com.trs.dev4.jdk16.apache;

import java.io.File;
import java.util.Properties;

import com.trs.dev4.jdk16.utils.PropertyUtil;

/**
 * Apache配置文件解析，用于获取相关信息. <br>
 * 
 */
public class HttpdConfParser {

	private Properties props;

	// public HttpdConfParser(String filePath) {
	// }

	/**
	 * 
	 * @param file
	 */
	public HttpdConfParser(File file) {
		props = PropertyUtil.loadProperties(file);
		if (props.size() == 0) {
			throw new IllegalArgumentException("no config in " + file);
		}
	}

	/**
	 * 获取Apache监听地址和端口。可能的配置格式如下：
	 * <ol>
	 * <li>Listen 80
	 * <li>Listen 192.0.2.1:80 (want Apache to handle IPv4 connections only)
	 * <li>Listen 0.0.0.0:80
	 * <li>Listen [2001:db8::a00:20ff:fea7:ccea]:80 (IPv6 addresses must be
	 * enclosed in square brackets)
	 * </ol>
	 * 详见http://httpd.apache.org/docs/2.2/bind.html
	 * 
	 * @return 端口值; 如不存在则返回<code>0</code>.
	 * @since liushen @ Nov 17, 2010
	 */
	public String getListenAddress() {
		return PropertyUtil.getTrimString(props, "Listen", null);
	}

}
