package com.trs.dev4.jdk16.view;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.web.context.ServletContextAware;

/**
 * 将一个系统配置文件转换为application上的一个 sysConfig属性<br>
 * 属性的结果为HashMap
 * 
 */
public class ConfigMapFactoryBean extends PropertiesFactoryBean implements
		ServletContextAware {

	@Override
	public Class<Properties> getObjectType() {
		return Properties.class;
	}

	private ServletContext application;

	/**
	 * Create the Map instance, populated with keys and Resource values.
	 */
	protected Object createInstance() throws IOException {
		Map<String, String> result = new HashMap<String, String>();
		Properties props = mergeProperties();
		for (Enumeration<?> en = props.propertyNames(); en
				.hasMoreElements();) {
			String key = (String) en.nextElement();
			String value = props.getProperty(key);
			result.put(key, value);
		}
		// 因为这个方法由super.afterPropertiesSet调用
		// 所以必在setServletContext方法之后
		// 但在测试用例中ServletContextAware无效,application为null
		if (application != null)
			application.setAttribute("sysConfig", result);
		return result;
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		application = servletContext;
	}

}
