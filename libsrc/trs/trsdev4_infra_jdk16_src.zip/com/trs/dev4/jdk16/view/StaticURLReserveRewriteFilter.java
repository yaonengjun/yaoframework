/*
 * Created: TRS@Sep 27, 2011 2:40:26 PM
 */
package com.trs.dev4.jdk16.view;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 将请求的静态URL改写成动态URL<br>
 * 
 */
public class StaticURLReserveRewriteFilter implements Filter {

	private final static Logger LOG = Logger.getLogger(StaticURLReserveRewriteFilter.class);

	/**
	 * @see javax.servlet.Filter#destroy()
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void destroy() {

	}

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		// 如果不需要重写的话，则直接转发
		if (!needRewrite(httpRequest, httpResponse)) {
			filterChain.doFilter(request, response);
			return;
		}
		// 需要做重写
		String uri = httpRequest.getServletPath();
		String rewritedUri = uri;
		Map<String, String> rewriteRules = this.loadRewriteRules(httpRequest, httpResponse);
		if (rewriteRules != null) {// 如果没有找到重写规则
			for (String findRegex : rewriteRules.keySet()) {
				String replaceRegex = rewriteRules.get(findRegex);
				rewritedUri = StringHelper.regexReplace(uri, findRegex, replaceRegex);
				if (!rewritedUri.equals(uri)) { // 如果重写前后的uri不一样的话，则表示经过了重写
					if (LOG.isDebugEnabled()) {
						LOG.debug("Request(" + httpRequest.getServletPath() + ")' uri rewrited to (" + rewritedUri + ") by (" + findRegex + ") .");
					}
					httpResponse.setHeader("reservedUri", rewritedUri + "," + DateUtil.getCurrentDateTime());
					request.getRequestDispatcher(rewritedUri).forward(request, response);
					return;
				}
			}
		} else {
			if (LOG.isDebugEnabled()) {
				LOG.debug("Request(" + httpRequest.getServletPath() + ")' repsone-rewrited by rewriteRules == null");
			}
			filterChain.doFilter(request, response);
		}
	}

	/**
	 * 获取重写规则
	 * 
	 * @param request
	 *            请求
	 * @param response
	 *            响应
	 * @return Map的key是查找规则，value是替换规则
	 * @since TRS @ Sep 28, 2011
	 */
	protected Map<String, String> loadRewriteRules(HttpServletRequest request, HttpServletResponse response) {
		Map<String, String> rewriteRules = new HashMap<String, String>();
		rewriteRules.put("/postList_(\\d+).html", "\\/boardList\\.do\\?action=postList&boardId=$1");
		return rewriteRules;
	}

	/**
	 * 判断请求是否需要进行URL重写，子类需进行覆盖
	 * 
	 * @param request
	 *            请求
	 * @param response
	 *            响应
	 * @return true表示需要重写，false表示不需要重写
	 * @since TRS @ Sep 28, 2011
	 */
	protected boolean needRewrite(HttpServletRequest request, HttpServletResponse response) {
		String uri = request.getServletPath();
		return uri.endsWith(".html");
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

}
