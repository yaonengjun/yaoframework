/*
 * Created: fangxiang@Apr 17, 2010 6:23:14 PM
 */
package com.trs.dev4.jdk16.view;

import com.trs.dev4.jdk16.model.IEntity;

/**
 *
 */
public class URLBuilder {

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String makePublicUrl(IEntity entity) {
		return "";
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String makeConsoleUrl(IEntity entity) {
		return "";
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String makeCacheUrl(IEntity entity) {
		return "";
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String makeStaticUrl(IEntity entity) {
		return "";
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String makePersonUrl(IEntity entity) {
		return "";
	}
}
