/*
 * Created: liushen@May 24, 2010 3:56:05 PM
 */
package com.trs.dev4.jdk16.exec;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 基于模板，替换、拼接、生成命令行参数或JSon等数据格式的字符串. <br>
 */
public class ArgumentsBuilder {

	private String template;

	private Map<String, String> tokenVars = new HashMap<String, String>();

	/**
	 * 根据模板构造对象.
	 */
	public ArgumentsBuilder(String template) {
		this.template = template;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, String value) {
		tokenVars.put(token, value);
		return this;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, long value) {
		tokenVars.put(token, String.valueOf(value));
		return this;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, int value) {
		tokenVars.put(token, String.valueOf(value));
		return this;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, double value) {
		tokenVars.put(token, String.valueOf(value));
		return this;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, float value) {
		tokenVars.put(token, String.valueOf(value));
		return this;
	}

	/**
	 * 替换模板变量.
	 * 
	 * @param token
	 *            模板变量名
	 * @param value
	 *            模板变量值
	 * @return 增加要替换的模板变量信息后的该对象自身，便于链式调用
	 * @since liushen @ May 24, 2010
	 */
	public ArgumentsBuilder replaceAll(String token, boolean value) {
		tokenVars.put(token, String.valueOf(value));
		return this;
	}

	/**
	 * 替换所有模板变量，生成命令行参数的字符串。 注意：如果模板变量值中有空格，则会自动加引号处理。
	 * 
	 * @return 命令行参数的字符串
	 * @since liushen @ May 24, 2010
	 */
	public String toArgument() {
		Set<String> tokens = tokenVars.keySet();
		String result = template;
		for (String token : tokens) {
			String replacement = StringHelper.addQuote(tokenVars.get(token));
			result = StringHelper.replaceAll(result, token, replacement);
		}
		return result.charAt(0) == ' ' ? result : " " + result;
	}

	/**
	 * 替换所有模板变量(但对于有空格的情况不添加双引号)，生成字符串。
	 * 
	 * @return 替换后的字符串
	 * @since lichuanjiao @ 2010-8-25
	 */
	public String toArgumentWithoutAddQuote() {
		Set<String> tokens = tokenVars.keySet();
		String result = template;
		for (String token : tokens) {
			String replacement = tokenVars.get(token);
			result = StringHelper.replaceAll(result, token, replacement);
		}
		return result.charAt(0) == ' ' ? result : " " + result;
	}

	/**
	 * 在后面追加一项，自动在前面加上空格。
	 * 
	 * @param item
	 * @return
	 * @since liushen @ Oct 25, 2011
	 */
	ArgumentsBuilder append(String item) {
		if (StringHelper.isEmpty(item)) {
			return this;
		}
		// A+B, A以空白结尾或B以空白开头，不需加空格；其他情况要加空格
		if (false == item.startsWith(" ")) {
			template += " ";
		}
		template += item;
		// TODO: liushen@Oct 25, 2011: 符合实际场景的单元测试
		return this;
	}

}
