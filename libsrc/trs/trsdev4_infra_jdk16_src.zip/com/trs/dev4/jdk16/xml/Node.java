/**
 * Node.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml;

/**
 * 一个节点。
 * 
 */
public interface Node {

	public String toXML() ;

	public void setLevel(int level) ;

	public int getLevel() ;

}
