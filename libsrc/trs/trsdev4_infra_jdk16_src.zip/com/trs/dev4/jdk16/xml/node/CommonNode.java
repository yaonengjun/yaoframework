/**
 * CommonNode.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml.node;

/**
 * 如果有children，就做ContainerNode使用，没有children则做SimpleNode使用。
 * 
 */
public class CommonNode extends ContainerNode {
	/**
	 *
	 */
	private String nodeValue ;
	/**
	 *
	 */
	private boolean CDATANeeded = false ;

	/**
	 * 
	 * @param nodeName
	 */
	public CommonNode(String nodeName) {
		super(nodeName);
	}

	@Override
	protected boolean hasNodeValue() {
		return super.hasNodeValue() || (nodeValue != null && nodeValue.length() > 0) ;
	}

	/**
	 * 返回子节点生成的xml
	 */
	@Override
	protected String getNodeValue() {

		if(super.hasNodeValue()){ //作为ContainerNode使用
			return super.getNodeValue() ;
		}else{ //作为SimpleNode使用
			if(!CDATANeeded){
				return nodeValue ;
			}else{
				StringBuffer sb = new StringBuffer(nodeValue.length() + 20) ;
				sb.append("<![CDATA[").append(nodeValue).append("]]>") ;

				return sb.toString() ;
			}
		}
	}

	public boolean isCDATANeeded() {
		return CDATANeeded;
	}

	public void setCDATANeeded(boolean needed) {
		CDATANeeded = needed;
	}

	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
		setCDATANeeded(true) ;
	}

	public void setNodeValue(int nodeValue) {
		this.nodeValue = String.valueOf(nodeValue) ;
		setCDATANeeded(false) ;
	}

}
