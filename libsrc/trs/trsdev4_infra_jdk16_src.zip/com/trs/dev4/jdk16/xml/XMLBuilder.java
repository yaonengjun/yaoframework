/**
 * XMLBuilder.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml;

import java.util.Stack;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.xml.node.CommonNode;

/**
 * XML Bulider
 * 
 * @see com.trs.common.xml.helper.XMLGenerator
 * 
 */
public class XMLBuilder {

	/**
	 *
	 */
	protected final Logger LOG = Logger.getLogger(getClass());
	/**
	 *
	 */
	private CommonNode currentNode ; //当前的Node

	private CommonNode parentNode ; //

	private CommonNode root ;

	private XMLGenerator xg ;
	/**
	 *
	 */
	private Stack<Node> traces = new Stack<Node>();

	public XMLBuilder(String rootName){
		this(rootName, "UTF-8") ;
	}

	public XMLBuilder(String rootName, String encoding){
		root = new CommonNode(rootName) ;
		currentNode = root ;

		xg = new XMLGenerator(encoding) ;
		xg.setRootNode(root) ;
	}

	/**
	 * 在当前节点上添加一个子节点，并且将当前节点移到节点。
	 * @param nodeName 要添加的子节点名称
	 */
	public XMLBuilder appendChildNode(String nodeName){
		CommonNode node = new CommonNode(nodeName) ;
		currentNode.addChildNode(node) ;

		traces.push(currentNode) ;
		parentNode = currentNode ;

		currentNode = node ;

		return this ;
	}

	/**
	 * 在当前节点上添加一个并列节点，并且将当前节点移到新节点。
	 * @param nodeName 要添加的并列节点名称
	 */
	public XMLBuilder appendSiblingNode(String nodeName){
		CommonNode node = new CommonNode(nodeName) ;
		parentNode.addChildNode(node) ;

		currentNode = node ;
		return this ;
	}

	/**
	 * 添加一个当前节点父节点的并列节点，并且将当前节点移动到新节点。
	 * @param nodeName 要添加的节点并称
	 */
	public XMLBuilder appendParentNode(String nodeName){
		backToParent() ;

		return appendSiblingNode(nodeName) ;
	}

	/**
	 * 把当前节点移动到父节点。
	 */
	public XMLBuilder backToParent(){
		if(LOG.isDebugEnabled()){
			LOG.debug("--------------------") ;
			LOG.debug("root:" + root) ;
			LOG.debug("traces:" + traces) ;

			LOG.debug("before. currentNode:" + currentNode) ;
			LOG.debug("before. parentNode:" + parentNode) ;
		}

		if(isCurrentRootNode()){
			throw new RuntimeException("已经到达了根节点") ;
		}else if(parentNode == root){
			currentNode = root ;
			parentNode = null ;
		}else{
			//回退到grandparent
			/*CommonNode m_parentNode = (CommonNode) */ traces.pop() ; //pop出parent
			CommonNode grandParent = (CommonNode) traces.peek() ;
			currentNode = parentNode ;
			parentNode = grandParent ;
		}

		if(LOG.isDebugEnabled()){
			LOG.debug("after. currentNode:" + currentNode) ;
			LOG.debug("after. parentNode:" + parentNode) ;
		}

		return this ;
	}

	/**
	 * 将当前节点移动到根节点。
	 */
	public XMLBuilder backToRoot(){
		while(!isCurrentRootNode()){
			backToParent() ;
		}
		return this ;
	}

	/**
	 * 当前节点是否是根节点。
	 */
	public boolean isCurrentRootNode(){
		return currentNode == root ;
	}

	/**
	 * @see #addAttribute(String, Object)
	 */
	public XMLBuilder addAttribute(String name, int value){
		currentNode.addAttribute(name, value) ;
		return this ;
	}

	/**
	 * @see #addAttribute(String, Object)
	 */
	public XMLBuilder addAttribute(String name, String value){
		currentNode.addAttribute(name, value) ;
		return this ;
	}

	/**
	 * 添加一个节点属性，如果原来的属性已经存在，则覆盖。名称区分大小写。
	 * @param name 属性名称
	 * @param value 属性值。如果为null，作为""处理。
	 */
	public XMLBuilder addAttribute(String name, Object value){
		currentNode.addAttribute(name, value) ;
		return this ;
	}

	public XMLBuilder setNodeValue(String nodeValue){
		currentNode.setNodeValue(nodeValue) ;
		return this ;
	}

	/**
	 * 设置节点值
	 * @param nodeValue 属性名称
	 * @param CDATANeeded 是否需要添加CDATA标记
	 */
	public XMLBuilder setNodeValue(String nodeValue, boolean CDATANeeded){
		currentNode.setNodeValue(nodeValue) ;
		currentNode.setCDATANeeded(CDATANeeded) ;
		return this ;
	}

	public XMLBuilder setNodeValue(int nodeValue){
		currentNode.setNodeValue(nodeValue) ;
		return this ;
	}

	public XMLBuilder setNodeValue(boolean nodeValue){
		currentNode.setNodeValue(String.valueOf(nodeValue)) ;
		currentNode.setCDATANeeded(false) ;
		return this ;
	}

	public String toXML(){
		return xg.generateXML() ;
	}

}
