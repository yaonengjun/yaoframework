/**
 * XMLSegmentNode.java. created on 2006-6-5
 */
package com.trs.dev4.jdk16.xml.node;

import com.trs.dev4.jdk16.xml.Node;

/**
 * xml片断。
 * 
 */
public class XMLSegmentNode implements Node {

	/**
	 *
	 */
	private String xmlText ;
	/**
	 *
	 */
	private int level ;

	/**
	 * 
	 * @param xmlText
	 */
	public XMLSegmentNode(String xmlText){
		this.xmlText = xmlText ;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.xml.Node#toXML()
	 */
	@Override
	public String toXML() {
		return xmlText;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.xml.Node#setLevel(int)
	 */
	@Override
	public void setLevel(int level) {
		this.level = level ;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.xml.Node#getLevel()
	 */
	@Override
	public int getLevel() {
		return level;
	}

}
