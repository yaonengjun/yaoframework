/**
 * 
 */
package com.trs.dev4.searcher.constant;

/**
 * 定义全文检索组件常量
 * 
 * @author chuchanglin
 *
 */
public class SearchConst {
	/**
	 * 是否进行二次检索的字段名
	 */
	public static String SECOND_SEARCH_FILED = "isSecondSearch";
	
	/**
	 * 默认检索字段名
	 */
	public static String DEFAULT_FILED_NAME = "title";
	
	/**
	 * TRS Server默认的连接字符编码
	 */
	public static String DEFAULT_CHARSET = "UTF8";
	
	/**
	 * 检索结果标红显示
	 */
	public static String COLOR_RED = "red";
	public static String COLOR_GREEN = "green";
	public static String COLOR_BLUE = "blue";
	public static String COLOR_BLACK = "black";
}
