/*
 *
 */
package com.trs.dev4.searcher;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.client.ClassInfo;
import com.trs.client.TRSConnection;
import com.trs.client.TRSConstant;
import com.trs.client.TRSDataBase;
import com.trs.client.TRSException;
import com.trs.client.TRSResultSet;
import com.trs.dev4.jdk16.dao.Condition;
import com.trs.dev4.jdk16.dao.GroupByResult;
import com.trs.dev4.jdk16.dao.GroupByResult.GroupByRecord;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.searcher.constant.SearchConst;

/**
 * ISearcher的实现类，主要是TRS全文检索
 *
 * @author chuchanglin
 *
 */
public class TRSSearcher implements ISearcher {

	/**
	 * TRS Server服务器IP
	 */
	private String serverIP;

	/**
	 * 服务器端口号
	 */
	private String serverPort;

	/**
	 * 用户名
	 */
	private String userName;

	/**
	 * 密码
	 */
	private String password;

	/**
	 * 设置当前使用的字符集，参考TRSConstant.TCE_CHARSET_*
	 */
	private String charset;

	/**
	 * 命中此范围截取长度，默认为200字
	 */
	private int iCutsize = 200;

	/**
	 * 命中词标注的颜色，默认为黑色
	 */
	private String strHitColor;

	/**
	 * 关键字段列表，设置后这些字段将进行标注颜色和截取长度处理.如果没有关键字段，则不需要设置
	 */
	private List<String> keywordFileds;

	private static final Logger LOG = Logger.getLogger(TRSSearcher.class);

	/**
	 * 含有参数的构造函数，便于动态构建TRSSearcher
	 *
	 * @param serverIP
	 * @param serverPort
	 * @param userName
	 * @param password
	 * @param charset
	 */
	public TRSSearcher(String serverIP, String serverPort, String userName,
			String password, String charset) {
		this.serverIP = serverIP;
		this.serverPort = serverPort;
		this.userName = userName;
		this.password = password;
		this.charset = charset;
	}

	/**
	 * 默认字符编码为UTF8的构造函数.便于动态构建TRSSearcher
	 *
	 * @param serverIP
	 * @param serverPort
	 * @param userName
	 * @param password
	 */
	public TRSSearcher(String serverIP, String serverPort, String userName,
			String password) {
		this(serverIP, serverPort, userName, password, null);
	}

	/**
	 * 空白的构建函数
	 */
	public TRSSearcher(){}

	/**
	 * 进行TRS检索，并返回带分页的检索结果
	 *
	 * @param searchFilter
	 *            SearchFilter对象，含有检索条件
	 * @param searcherProvider
	 *            ISearcherProvider类型对象，主要提供检索的表名，将中间产物Map还原为ISeachable对象
	 * @return 含有ISearchable对象的PagedList对象
	 */
	public PagedList<ISearchable> search(SearchFilter searchFilter,
			ISearcherProvider searcherProvider) {
		// 当前页
		int pageIndex = 0;
		// 当前记录数
		int records = 0;
		PagedList<ISearchable> results = new PagedList<ISearchable>(
				new LinkedList<ISearchable>(), pageIndex, searchFilter
						.getMaxResults(), records);

		TRSConnection conn = null;
		TRSResultSet rtst = null;

		// 统计结果表达式，多个表达式之间以逗号分隔，可为空。
		String strStat = null;

		// TRS Server库名
		String dbName = searcherProvider.getSearcherDatabase();
		//如果条件为空或者数据库名为空，则返回一个空结果
		if (StringHelper.isEmpty(dbName)) {
			return results;
		}

		// 检索语句
		String trser = this.buildSearchExpression(searchFilter);
		//默认检索字段
		String defaultFields = searchFilter.getDefaultFields();

		try {
			conn = this.getConnection();
			TRSDataBase base = getDatabase(conn, dbName);
			LOG.info("TRSDataBase " + dbName + " encoding: "
					+ base.getProperty("LANGUAGE")
					+ "; TRSConnection encoding: "
					+ TRSConnection.getCharset(false) + "; defaultEncoding:"
					+ TRSConnection.getCharset(true));
			rtst = conn.executeSelect(dbName,
					trser, searchFilter.getOrderBy(), strStat,
							defaultFields, TRSConstant.TCM_MIXSORT|TRSConstant.TCM_LIFOSPARE,
					TRSConstant.TCE_OFFSET, isSecondSearch(searchFilter));
			LOG.debug("TRSDBName:" + dbName + ",expression:" + trser
					+ ",defaultFields:" + defaultFields + ",rtst.size():"
					+ rtst.getRecordCount());
			//进行分类查询，需要从searchFilter中取出groupby值，并进行分类对象构建
			String groupBy = searchFilter.getGroupBy();
			//构建GroupByRecord集合
			List<GroupByRecord> crs = categoryRecordFactory(rtst, groupBy,searchFilter.getOrderBy());
			GroupByResult cbr = new GroupByResult(groupBy, crs);
			LOG.debug("GroupBy:"+groupBy+",GroupByResult-size:"+cbr.getRecords().size());
			if ( LOG.isDebugEnabled() ){
				for ( GroupByRecord groupByRecord : cbr.getRecords() ){
					LOG.debug("GroupByRecord("+groupBy+"):"+groupByRecord.getFieldValue()+","+groupByRecord.getRecordCount());
				}
			}
			rtst.setBufferSize((searchFilter.getStartPos() / searchFilter
					.getMaxResults()), searchFilter.getMaxResults());
			//加工PagedList对象
			results = buildResultPage(rtst, searchFilter, searcherProvider);
			//将groupbyresult对象保存至PagedList中
			results.setGroupByResult(cbr);
		} catch (TRSException ex) {
			StringBuilder sb = new StringBuilder();
			sb.append("TRS全文检索出现异常：").append(ex.getMessage())
					.append(this.serverIP).append(":").append(this.serverPort)
					.append(", ").append(this.userName).append("@")
					.append(dbName).append("; 检索语句：").append(trser)
					.append(", 默认检索字段：").append(defaultFields);
			LOG.error(sb.toString(), ex);
			throw new DAOException(ex);
		} finally {
			this.cleanConnection(conn);
		}
		return results;
	}

	/**
	 * @param conn
	 * @param dbName
	 * @return
	 * @throws TRSException
	 * @since liushen @ May 31, 2011
	 */
	TRSDataBase getDatabase(TRSConnection conn, String dbName)
			throws TRSException {
		TRSDataBase[] arrDb = conn.getDataBases(dbName);
		if (arrDb == null || arrDb.length == 0) {
			return null;
		}
		return arrDb[0];
	}


	/**
	 * 按分类检索
	 *
	 * @param rtst TRS检索结果集
	 * @param 检索条件
	 * @throws TRSException
	 */
	private List<GroupByRecord> categoryRecordFactory(TRSResultSet rtst, String groupby,String orderBy) throws TRSException {
		List<GroupByRecord> records = new LinkedList<GroupByRecord>();
		if(StringHelper.isEmpty(groupby) || 0 == rtst.getRecordCount()){
			return records;
		}
		//每个类中保留结果记录的个数：0表示对结果记录只进行类别统计，而不改变结果记录的存储；
		//65535表示对结果记录进行类别统计，并按类别存储和保留所有的结果记录；其它值表示对结果记录进行类别统计，
		//并按类别存储，每个所保留的结果记录数不超过这里所指定的值。
		int iPruneStore = 0;

		//结果记录的排序方式，为空表示不改变原来的排序方式。多个排序字段间以半角分号、
//		逗号或空格分隔，字段名前加前缀‘+’表示按升序排列，加前缀‘-’表示按降序排列，指定“RELEVANCE”表示按相关性排序，
//		或用LIFO表示按记录的物理记录号的降序排列，如“+日期; -作者; RELEVANCE”。
//		String strSortMethod = "";

		//分类值
		String groupValue = "";

		//如果为true，则表示返回结果时类别名按升序排列，否则类别名按降序排列
		boolean orderby = false;
		int iClassNum = rtst.classResult(groupby, groupValue, iPruneStore, orderBy, orderby, TRSConstant.TCM_CLASSASCENT);
		LOG.debug("Group by ("+groupby +","+orderBy+") classNum:"+ iClassNum);
		for (int i= 0; i< iClassNum; i++){
	        ClassInfo classInfo= rtst.getClassInfo(i);
	        //分类的字段值
	        String fieldValue = classInfo.strValue;
	        //对应的记录数
	        int recordCount = classInfo.iRecordNum;
	        GroupByRecord cr = new GroupByRecord(fieldValue,recordCount);
			LOG.debug("Group by ("+groupby +","+orderBy+") classInfo("+i+"):"+ classInfo.toString()+",fieldValue:"+fieldValue+",recordNum:"+recordCount);
	        records.add(cr);
		}

		return records;
	}

	/**
	 * 将检索结果转化为Map，目的在于摆脱在上层实现对TRSResultSet的依赖
	 * 
	 * @param rtst为移动到检索结果记录集的指定记录
	 *            ，即使用moveTo方法后的TRSResultSet
	 * @return 将TRSResultSet转化的Map
	 */
	Map<String, String> processSearchResult(TRSResultSet rtst) {
		Map<String, String> result = new LinkedHashMap<String, String>();
		if (null == rtst)
			return result;

		int columns = 0;
		long recordID = 0;
		try {
			columns = rtst.getColumnCount();
			recordID =  rtst.getRecordID();
			//设置
			result.put("recordId",recordID+"");
		} catch (TRSException e) {
			LOG.error("GetColumnCount error:" + e.getMessage(), e);
		}
		//
		for (int i = 0; i < columns; i++) {
			try {
				String columnName = rtst.getColumnName(i);
				//标红与截取命中前后范围，现在指定的是截取前后200字，总长度为400字。
				String columnValue = columnValueBuilder(rtst, i, columnName);
				result.put(columnName, columnValue);
			} catch (TRSException e) {
				LOG.error("Record("+recordID+")'s GetColumnName( " + i + ") error ：" + e.getMessage(),
						e);
			}
		}
		// LOG.debug("Record("+recordID+"):"+result.toString());
		return result;
	}

	/**
	 * 截取命中此前后范围、设置命中显示颜色。如果需要自定义则覆盖此方法即可。
	 * 实现代码如：
	 * String columnValue = rtst.getStringWithCutsize(i, 400, "red");其中只需要重设400与"red"即可。
	 *	return columnValue;
	 *
	 * @param rtst
	 * @param i
	 * @return
	 * @throws TRSException
	 */
	protected String columnValueBuilder(TRSResultSet rtst, int i, String columnName)
			throws TRSException {
		if(StringHelper.isEmpty(columnName)){
			return "";
		}

		String value = rtst.getString(i);
		if(null == keywordFileds || 0 == keywordFileds.size()){
			return value;
		}

		//如果是关键字段，则做标色与截取长度处理
		if(keywordFileds.contains(columnName)){
			return rtst.getStringWithCutsize(i, iCutsize, strHitColor);
		}

		return value;
	}

	/**
	 * 封装成PagedList对象
	 *
	 * @param rtst
	 * @return ISeachable对象的PagedList
	 * @throws TRSException
	 */
	PagedList<ISearchable> buildResultPage(TRSResultSet rtst,
			SearchFilter searchFilter, ISearcherProvider searcherProvider)
			throws TRSException {
		int pageSize = searchFilter.getMaxResults();
		int pageIndex = searchFilter.getStartPos()
				/ searchFilter.getMaxResults();

		// 如果没有记录，则返回空集
		if (0 == rtst.getValidCount()) {
			return new PagedList<ISearchable>(new LinkedList<ISearchable>(),
					pageIndex, pageSize, 0);// 其中0为总记录数
		}

		List<ISearchable> itemList = new LinkedList<ISearchable>();

		rtst.moveTo(0, searchFilter.getStartPos());
		//
		for (int count = 0; count < pageSize; count++) {
			ISearchable searchable = searcherProvider.buildSearchedObject(this
					.processSearchResult(rtst));
			itemList.add(searchable);
			// 如果是最后一条则退出循环
			if (false == rtst.moveNext()) {
				break;
			}
		}
		PagedList<ISearchable> pagedList = new PagedList<ISearchable>(itemList,
				pageIndex, pageSize, (int) rtst.getRecordCount());
		return pagedList;
	}

	/**
	 * 按照指定的形式组织String，此方法可以提取到工具类中
	 *
	 * @param strs
	 * @param formStr
	 * @return
	 * @since chuchanglin @ 2010-6-30
	 */
	String strFormer(List<String> strs, String formStr) {
		if(null == strs || 0 == strs.size()){
			return "";
		}

		//默认的分割符为';'
		if(StringHelper.isEmpty(formStr)){
			formStr = ";";
		}
		StringBuffer sb = new StringBuffer();

		int size = strs.size();

        for (int i = 0; i < size; i++){
           sb.append(strs.get(i).trim());
           if(i != size - 1){
        	   sb.append(formStr);
           }
        }

        return sb.toString();
	}

	/**
	 * 建立和TRS Database Server的连接。
	 *
	 * @return 和TRS Database Server的连接
	 * @throws TRSException
	 *             创建连接失败
	 */
	TRSConnection getConnection() throws TRSException {
		TRSConnection conn = new TRSConnection();
		conn.connect(this.serverIP, this.serverPort, this.userName,
				this.password);
		if (false == StringHelper.isEmpty(charset)) {
			try {
				TRSConnection.setCharset(getCharset(charset), true); // 设置当前使用的字符集，参考TRSConstant.TCE_CHARSET_*
			} catch (Throwable e) {
				LOG.error("TRSConnection.setCharset to " + charset + " failed",
						e);
			}
		}
		return conn;
	}

	/**
	 * 获取字符集类型
	 *
	 * @param charset
	 *            字符编码
	 * @return int型， 字符编码对应的类型
	 */
	private int getCharset(String charset) {
		int iCharset = 0;

		// 默认为UTF8编码
		if (StringHelper.isEmpty(charset)){
			charset = SearchConst.DEFAULT_CHARSET;
		}

		charset = charset.toUpperCase();

		if (charset.equalsIgnoreCase("GBK")) {
			iCharset = TRSConstant.TCE_CHARSET_GB;
		} else {
			iCharset = TRSConstant.TCE_CHARSET_UTF8;
		}

		return iCharset;
	}

	/**
	 * 关闭连接
	 *
	 * @param conn
	 *            TRSConnection对象
	 */
	public void cleanConnection(TRSConnection conn) {
		if (conn != null) {
			conn.clean();
		}
	}

	/**
	 * 根据检索条件构造检索表达式
	 *
	 * @param searchFilter
	 *            ，SearchFilter对象，含有检索条件
	 * @return 加工好的TRS检索表达式。
	 */
	String buildSearchExpression(SearchFilter searchFilter) {
		// 如果searchFilter为空
		if (null == searchFilter)
			return null;

		// 条件总数
		int totalCount = searchFilter.getTotalConditions();

		StringBuilder sb = new StringBuilder();

		if(!isConditionEmpty(totalCount)){
			sb.append("(");
		}

		//遍历所有检索条件
		for (int i = 0; i < totalCount; i++) {
			Condition condition = searchFilter.getCondition(i);
			conditionBuilder(sb, condition);

			if(totalCount>1 && i<totalCount-1){
				sb.append(" and ");
			}
		}

		if(!isConditionEmpty(totalCount)){
			sb.append(")");
		}

		//默认检索此的处理
		String defaultKeyWord = searchFilter.getDefaultKeyword();

		if(isConditionEmpty(totalCount)){
			return defaultKeyWord;
		}else{
			if(!StringHelper.isEmpty(defaultKeyWord)){
				sb.append(" and ").append(defaultKeyWord);
			}
		}

		// 调试查看检索表达式
		if (LOG.isDebugEnabled()) {
			LOG.debug("search filter is--:" + sb.toString());
		}

		return sb.toString();
	}

	/**
	 * 条件是否为空
	 *
	 * @return
	 */
	private boolean isConditionEmpty(int totalCount){
		return 0 == totalCount;
	}

	/**
	 * 单个检索条件处理
	 *
	 * @param sb
	 * @param condition
	 */
	@SuppressWarnings("unchecked")
	void conditionBuilder(StringBuilder sb, Condition condition) {
		sb.append("(");
		sb.append(condition.getField()).append(' ');

		if (condition.isLikeCondition()) { // 对like进行判断
			sb.append(" = ").append(
					formatSearchWord(condition.getValue().toString()));
		} else if (condition.isBetweenCondition()) {// 对between操作符的处理
			sb.append('(').append(condition.getField()).append(" >= ")
					.append(
							formatSearchWord(condition.getValue()
									.toString())).append(')');
			sb.append(" and (").append(condition.getField()).append(" <= ")
					.append(
							formatSearchWord(condition.getValue2()
									.toString())).append(")");
		} else if (condition.needBindCollectionParam()) {// 对in操作符的处理
			List<String> values = (List<String>) condition.getValue();
			for (int j = 0; j < values.size(); j++) {
				sb.append(formatSearchWord(values.get(j).toString()));
				if (j != values.size() - 1) {
					sb.append(',');
				}
			}
		} else {
			sb.append(condition.getOp()).append(' ');
			sb.append(formatSearchWord(condition.getValue().toString()));
		}
		sb.append(")");
	}

	/**
	 * 过滤检索词中的vlaue中的非法字符
	 *
	 * @param sw
	 *            检索过滤词
	 * @return 过滤后的检索过滤词
	 */
	private String formatSearchWord(String sw) {
		sw = sw.trim();
		sw = squeezeWhiteSpace(sw);
		sw = this.replaceString(sw, "\\", "\\\\");
		sw = this.replaceString(sw, "'", "\\'");
		sw = this.replaceString(sw, "%", "\\%");
		sw = this.replaceString(sw, "?", "\\?");
//		sw = this.replaceString(sw, " ", "' AND  '");

		StringBuffer sb = new StringBuffer();
		sb.append("'").append(sw).append("'");
		return sb.toString();
	}


	/**
	 * 替换字符串
	 *
	 * @param str
	 * @param substr
	 * @param restr
	 * @return
	 */
	private String replaceString(String str, String substr, String restr) {
		if (str == null)
			return null;
		if (substr == null || substr.length() == 0)
			return str;
		String[] tmp = splitString(str, substr);
		String returnstr = null;
		if (tmp.length != 0) {
			returnstr = tmp[0];
			for (int i = 0; i < tmp.length - 1; i++)
				returnstr = dealNull(returnstr) + restr + tmp[i + 1];
		}
		return dealNull(returnstr);
	}

	/**
	 * 遍历字符串
	 *
	 * @param toSplit
	 * @param delimiter
	 * @return
	 */
	private String[] splitString(String toSplit, String delimiter) {
		if (toSplit == null)
			return new String[0];
		int arynum = 0;
		int intIdx = 0;
		int intIdex = 0;
		int div_length = delimiter.length();
		if (toSplit.compareTo("") != 0) {
			if (toSplit.indexOf(delimiter) != -1) {
				intIdx = toSplit.indexOf(delimiter);
				int intCount = 1;
				for (;;) {
					if (toSplit.indexOf(delimiter, intIdx + div_length) != -1) {
						intIdx = toSplit
								.indexOf(delimiter, intIdx + div_length);
						arynum = intCount;
					} else {
						arynum += 2;
						break;
					}
					intCount++;
				}
			} else
				arynum = 1;
		} else
			arynum = 0;
		intIdx = 0;
		intIdex = 0;
		String[] returnStr = new String[arynum];
		if (toSplit.compareTo("") != 0) {
			if (toSplit.indexOf(delimiter) != -1) {
				intIdx = toSplit.indexOf(delimiter);
				returnStr[0] = toSplit.substring(0, intIdx);
				int intCount = 1;
				for (;;) {
					if (toSplit.indexOf(delimiter, intIdx + div_length) != -1) {
						intIdex = toSplit.indexOf(delimiter, intIdx
								+ div_length);
						returnStr[intCount] = toSplit.substring(intIdx
								+ div_length, intIdex);
						intIdx = toSplit
								.indexOf(delimiter, intIdx + div_length);
					} else {
						returnStr[intCount] = toSplit.substring(intIdx
								+ div_length, toSplit.length());
						break;
					}
					intCount++;
				}
			} else {
				returnStr[0] = toSplit.substring(0, toSplit.length());
				return returnStr;
			}
		} else
			return returnStr;
		return returnStr;
	}


	/**
	 * 删除字符串中的多余空格。并且把字符串的前后空格删掉。
	 *
	 * <pre>
	 * 例如把&quot;     &quot;变成&quot; &quot;，把制表符'\t'变成&quot; &quot;;
	 * </pre>
	 *
	 * @date 2010-3-10
	 */
	private String squeezeWhiteSpace(String str) {
		str = dealNull(str);
		StringBuffer sb = new StringBuffer(str);
		StringBuffer sb2 = new StringBuffer();
		boolean flag = false;

		for (int i = 0; i < sb.length(); i++) {
			char c = sb.charAt(i);
			if (c != ' ' && c != '\t') {
				if (flag) {
					sb2.append(' ');
					flag = false;
				}
				sb2.append(c);
			} else {
				flag = true;
			}
		}
		return sb2.toString().trim();
	}

	/**
	 * 把null变成""<br>
	 *
	 * @date 2003年7月28日,2003年8月3日
	 */
	private String dealNull(String str) {
		String returnstr = null;
		if (str == null)
			returnstr = "";
		else
			returnstr = str;
		return returnstr;
	}


	/**
	 * 判断是否含有二次检索请求
	 *
	 * @param searchFilter
	 *            ， SearchFilter对象，含有检索条件
	 * @return 是否为二次检索，默认为不进行二次检索
	 */
	private boolean isSecondSearch(SearchFilter searchFilter) {

		boolean isSecondSearch = false;

		//暂时不考虑二次检索
		return isSecondSearch;
	}

	/**
	 * @param serverIP
	 *            the serverIP to set
	 */
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	/**
	 * @param serverPort
	 *            the serverPort to set
	 */
	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param charset
	 *            the charset to set
	 */
	public void setCharset(String charset) {
		this.charset = charset;
	}

	/**
	 * @param iCutsize the iCutsize to set
	 */
	public void setICutsize(int iCutsize) {
		this.iCutsize = iCutsize;
	}

	/**
	 * @param strHitColor the strHitColor to set
	 */
	public void setStrHitColor(String strHitColor) {
		this.strHitColor = strHitColor;
	}

	/**
	 * @param keywordFiled the keywordFiled to set
	 */
	public void setKeywordFileds(List<String> keywordFileds) {
		this.keywordFileds = keywordFileds;
	}
}
