/*
 * Created: liushen@Feb 16, 2011 1:14:02 PM
 */
package com.trs.dev4.searcher;

import com.trs.client.TRSConnection;
import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * 获取TRS Server Javabeans的主要信息. <br>
 */
public class TRSBeanUtil {

	/**
	 * TRSBean的本地库是否加载成功.
	 * 
	 * @since liushen @ Feb 16, 2011
	 */
	public static boolean isJNILibLoaded() {
		try {
			assertJNILibLoaded();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * 断定本地库已加载成功；否则抛出具体错误信息.
	 * 
	 * @throws WrappedException
	 * @since liushen @ Feb 16, 2011
	 */
	public static void assertJNILibLoaded() {
		try {
			new TRSConnection();
		} catch (Exception e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 返回TRSBean的版本号.
	 * 
	 * @since liushen @ Feb 16, 2011
	 */
	public static String getTRSBeanVersion() {
		try {
			return new TRSConnection().getVersion("Bean");
		} catch (Exception e) {
			throw new WrappedException(e);
		}
	}

}
